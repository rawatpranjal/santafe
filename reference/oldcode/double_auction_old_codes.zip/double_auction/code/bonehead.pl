#!/usr/bin/perl

# bonehead.pl: code to calculate the mean square prediction error
#              for forecasting the midpoint equilibrium price in a
#              double auction using the "boneheaded" prediction
#              strategy
#
#              Cyrus Aghamolla and John Rust, University of Maryland, 
#              October, 2008

$ENV{'PGHOST'} = "beethoven.econ.umd.edu";
$ENV{'PGPORT'} = "5432";
$ENV{'PGSSLMODE'} = "require";


use DBI;

my $dbh=DBI->connect("DBI:Pg:dbname=da","rthenkel","ot9Aihae");

$sth=doQuery($dbh,"select * from games where not(gamestart is null) order by gameid");

while ($href=$sth->fetchrow_hashref)
{

  my $nri=singleQuery($dbh,'select max(round) as maxrounds from tokens where gameid=?',$href->{gameid});

  my $nb=singleQuery($dbh,'select count(player) as num from players where gameid=? and player > 0',$href->{gameid});
  $nb=$nb->{num};
  my $ns=singleQuery($dbh,'select count(player) as num from players where gameid=? and player < 0',$href->{gameid});
  $ns=$ns->{num};

  print "analyzing game $href->{gameid} token generator code=$href->{randomseed}\n";
  print "    $nb buyers  $ns sellers  $nri->{maxrounds} rounds\n";


  for ($round=1; $round<=$nri->{maxrounds}; $round++)
  {
    my $sth1=doQuery($dbh,'select * from tokens where gameid=? and round=? and player > 0 order by value desc',
       $href->{gameid},$round);

    @df=();
    while ($pref=$sth1->fetchrow_hashref)
    {
     push(@df,$pref->{value});
    }

    my $sth1=doQuery($dbh,'select * from tokens where gameid=? and round=? and player < 0 order by value',
       $href->{gameid},$round);
    @sf=();
    while ($pref=$sth1->fetchrow_hashref)
    {
     push(@sf,$pref->{value});
    }

    @eq=equil($#df,$#sf,@df,@sf); 

    my $ns=$#sf+1;
    my $nb=$#df+1;

    print "    round $round equilibrium $ns units to sell $nb units to buy, q=$eq[0] pu=$eq[1] pl=$eq[2]\n";

    $cref=singleQuery($dbh,'select q,pl,pu from rounds where gameid=? and round=?',$href->{gameid},$round);

    print "                          q=$cref->{q} pu=$cref->{pu} pl=$cref->{pl}\n"; 



    $np=singleQuery($dbh,'select max(period) as maxp from transactions where gameid=? and round=?',$href->{gameid},$round);

    $np=$np->{maxp};

    for ($p=1; $p<=$np; $p++)
    {
      print "bid and ask history\n";
      $sth2=doQuery($dbh,'select distinct time from proposals where gameid=? and round=? and period=? and winner=?  order by time',
               $href->{gameid},$round,$p,'true');

      $nt=0;
      while ($gref=$sth2->fetchrow_hashref)
      {
         $nt++;
	 $best_bid=singleQuery($dbh,'select value from proposals where gameid=? and round=? and period=? and winner=?  '.
	           'and player > 0 and time=?',$href->{gameid},$round,$p,'true',$gref->{time});
	 $best_ask=singleQuery($dbh,'select value from proposals where gameid=? and round=? and period=? and winner=?  '.
	           'and player < 0 and time=?',$href->{gameid},$round,$p,'true',$gref->{time});
         print "p=$p $nt t=$gref->{time} current bid=$best_bid->{value} current ask=$best_ask->{value}\n";
      }

      $sth2=doQuery($dbh,'select time,price from transactions where gameid=? and round=? and period=? order by time',
               $href->{gameid},$round,$p);

      "transaction history\n";
      $nt=0;
      while ($gref=$sth2->fetchrow_hashref)
      {
         $nt++;
         print "p=$p $nt t=$gref->{time} price=$gref->{price}\n";
      }
      print "---------------------------------------\n";
    }

  } 

}


$dbh->disconnect;

sub equil
{
   (@array)=@_;

   @eq=(0,0,0);

   @df=();

   my $i=0;

   for ($i=0; $i<=$array[0]; $i++)
   {
      push(@df,$array[2+$i]);
   }
   for ($i=0; $i<=$array[0]; $i++)
   {
      push(@df,$array[2+$array[0]+$i]);
   }

   my $n=0;
   if ($array[0] > $array[1])
   {
     $n=$array[1];
   }
   else
   {
     $n=$array[0];
   }

   for ($i=0; $i<$n; $i++)
   {
   #   print "$i $df[$i] $sf[$i]\n";
      if ($df[$i] < $sf[$i]) {goto endloop; }
   }
endloop:

   if ($i == 0)
   {
      return (@eq);
   }
   else
   {
      $eq[0]=$i;
      $eq[1]=$df[$i-1];
      $eq[2]=$sf[$i-1];
      return (@eq);
   }
}

sub doQuery 
{
   my $dbh=shift;
   my ($statement, @args) = @_;

   my $sth = $dbh->prepare($statement);
   $sth->execute(@args);

   return $sth;
}

sub singleQuery 
{
  my $dbh = shift;
  my ($statement, @args) = @_;

  my $sth = $dbh->prepare($statement);
  $sth->execute(@args);

  my $href = $sth->fetchrow_hashref;
  return $href;
}

sub doStatement 
{
  my $dbh=shift;
  my ($statement,
  @args) = @_;

  return $dbh->do($statement, undef, @args);
}		



