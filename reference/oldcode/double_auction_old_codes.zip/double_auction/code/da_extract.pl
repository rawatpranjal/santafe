#!/usr/bin/perl

# code to extract data from double auction database to estimate
# "belief objects" needed by the dynamic programming routine
# John Rust, University of Maryland, June, 2009

$ENV{'PGHOST'} = "beethoven.econ.umd.edu";
$ENV{'PGPORT'} = "5432";
$ENV{'PGSSLMODE'} = "require";

use DBI;

open(OF,">da_transactions.out");

my $dbh=DBI->connect("DBI:Pg:dbname=da","rthenkel","ot9Aihae");

$sth=doQuery($dbh,"select * from games where not(gamestart is null) order by gameid");

$i=0;
$ntp=1;  # number of transactions from the previous period to average to construct starting
         # eprice for periods 2 and higher (for period 1, eprice is set to the prior price pbar
	 # from the priors table)

while ($href=$sth->fetchrow_hashref)
{
  my $priorinfo=singleQuery($dbh,'select  pbar,qbar,numbuyers,numsellers from priors where tokenparameter=?',$href->{randomseed});

  my $nri=singleQuery($dbh,'select max(round) as maxrounds from tokens where gameid=?',$href->{gameid});

  my $nb=singleQuery($dbh,'select count(player) as num from players where gameid=? and player > 0',$href->{gameid});
  $nb=$nb->{num};
  my $ns=singleQuery($dbh,'select count(player) as num from players where gameid=? and player < 0',$href->{gameid});
  $ns=$ns->{num};

  $i++;

  if ($nb != $priorinfo->{numbuyers} || $ns != $priorinfo->{numsellers})
  {
     print "Error: number of buyers in game $href->{gameid} is $nb but in the prior table it is $priorinfo->{numbuyers} (tokenparameter is $href->{randomseed})\n";
     print "Error: number of seller in game $href->{gameid} is $ns but in the prior table it is $priorinfo->{numsellers} (tokenparameter is $href->{randomseed})\n";
     $sth='';
     goto ERRORTERMINATION;
  }

  print "analyzing game $href->{gameid} token generator code=$href->{randomseed}\n";
  print "    $nb buyers  $ns sellers  $nri->{maxrounds} rounds\n";
  print "    prior price: $priorinfo->{pbar} prior quantity: $priorinfo->{qbar}\n";


  for ($round=1; $round<=$nri->{maxrounds}; $round++)
  {
    my $sth1=doQuery($dbh,'select * from tokens where gameid=? and round=? and player > 0 order by value desc',
       $href->{gameid},$round);

    @df=();
    while ($pref=$sth1->fetchrow_hashref)
    {
      push(@df,$pref->{value});
    }

    my $sth1=doQuery($dbh,'select * from tokens where gameid=? and round=? and player < 0 order by value',
       $href->{gameid},$round);
    @sf=();
    while ($pref=$sth1->fetchrow_hashref)
    {
     push(@sf,$pref->{value});
    }

    @eq=equil(@df,@sf,$#sf,$#df); 
    print "    round $round equilibrium size of supply function: $#sf, size of demand function $#df units to be bought, q=$eq[0] pu=$eq[1] pl=$eq[2] total surplus=$eq[3];\n";

    my $check_equil=singleQuery($dbh,'select q,pl,pu from rounds where gameid=? and round=?',$href->{gameid},$round);

    print "         check Rudy's calculation:            q=$check_equil->{q} pu=$check_equil->{pu} pl=$check_equil->{pl}\n";

    $avprice=($eq[1]+$eq[2])/2.0;

    $np=singleQuery($dbh,'select max(period) as maxp from transactions where gameid=? and round=?',$href->{gameid},$round);

    $np=$np->{maxp};

    for ($p=1; $p<=$np; $p++)
    {
#      $sth2=doQuery($dbh,'select distinct time from proposals where gameid=? and round=? and period=? and winner=?  order by time',
#               $href->{gameid},$round,$p,'true');

      $nt=0;
      # in the first period, use the prior price pbar from the priors table, otherwise take the
      # average of the last k transactions in the previous period, where ntp is a parameter to be experimented with

      if ($p > 1)
      {
	 $nt=$#transaction_prices;
	 $sum=0;
	 $ct=0;
	 $lb=$nt-$ntp;
	 if ($lb < -1)
	 {
	      $lb=-1;
         }

	 for ($j=$nt; $j>$lb; $j--)
	 {
	   $ct++;
	   $sum=$sum+$transaction_prices[$j];
	 }

         $eprice=$sum/$ct;  # eprice is the average of the last $ntp transactions in the previous period
      }
      else
      {
        $eprice=$priorinfo->{pbar};  # eprice is the prior price in period 1
      }

      printf("Eprice is %6.3f based on $ct transactions in previous period\n",$eprice,$ct);

      @transaction_prices=();

      $mse_forecast=0;
#      print "bid and ask history: prior expected price is $eprice expected quantity is $priorinfo->{qbar}\n";
#      while ($gref=$sth2->fetchrow_hashref)
      for ($nt=1; $nt<=25; $nt++)
      {
         my $ntrades=singleQuery($dbh,'select count(price) as cnt from transactions where gameid=? and round=? and period=? and time < ?',
               $href->{gameid},$round,$p,$nt);
         my $tslt=0; # time since last trade
         if ($ntrades->{cnt} > 0)
	 {
            my $tslt_ref=singleQuery($dbh,'select max(time) as tslt from transactions where gameid=? and round=? and period=? and time < ?',
               $href->{gameid},$round,$p,$nt);
            $tslt=$nt-$tslt_ref->{tslt};
	 }
	 else
	 {
	    $tslt=-1;
	 }
	 $best_bid=singleQuery($dbh,'select value from proposals where gameid=? and round=? and period=? and winner=?  '.
	           'and player > 0 and time=?',$href->{gameid},$round,$p,'true',$nt);
	 $best_ask=singleQuery($dbh,'select value from proposals where gameid=? and round=? and period=? and winner=?  '.
	           'and player < 0 and time=?',$href->{gameid},$round,$p,'true',$nt);

         $cwt=wt($nt,$ntrades->{cnt},$priorinfo->{qbar},$tslt,25,$best_bid->{value},$best_ask->{value});
	 $eprice=$cwt*avprice($best_bid->{value},$best_ask->{value})+(1.0-$cwt)*$eprice;

	 $mse_forecast=$mse_forecast+($avprice-$eprice)**2;

         print "p=$p t=$nt current bid=$best_bid->{value} current ask=$best_ask->{value} av=".(avprice($best_bid->{value},$best_ask->{value}))."\n";
	 print "   number of trades so far: $ntrades->{cnt} tslt=$tslt wt=$cwt eprice=$eprice avprice=$avprice\n";
      }

      $mse_forecast=sqrt($mse_forecast/25);

      $sth2=doQuery($dbh,'select time,price from transactions where gameid=? and round=? and period=? order by time',
               $href->{gameid},$round,$p);

      $mse_all=0;
      print OF "transaction history\n";
      $nt=0;
      while ($gref=$sth2->fetchrow_hashref)
      {
         $nt++;
  #       print OF "$href->{gameid} $round $p $nt $gref->{time} $gref->{price}\n";
         print "r=$round p=$p t=$gref->{time} tp=$gref->{price}\n";
         $mse_all=$mse_all+($gref->{price}-$avprice)**2;
	 $lastprice=$gref->{price};
	 push(@transaction_prices,$lastprice);
      }
      $mse_all=sqrt($mse_all/$nt);
      $mse_last=sqrt(($lastprice-$avprice)**2);
      print "-------------------- p=$p last=$lastprice avprice=$avprice  mse_last=$mse_last mse_all=$mse_all mse_forecast=$mse_forecast \n\n";
    }

  } 
}

ERRORTERMINATION:

close(OF);
$dbh->disconnect;

sub avprice
{
   my $cbid=shift;
   my $cask=shift;

   if ($cbid && $cask)
   {
      return(($cbid+$cask)/2.0);
   }
   elsif (!$cbid && $cask)
   {
      return $cask;
   }
   elsif ($cbid && !$cask)
   {
      return $cbid;
   }
   else
   {
       return 0;
   }
}

sub wt
{
   my $t=shift;
   my $ntrades=shift;
   my $priortrades=shift;
   my $time_since_last_trade=shift;
   my $total_time_steps=shift;
   my $cbid=shift;
   my $cask=shift;

   my $time_lag_et=int(.15*$total_time_steps);

   if ($ntrades > $priortrades)
   {
#print "\nwt: ntrades=$ntrades priortrades=$priortrades time since last trade $time_since_last_trade time_lag=$time_lag_et\n";
      if ($time_since_last_trade == 1)
      {
        return 0.7;
      }
      elsif ($time_since_last_trade > $time_lag_et)
      {
        return 0.0;
      }
      else
      {
        return (($time_lag_et-$time_since_last_trade+1)/$time_lag_et);
      }
   }
   else
   {
      my $tw=2.0*($t/$total_time_steps);

      if ($tw < .1)
      {
          $tw=0.1;
      }
      my $adj=$ntrades/$priortrades;

      my $bumpfactor=1.0;

      if ($time_since_last_trade == 1)
      {
         $bumpfactor=2.0;
      }

      if ($tw > 1.0)
      {
         $tw=1.0;
      }

      if ($ntrades == 0)
      {
          $adj=1/$priortrades;   
      }
      else
      {
          if ($ntrades > $priortrades)
	  {
	     $adj=1.0;
	  }
      }

      my $rw=$bumpfactor*$tw*$adj;

#print "\nwt: ntrades=$ntrades priortrades=$priortrades time since last trade $time_since_last_trade time_lag=$time_lag_et tw=$tw adj=$adj ".
#            "bump factor: $bumpfactor revised weight $rw\n";

      if ($rw > 1.0)
      {
         $rw=1.0;
      }

      if ($cbid && $cask)
      {
          return $rw;
      }
      elsif (!$cbid && $cask)
      {
          return .25*$rw;
      }
      elsif ($cbid && !$cask)
      {
          return .25*$rw;
      }
      else
      {
         return 0.0;
      }
   }
}

sub equil
{
   my @array=@_;

   my @eq=(0,0,0,0);

   my @df=();
   my @sf=();

   my $sd=pop(@array);
   my $ss=pop(@array);

   my $i=0;
   for ($i=0; $i<=$sd; $i++)
   {
      push(@df,$array[$i]);
      #print "df[$i]=$array[$i]\n";
   }
   for ($i=0; $i<=$ss; $i++)
   {
      push(@sf,$array[$sd+$i+1]);
      #print "sf[$i]=$array[$i+$sd+1]\n";
   }

   my $n=0;
   if ($sd > $ss)
   {
     $n=$ss;
   }
   else
   {
     $n=$sd;
   }

   $i=0;
   while ($df[$i] >= $sf[$i] && $i <= $n)
   {
      $eq[3]=$eq[3]+$df[$i]-$sf[$i];
      #print "$i $df[$i] $sf[$i]\n";
      $i++;
   }

   if ($i == 0)
   {
      return (@eq);
   }
   else
   {
      $eq[0]=$i;
      $eq[1]=$df[$i-1];
      $eq[2]=$sf[$i-1];
      #print "initial guess of equilibrium: n=$eq[0] pu=$eq[1] pl=$eq[2]\n";
      if ($eq[0] <= $ss)
      {
         if ($sf[$eq[0]] < $eq[1])
	 {
	    $eq[1]=$sf[$eq[0]];
	 }
      }
      if ($eq[0] <= $sd)
      {
         if ($df[$eq[0]] > $eq[2])
	 {
	    $eq[2]=$df[$eq[0]];
	 }
      }
      #print "final equilibrium: n=$eq[0] pu=$eq[1] pl=$eq[2]\n";
      return (@eq);
   }
}

sub doQuery 
{
   my $dbh=shift;
   my ($statement, @args) = @_;

   my $sth = $dbh->prepare($statement);
   $sth->execute(@args);

   return $sth;
}

sub singleQuery 
{
  my $dbh = shift;
  my ($statement, @args) = @_;

  my $sth = $dbh->prepare($statement);
  $sth->execute(@args);

  my $href = $sth->fetchrow_hashref;
  return $href;
}

sub doStatement 
{
  my $dbh=shift;
  my ($statement, @args) = @_;

  return $dbh->do($statement, undef, @args);
}		



