public class CGameInitializer {
    private CServerCom myCom;
    private GameHistory history;
    private CGameController myController;

    public CGameInitializer(CGameController c, CServerCom com, GameHistory h) {
	myCom = com;
	history = h;
	myController = c;
    }

    public void init1() {	
	String s = myCom.waitForLine();
	int[] m = myController.parseLine(s);
	if (m[0]==Global.KILLED)
	    myController.gameFailed();
	else {
	    int gameType = m[1];
	    int gameId = m[2];
	    
	    history.setGameParameters(gameType, gameId);
	    
	    s = myCom.waitForLine();
	    m = myController.parseLine(s);
	    int numRounds = m[1];
	    
	    s = myCom.waitForLine();	
	    m = myController.parseLine(s);
	    int numPeriods = m[1];
	    int numTimes = m[2];
	    
	    history.setDuration(numRounds, numPeriods, numTimes);
	    
	    s = myCom.waitForLine();	
	    m = myController.parseLine(s);
	    int maxTokens = m[1];
	    
	    s = myCom.waitForLine();	
	    m = myController.parseLine(s);
	    int maxBuyers = m[1];
	    int maxSellers = m[2];
	    
	    history.setMaximums(maxTokens, maxBuyers, maxSellers);
	    
	    s = myCom.waitForLine();	
	    m = myController.parseLine(s);
	    int role = m[1];
	    int timeout = m[2];
	    
	    history.setMyRole(role);
	    history.setTimeout(timeout);
	    
	    myCom.sendLine(Global.ACCEPT + " " + 7777);
	}
    }

    public void init2() {	
	String s = myCom.waitForLine();
	int[] m = myController.parseLine(s);
	if (m[0]==Global.KILLED)
	    myController.gameFailed();
	else {
	    int numBuyers = m[1];
	    int numSellers = m[2];
	    
	    history.setBuyersSellers(numBuyers, numSellers);
	    for (int x=1;x<=numBuyers;x+=2) {
		s = myCom.waitForLine();
		m = myController.parseLine(s);
		history.addPlayerInfo(x,true,0,m[1],"");
		if ((x+1)<=numBuyers)
		    history.addPlayerInfo(x+1,true,0,m[2],"");
	    }
	    
	    for (int x=1;x<=numSellers;x+=2) {
		s = myCom.waitForLine();
		m = myController.parseLine(s);
		history.addPlayerInfo(x,false,0,m[1],"");
		if ((x+1)<=numSellers)
		    history.addPlayerInfo(x+1,false,0,m[1],"");
	    }
	    
	    s = myCom.waitForLine();
	    m = myController.parseLine(s);
	    int minPrice = m[1]; 
	    int maxPrice = m[2];
	    
	    System.out.println(minPrice + " " + maxPrice);
	    history.setPriceLimits(minPrice, maxPrice);
	    
	    s = myCom.waitForLine(); 
	    m = myController.parseLine(s);
	    int myId = m[1];
	    history.setMyId(myId);
	    
	    if (history.iAmObserver())
		myController.givePlayerMessage("You are an observer of this game.");
	    else if (history.iAmBuyer())
		myController.givePlayerMessage("You are Buyer "+myId+". (B"+myId+")");
	    else
		myController.givePlayerMessage("You are Seller "+myId+". (S"+myId+")");
	    
	    history.determinePlayerColors();

	    myCom.sendLine(Global.READY + " " + myId);
	}
    }
}
