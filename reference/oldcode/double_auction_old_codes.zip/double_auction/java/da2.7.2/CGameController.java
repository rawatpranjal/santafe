import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class CGameController {
    private GameHistory history;
    private CButtonPanel buttonPanel;
    private CTextFrame textFrame;
    private CGameHistoryFrame historyFrame;
    private CPeriodGraph cPeriodGraph;
    private CRoundGraph cRoundGraph;
    private CPeriodGraphFrame periodGraphFrame;
    

    private CGameInitializer gameInitializer;
    private CGameRunner gameRunner;
    private CServerCom myCom;
    private DAClient myClient;
    private int cT, cP, cR;
    private int rolePreference;
    private int timeout;
    private Timer myTimer;
    private int secondsRemaining;

    public CGameController (DAClient c, CServerCom com, int rolePref) {
	rolePreference = rolePref;
	myClient = c;
	myCom = com;
	init0();
    }

    private void init0() {
	myCom.register(this);
	myCom.start();
	history = new GameHistory();
	cT=0;
	cP=0;
	cR=0;
	buttonPanel = new CButtonPanel(this);
	textFrame = new CTextFrame();
	textFrame.givePlayerMessage("Connecting to game...");
    }

    public void receiveMessage(String s) {
	if (s.equals("start")) {
	    gameInitializer = new CGameInitializer(this, myCom, history);
	    gameInitializer.init1();
	    if (gameInitializer!=null)
		gameInitializer.init2();
	    if (gameInitializer!=null) {
		buttonPanel.prepareForGame(history.iAmBuyer());
		gameRunner = new CGameRunner(this, myCom, history);
		gameInitializer = null;
		historyFrame = new CGameHistoryFrame();
		periodGraphFrame = new CPeriodGraphFrame(this);
		periodGraphFrame.setTitle("Running Game # "+history.getGameId());
		timeout = history.getTimeout();
	    }
	}
	else if ( (s.equals("abort")) || (s.equals("nogame")) ) {
	    givePlayerMessage("Game failed to start.");
	    gameFailed();
	}
	else {
	    int[] m = parseLine(s);
	    if (m==null)
		givePlayerMessage(s);
	    else if (m[0]==Global.KILLED)
		gameFailed();
	    else
		gameRunner.receiveMessage(s);
	}
    }

    public void givePlayerMessage(String s) {
	if (textFrame!=null)
	    textFrame.givePlayerMessage(s);
	if (cPeriodGraph!=null)
	    cPeriodGraph.givePlayerMessage(s);
    }

    public void newRound() {
	cR++;
	cP=0;
    }

    public void newPeriod() {
	cT=0;
	cP++;
	cPeriodGraph = new CPeriodGraph(buttonPanel, periodGraphFrame, history);
	periodGraphFrame.changePeriodGraph(cPeriodGraph);
	cPeriodGraph.repaint();
    }
    
    public void endPeriod() {
	cPeriodGraph.finishGraph();
	historyFrame.addPeriodGraph(cPeriodGraph);
    }

    public void endRound() {
	cRoundGraph = new CRoundGraph(history);
	historyFrame.addRoundGraph(cRoundGraph);
	cRoundGraph.repaint();
    }

    public void propositionStep(boolean a) {
	if (a) {
	    stopTimer();
	    setTimer();
	}
	cT++;
	buttonPanel.propositionStep(a);
    }

    public void transactionStep(boolean a) {
	if (a) {
	    stopTimer();
	    setTimer();
	}
	buttonPanel.transactionStep(a);
    }

    private void setTimer() {
	int delay = 1000;
	secondsRemaining = timeout;
	tickDown();
	ActionListener ticker = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    tickDown();
		}
	    };
	myTimer = new Timer(delay,ticker);
	myTimer.start();
    }

    private void tickDown() {
	secondsRemaining--;
	if (secondsRemaining==0) {
	    givePlayerMessage("You ran out of time.");
	    buttonPanel.noneButtonPressed();
	}
	cPeriodGraph.updateTimer(secondsRemaining, ((double)secondsRemaining/(double)(timeout-1)));
    }
    
    // Updates the graphs through time t
    public void updateGraph(int t, boolean projectTokenValues) {
	cPeriodGraph.update(t, projectTokenValues);
    }

    public void acceptTransaction(boolean a) {
	stopTimer();
	gameRunner.acceptTransaction(a);
    }

    public boolean propose(int p) {
	boolean result = gameRunner.propose(p);
        if (result) stopTimer();
	return result;
    }


    public void gameFinished() {
	historyFrame.setSize(700,700);
	historyFrame.setLocation(450,0);
	periodGraphFrame.dispose();
	periodGraphFrame=null;
	givePlayerMessage("The game has finished successfully.  Thanks for playing!");
	stopRunning();
	buttonPanel.finish();
    }

   public void selectQuitTerminal() {
        stopTimer();
	stopRunning();
	myCom.sendLine(Global.QUIT+" 0");

	if (textFrame!=null) {
	    textFrame.dispose();
	    textFrame=null;
	}
	if (periodGraphFrame!=null) {
	    periodGraphFrame.dispose();
	    periodGraphFrame=null;
	}
	if (historyFrame!=null) {
	    historyFrame.dispose();
	    historyFrame=null;
	}
	myClient.selectGameFinished();
    }

    private void stopTimer() {
	if (myTimer != null)
	    myTimer.stop();
    }

    public void gameFailed() {
	givePlayerMessage("Game was terminated unexpectedly.");
	stopRunning();
	buttonPanel.finish();
    }

    private void stopRunning() {
	if (myCom!=null)
	    myCom.stopListening();
	gameRunner=null;
	gameInitializer=null;
    }


    // Parses a string into its component integers.
    public int[] parseLine(String m) {       
	String s = m.trim();
	if (!isDigit(s.charAt(0)))
	    return null;
	int[] result = new int[3];
	result[0] = getNthInt(1,s);
	result[1] = getNthInt(2,s);
	result[2] = getNthInt(3,s);
	return result;
    }

    private int getNthInt(int n, String s) {
	int count=1, x=0, y=0;
	while (count != n) {
	    while (isDigit(s.charAt(x))) x++;
	    while (!isDigit(s.charAt(x))) x++;
	    count++;
	}
	y=x;
	while ((y<(s.length()))&&(isDigit(s.charAt(y)))) y++;
	String t = s.substring(x,y);
	return Integer.parseInt(t);
    }

    private boolean isDigit(char c) {
	if ((c>='0')&&(c<='9'))
	    return true;
	else
	    return false;
    }
    
    public void toggleTextFrame() {
	textFrame.setVisible(!textFrame.isVisible());
    }

    public void toggleHistoryFrame() {
	historyFrame.setVisible(!historyFrame.isVisible());
    }
}
	
