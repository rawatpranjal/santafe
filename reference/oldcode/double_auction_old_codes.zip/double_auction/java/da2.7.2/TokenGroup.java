public class TokenGroup {
    private boolean isBuyer;
    
    private int numTokens;
    
    private int currentToken; // Used during creation
    
    private int[] tokenValues;

    public TokenGroup(int nT, boolean buyer) {
	isBuyer = buyer;
	numTokens = nT;
	currentToken=0;
	tokenValues = new int[numTokens+1];
    }

    public int getTokenValue(int t) {
	if ((t>0)&&(t<=numTokens))
	    return tokenValues[t];
	return -1;
    }

    public void addTokenValue(int v) {
	currentToken++;
	tokenValues[currentToken]=v;
    }

    public String getTokenString(int numTokensTraded) {
	String s="";
	for (int x=1;x<=numTokensTraded;x++)
	    s = s + "- ";
	for (int x=numTokensTraded+1;x<=numTokens;x++)
	    s = s + (tokenValues[x] + " ");
	return s;
    }

    public int getNumTokens() { return numTokens; }
    
    // Returns the maximum profit obtainable from this TokenGroup given a competitive equilibrium price
    // of eqPrice.
    public int getMaxProfit(int eqPrice) {
	int profit=0;
	int x=1;
	if (isBuyer)
	    while ((x<=numTokens)&&(tokenValues[x]>eqPrice)) {
		profit+=(tokenValues[x]-eqPrice);
		x++;
	    }
	else
	    while ((x<=numTokens)&&(tokenValues[x]<eqPrice)) {
		profit+=(eqPrice-tokenValues[x]);
		x++;
	    }
	return profit;
    }
		    
	
}
	    
