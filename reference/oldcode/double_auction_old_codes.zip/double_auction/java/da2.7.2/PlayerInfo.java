import java.awt.*;

public class PlayerInfo {
    private int type;    // 1=Human using Applet, 2=Robot
    private int number;  // Player number, assigned to a given person, invariant between games.
    private String userId; // userId corresponding to playerNumber
    private Color color;   // The color corresponding to a player for a given game.

    public PlayerInfo(int t, int n, String u) {
	type = t;
	number = n;
	userId=u;
    }

    public void setColor(Color c) { color = c; }

    public Color getColor() { return color; }

    public void setNumber(int n) { number = n; }

    public int getNumber() { return number; }

    public void setUserId(String u) { userId = u; }

    public String getUserId() { return userId; }

    public void setType(int t) { type = t; }

    public int getType() { return type; }
	
}
