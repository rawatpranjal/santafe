import java.util.*;
import java.awt.*;

public class GameHistory {
    private String gameName; // Game name, optional
    private int gameId; // Game ID, assigned by dmon
    private int gameType;

    private PlayerInfo[] buyerInfo;
    private PlayerInfo[] sellerInfo;

    private int timeout; 
    
    private int numBuyers;
    private int numSellers;

    private int numRounds;
    private int numPeriods;
    private int numTimes;

    private RoundHistory[] round;
    private int currentRound;

    private int maxPrice;
    private int minPrice;

    private int maxBuyers;
    private int maxSellers;

    // Used by client side GameHistory objects
    private int myId;
    private boolean iAmBuyer;
    private boolean iAmObserver=false;

    private int minTokens;
    private int maxTokens;

    private int[] buyerProfit;
    private int[] sellerProfit;
    private int totalProfit;

    private int[] buyerEff;
    private int[] sellerEff;
    private int totalEff;

    // INITIALIZATION-1

    public GameHistory() {
	gameName = "DefaultGame";
    }
    
    public void setGameParameters(int t, int i) {
	gameType=t;
	gameId = i;
    }

    public void setDuration(int r, int p, int t) {
	numRounds = r;
	numPeriods = p;
	numTimes = t;
	round = new RoundHistory[numRounds+1];
	currentRound=0;
	}

    public void setMaximums(int t, int b, int s) {
	maxBuyers = b;
	maxSellers = s;
	maxTokens = t;
    }

    public void setMyRole(int role) {
	if (role==1)
	    iAmBuyer=true;
	else if (role==2)
	    iAmBuyer=false;
	else if (role==4)
	    iAmObserver=true;
    }

    public void setTimeout(int t) {
	timeout = t;
    }


    // INITIALIZATION-2

    public void setBuyersSellers(int b, int s) {
	numBuyers = b;
	buyerInfo = new PlayerInfo[b+1];
	numSellers = s;
	sellerInfo = new PlayerInfo[s+1];
	buyerProfit = new int[b+1];
	sellerProfit = new int[s+1];
	buyerEff = new int[b+1];
	sellerEff = new int[s+1];
    }

    public void addPlayerInfo(int i, boolean isBuyer, int type, int playerNumber, String userId) {
	if (isBuyer)
	    buyerInfo[i] = new PlayerInfo(type, playerNumber, userId);
	else
	    sellerInfo[i] = new PlayerInfo(type, playerNumber, userId);
    }

    public void setPriceLimits(int min, int max) {
	minPrice = min;
	maxPrice = max;
    }

    public void setMyId(int i) {
	myId=i;
    }

    public void setTokenLimits(int min, int max) { minTokens = min; maxTokens=max; }

    public int getMinTokens() { return minTokens; }

    public int getMaxTokens() { return maxTokens; }

    public int getNumBuyers() { return numBuyers; }

    public int getNumSellers() { return numSellers; }

    // Returns a random number between minTokens and maxTokens
    public int generateNumberTokens() {
	Random rGen = new Random();
	int dif = maxTokens-minTokens;
	return rGen.nextInt(dif+1) + minTokens;
    }
	
    public boolean incrementRound() {
	if (currentRound>0) {
	    for (int x=1;x<=numBuyers;x++)
		buyerProfit[x]+=round[currentRound].getProfit(true, x);
	    for (int x=1;x<=numSellers;x++)
		sellerProfit[x]+=round[currentRound].getProfit(false, x);
	}
	currentRound++;
	if (currentRound>numRounds)
	    return false;
	RoundHistory r = new RoundHistory(currentRound, numPeriods, numTimes, numBuyers, numSellers, maxPrice, minPrice, myId, generateNumberTokens(), iAmBuyer);
	round[currentRound] = r;
	return true;
	}

    public RoundHistory getCurrentRound() {
	return round[currentRound];
	}

    public String getName(){ return gameName; }

    public int getGameId() { return gameId; }

    public int getGameType() { return gameType; }

    public String getGameName() { return gameName; }
    
    public int getTimeout() { return timeout; }

    public int getMyId() { return myId; }
    
    public boolean iAmBuyer() { return iAmBuyer; }

    public boolean iAmObserver() { return iAmObserver; }

    public void setMyEfficiency(int e) {
	if (iAmBuyer)
	    buyerEff[myId]=e;
	else
	    sellerEff[myId]=e;
    }

    public int getMyEfficiency() {
	if (iAmBuyer)
	    return buyerEff[myId];
	else
	    return sellerEff[myId];
    }

    public int getMyProfit() {
	if (iAmBuyer)
	    return buyerProfit[myId];
	else
	    return sellerProfit[myId];
    }

    public int getProfit(boolean buyer, int i) {
	if (buyer)
	    return buyerProfit[i];
	else
	    return sellerProfit[i];
    }

    public int getEfficiency(boolean buyer, int i) {
	if (buyer)
	    return buyerEff[i];
	else
	    return sellerEff[i];
    }

   public int getTotalProfit() { return totalProfit; }

    public int getTotalEfficiency() { return totalEff; }


    public void calculateEfficiencies() {
	totalProfit = 0;
	totalEff = 0;
	for (int x=1;x<=numRounds;x++) {
	    totalProfit+=round[x].getTotalProfit();
	    totalEff +=round[x].getTotalEfficiency();
	}
	totalEff = totalEff/numRounds;
	for (int x=1;x<=numBuyers;x++) {
	    int sum=0;
	    for (int y=1;y<=numRounds;y++)
		sum+=round[y].getEfficiency(true, x);
	    buyerEff[x] = sum/numRounds;
	}
	for (int x=1;x<=numSellers;x++) {
	    int sum=0;
	    for (int y=1;y<=numRounds;y++)
		sum+=round[y].getEfficiency(false, x);
	    sellerEff[x] = sum/numRounds;
	}
    }

    public void determinePlayerColors() {
	// If the player is a buyer, then other buyers are done in reddish shades,
	// and sellers are done in greenish shades.  Visa versa if the player is a
	// seller.  The player themself is always blue.
	int sR, sG, bR, bG, sBI, bBI;
	int nB = numBuyers;
	int nS = numSellers;
	if (myId>0) {
	    if (iAmBuyer) nB--;
	    else nS--;
	}
	int b1 = (int)(Math.sqrt(nB));
	int s1 = (int)(Math.sqrt(nS));
	int b2 = b1;
	int s2 = s1;
	System.out.println(b1+" "+b2+" "+s1+" "+s2);
	if ((b1*b2)<nB)
	    b2++;
	if ((b1*b2)<nB)
	    b1++;
	if ((s1*s2)<nS)
	    s2++;
	if ((s1*s2)<nS)
	    s1++;
	System.out.println(b1+" "+b2+" "+s1+" "+s2);
	// Buyers
	int numColored=0;
	for (int x=1;x<=numBuyers;x++) {
	    if ((iAmBuyer)&&(myId==x))
		buyerInfo[x].setColor(new Color(200,200,0));
	    else {
		int i1 = numColored/b2;
		int i2 = (numColored-b2*i1);
		int otherColor = 255 - 255*i1/b1;
		int blueColor;
		if (b2==1)
		    blueColor = 0;
		else
		    blueColor = 255*(i2)/(b2-1);
		if (iAmBuyer) {
		    System.out.println("Buyer "+x+": "+otherColor+", "+0+", "+blueColor+".");
		    buyerInfo[x].setColor(new Color(otherColor, 0, blueColor));
		}
		else {
		    System.out.println("Buyer "+x+": "+0+", "+otherColor+", "+blueColor+".");
		    buyerInfo[x].setColor(new Color(0,otherColor,blueColor));
		}
		numColored++;
	    }
	}
	// Sellers
	numColored=0;
	for (int x=1;x<=numSellers;x++) {
	    if ((!iAmBuyer)&&(myId==x))
		sellerInfo[x].setColor(new Color(200,200,0));
	    else {
		int i1 = numColored/s2;
		int i2 = (numColored-s2*i1);
		int otherColor = 255 - 255*i1/s1;
		int blueColor;
		if (s2==1)
		    blueColor=0;
		else
		    blueColor = 255*(i2)/(s2-1);
		if (iAmBuyer) {
		    System.out.println("Seller "+x+": "+0+", "+otherColor+", "+blueColor+".");
		    sellerInfo[x].setColor(new Color(0, otherColor, blueColor));
		}
		else {
		    System.out.println("Seller "+x+": "+otherColor+", "+0+", "+blueColor+".");
		    sellerInfo[x].setColor(new Color(otherColor,0,blueColor));
		}
		numColored++;
	    }
	}
    }   

    public Color getPlayerColor(int i, boolean isBuyer) {
	if (isBuyer)
	    return buyerInfo[i].getColor();
	else
	    return sellerInfo[i].getColor();
    } 
}
