import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

// This handles the interface buttons.
public class CButtonPanel extends JPanel implements ActionListener {
    private QuitFrame quitFrame;
    private JButton propositionButton, quitButton, transactionConfirmButton, noneButton;
    private CGameController myController;
    private boolean iAmBuyer;
    private JTextField propositionEntry;
    
    public CButtonPanel(CGameController c) {
	myController = c;
	setup();
    }
    
    private void setup() {
	setupPropositionEntry();
	setupPrimaryButtons();
	addComponents();
	setupAppearance();

	quitFrame = new QuitFrame();
    }

    private void setupAppearance() {
	setVisible(true);
	setOpaque(false);
    }
    
    private void addComponents() {
	add(propositionEntry);
	add(propositionButton);
	add(noneButton);
	noneButton.setPreferredSize(new Dimension(70,25));
	add(transactionConfirmButton);
	add(quitButton);
    }

    private void setupPropositionEntry() {
	propositionEntry = new JTextField(4);

	propositionEntry.addKeyListener(new KeyAdapter() {
		public void keyPressed(KeyEvent e) {
		    if ( e.getKeyCode() == KeyEvent.VK_ENTER)
			if (propositionButton.isEnabled())
			    propositionButton.doClick();
		}
	    });
	propositionEntry.setAlignmentY(0.0f);
    }

    private void setupPrimaryButtons() {
	propositionButton = new JButton("Ask");
	propositionButton.addActionListener(this);
	propositionButton.setEnabled(false);
	propositionButton.setAlignmentY(0.0f);

	transactionConfirmButton = new JButton("Yes");
	transactionConfirmButton.addActionListener(this);
        transactionConfirmButton.setEnabled(false);
	transactionConfirmButton.setAlignmentY(0.0f);

	noneButton = new JButton("None");
        noneButton.addActionListener(this);
	noneButton.setEnabled(false);
	noneButton.setAlignmentY(0.0f);
	

	quitButton = new JButton("Quit");
	quitButton.addActionListener(this);
	quitButton.setEnabled(true);
	quitButton.setAlignmentY(0.0f);
    }
    
    private void setButtonText(boolean isBuyer) {
	if (isBuyer)
	    propositionButton.setText("Bid");
	else
	    propositionButton.setText("Ask");
    }

    public void prepareForGame(boolean isBuyer) {
	setButtonText(isBuyer);
    }

    // secs is seconds the player has to make a choice before default response
    public void propositionStep(boolean allowProposition) {
	transactionConfirmButton.setEnabled(false);
	noneButton.setEnabled(allowProposition);
	noneButton.setText("None");
	propositionButton.setEnabled(allowProposition);
    }

    // secs is seconds the player has to make a choice before default response
    public void transactionStep(boolean allowTransaction) {
	transactionConfirmButton.setEnabled(allowTransaction);
	noneButton.setEnabled(allowTransaction);
	noneButton.setText("No");
	propositionButton.setEnabled(false);
    }

    public void quit( boolean quitConfirm ) {
	if (quitConfirm)
	    myController.selectQuitTerminal();
	else
	    setVisible(true);
    }

    public void finish() {
	propositionButton.setEnabled(false);
	noneButton.setEnabled(false);
	transactionConfirmButton.setEnabled(false);
	quitButton.setEnabled(true);
    }

    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if (source==quitButton)
	    quitButtonPressed();
	else if (source==noneButton)
	    noneButtonPressed();
	else if (source==transactionConfirmButton)
	    transactionConfirmButtonPressed();
	else if (source==propositionButton)
	    propositionButtonPressed();
    }

    private void quitButtonPressed() {
	setVisible(false);
	quitFrame.setVisible(true);
    }

    public void noneButtonPressed() {
	quitButton.setEnabled(false);
	if (noneButton.getText().equals("None")) {
	    myController.propose(0);
	    noneButton.setEnabled(false);
	    propositionButton.setEnabled(false);  
	}
	else {
	    myController.acceptTransaction(false);
	    transactionConfirmButton.setEnabled(false);
	    noneButton.setEnabled(false);
	}
	quitButton.setEnabled(true);
    }
    
    private void transactionConfirmButtonPressed() {
	quitButton.setEnabled(false);
	myController.acceptTransaction(true);
	noneButton.setEnabled(false);
	transactionConfirmButton.setEnabled(false);
	quitButton.setEnabled(true);
    }

    private void propositionButtonPressed() {
	quitButton.setEnabled(false);
	String amount = propositionEntry.getText().trim();
	propositionEntry.setText("");
	if (stringIsPositiveInteger(amount))
	    if (myController.propose(Integer.parseInt(amount))) {
		propositionButton.setEnabled(false);
		noneButton.setEnabled(false);
		}
	    else {
		myController.givePlayerMessage("Sorry, but the amount you entered was not acceptable. Make sure that you are beating last round's best proposal, and that you are within the allowed price range.");
	    }
	else
	    myController.givePlayerMessage("Bids must be positive integers.");
	quitButton.setEnabled(true);
    }

    public boolean stringIsPositiveInteger(String s) {
	int currentBid;
	try {
	    currentBid = Integer.parseInt(s);
	} catch (NumberFormatException e) { return false; }
	if (currentBid <= 0)
	    return false;
	return true;
    }

    private class QuitFrame extends JFrame implements ActionListener {
	JButton yesButton, noButton;
	boolean quit = false;

	public QuitFrame() {
		super("Quit this game?");
		yesButton = new JButton("Yes");
		noButton = new JButton("No");
		yesButton.addActionListener(this);
		noButton.addActionListener(this);
		getContentPane().setLayout(new FlowLayout());
		getContentPane().add(yesButton);
		getContentPane().add(noButton);		
		setSize(210,80);
		setLocationRelativeTo(null);
 		setVisible(false);
	}

	public void actionPerformed(ActionEvent event){
	    Object source = event.getSource();
	    if (source==yesButton) {
		setVisible(false);
		quit(true);
	    }
	    else if (source==noButton) {
		setVisible(false);
		quit(false);
	    }
	}
    }

    public void setOffer(int offer) {
	if (propositionButton.isEnabled()) {
	    propositionEntry.setText(offer+"");
	    propositionEntry.selectAll();
	    propositionEntry.grabFocus();
	}
    }

    public void submitOffer() {
	if (propositionButton.isEnabled())
	    propositionButton.doClick();
    }
	
}
