import java.util.*;

// ExampleRobot
// playerNumber = 0001
public class SRobotExample extends SRobotSkeleton {

    public final static String robotType = "ExampleRobot";
    public final static int robotNum = 1;
    public final static int rolePref = 3;

    public SRobotExample() {
	super(robotType, robotNum, rolePref);
    } 

    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {}

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {}

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {
	int most, newbid;
	double alpha;
	
	if (nobidask>0) return 0;	/* nothing left to trade */
	
	alpha = 0.25 + 0.1*drand();
	if (cbid == 0) {
	    most = token[ntokens]-1;
	    if (cask>0 && cask<most) most = cask;
	    newbid = most - (int) (alpha*(token[1]-token[ntokens]));
	}
	else {
	    most = token[mytrades+1]-1;
	    if (cask>0 && cask<most) most = cask;
	    if (most <= cbid) return 0;
	    newbid = (int) ((1.0-alpha)*(cbid+1) + alpha*most + 0.001);
	}
	
	return ((newbid<minprice)? minprice : newbid);
    }

    public int playerRequestAsk() {
	int least, newask;
	double alpha;
	
	if (nobidask>0) return 0;	/* nothing left to trade */
	
	alpha = 0.25 + 0.1*drand();
	if (cask == 0) {
	    least = token[ntokens]+1;
	    if (cbid > least) least = cbid;
	    newask = least + (int) (alpha*(token[ntokens]-token[1]));
	}
	else {
	    least = token[mytrades+1]+1;
	    if (cbid > least) least = cbid;
	    if (least >= cask) return 0;
	    newask = (int) ((1.0-alpha)*(cask-1) + alpha*least + 0.001);
	}
	
	return ((newask>maxprice)? maxprice : newask);
    }
    
    public int playerRequestBuy() {
	double target, alpha;
    
	if (nobuysell>0) return 0;
	if (token[mytrades+1] <= cask) return 0;	/* don't buy at a loss! */
	if (id==bidder && cbid >= cask ) return 1;	/* accept offer <= our bid */
    
	target = 1.3*token[ntokens] - 0.3*token[1];
	alpha = 1.0/((double)(t-lasttime));
	if (cask < (int)(alpha*target + (1.0-alpha)*token[mytrades+1]))
	    return 1;
	else
	    return 0;
    }

    public int playerWantToSell() {
		double target,alpha;

	if (nobuysell>0) return 0;
	if (cbid <= token[mytrades+1]) return 0;	/* don't sell at a loss! */
	if (id==asker && cask<=cbid) return 1;	/* accept bid >= our offer */
	
	target = 1.3*token[ntokens] - 0.3*token[1];
	alpha = 1.0/((double)(t-lasttime));
	if (cbid > (int)(alpha*target + (1.0-alpha)*token[mytrades+1]))
	    return 1;
	else
	    return 0;
    } 


}
