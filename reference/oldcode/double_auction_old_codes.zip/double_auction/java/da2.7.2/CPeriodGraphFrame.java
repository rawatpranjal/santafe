import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class CPeriodGraphFrame extends JFrame implements MouseListener {
    private CPeriodGraph myGraph;
    private CGameController myController;
    private CGameMenuBar myMenus;

    public CPeriodGraphFrame(CGameController myControl) {
	super();
	setSize(800,550);
	setLocation(450,0);
	getContentPane().setLayout(new BorderLayout());
	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	myController = myControl;
	setupMenuBar();
    }

    public void changePeriodGraph(CPeriodGraph graph) {
	if (myGraph!=null) {
	    myGraph.removeMouseListener(this);
	    remove(myGraph);
	}
	myGraph = graph;
	setVisible(true);
	getContentPane().add("Center",myGraph);
	
	myGraph.addMouseListener(this);
    }

    private void setupMenuBar() {
	myMenus = new CGameMenuBar(myController);
	setJMenuBar(myMenus);
    }

    public void mouseClicked(MouseEvent e) {
	if (myGraph!=null)
	    myGraph.pointClicked(e.getX(), e.getY(), e.getClickCount());
    }
	
    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }
    
    public void mousePressed(MouseEvent e) {
	
    }

    public void mouseReleased(MouseEvent e) {

    }

}
	
