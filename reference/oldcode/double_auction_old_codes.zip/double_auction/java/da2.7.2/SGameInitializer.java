import java.util.*;

public class SGameInitializer extends Thread {

    // Players who have expressed desire to join the game
    private ArrayList<SPlayer> potentialPlayers;
    private SGameHandler myHandler;

    private String creatorId;
    private int gameId;
    private int timeout;
    private int minHumanPlayers;
    private int maxHumanPlayers;
    private int numRobots;
    private long creationTime;
    private int minSecondsToWait;
    private int maxSecondsToWait;
    private int secondsTilStart;
    private String idString;
    private String[] statusString;
    private String status;
    private int confirmedPlayers;
    private int numObservers;
    private int numRounds;
    private int numPeriods;
    private int numTimes;
    private int maxBuyers;
    private int maxSellers;
    private int minTokens;
    private int maxTokens;
    private int minPrice;
    private int maxPrice;

    private int numBuyers;
    private int numSellers;
    private int gameType;

    private int[] buyerPlayerNumbers;
    private int[] sellerPlayerNumbers;

    private STokenGenerator myTokenGenerator;
    

    public SGameInitializer(SGameHandler myH, SPlayerCom creator, int gId, int t, int minWaitTime, int maxWaitTime, int minH, int maxH, ArrayList<SPlayer> robots, int numR, int numP, int numT, int maxB, int maxS, int maxT, int minP, int maxP, int minTok, int maxTok, STokenGenerator myTG, int gType) {
	myHandler = myH;
	creatorId = creator.getUser();
	gameId = gId;
	timeout=t;
	minSecondsToWait = minWaitTime;
	maxSecondsToWait = maxWaitTime;
	secondsTilStart=maxWaitTime;
	creationTime = System.currentTimeMillis();
	minHumanPlayers = minH;
	maxHumanPlayers = maxH;
	potentialPlayers = robots;
	numRobots = robots.size();
	status = "WAITING";
	confirmedPlayers=0;
	numRounds = numR;
	numPeriods = numP;
	numTimes = numT;
	makeStatusString();
	maxBuyers = maxB;
	maxSellers = maxS;
	minTokens = minTok;
	maxTokens = maxTok;
	maxPrice=maxP;
	minPrice=minP;


	numBuyers=0;
	numSellers=0;

	myTokenGenerator=myTG;

	gameType = gType;
    }

    private void makeStatusString() {
	statusString = new String[8];
	statusString[0]=gameId+"";
	statusString[1]=creatorId;
	statusString[2]=secondsTilStart+"";
	statusString[3]=minHumanPlayers+"";
	statusString[4]=maxHumanPlayers+"";
	statusString[5]=numRobots+"";
	statusString[6]=confirmedPlayers+"";
	statusString[7]=status;
    }

    public String[] getStatusString() {
	makeStatusString();
	return statusString;
    }

    public boolean addPlayer(SPlayerCom pCom) {
	synchronized (potentialPlayers) {
	    int rolePreference = Integer.parseInt(pCom.waitForLine());
	    if (rolePreference!=4) {
		if (!status.equals("WAITING"))
		    return false;
		if ((confirmedPlayers)>=maxHumanPlayers)
		    return false;
	    }
	    pCom.sendLine("join");
	    SPlayer aPlayer;
	    System.out.println(rolePreference+" ");
	    if (rolePreference==4) {
		aPlayer = new SObserverPlayer(pCom);
		numObservers++;
	    }
	    else {
		aPlayer = new SSocketPlayer(pCom, rolePreference);
		confirmedPlayers++;
	    }
	    potentialPlayers.add(aPlayer);
	}
	System.out.println(pCom.getUser() +" has asked to join Game "+gameId);
	return true;
    }

    public void run() {
	waitForBegin();
	setStatusInitialization();
	if (verify1()) {
	    determineRoles();
	    initialize1();  
	    if (verify2()) {
		assignIds();
		initialize2();
		createGameRunner();
	    }
	}
    }

    private void waitForBegin() {
	while (secondsTilStart>0) {
	    synchronized (potentialPlayers) {
		Iterator pIterator = potentialPlayers.iterator();
		while (pIterator.hasNext()) {
		    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
		    String message = aPlayer.getLine();
		    if (!message.equals("")) {
			if (message.equals(Global.QUIT+" 0")) {
			    pIterator.remove();
			    myHandler.takePlayer(aPlayer.getPlayerCom());
			    if (aPlayer.getType()==4)
				numObservers--;
			    else
				confirmedPlayers--;
			}
		    }
		}   
		secondsTilStart = maxSecondsToWait - (int)((System.currentTimeMillis()-creationTime)/1000);
		if (confirmedPlayers==maxHumanPlayers)
		    secondsTilStart = minSecondsToWait - (int)((System.currentTimeMillis()-creationTime)/1000);
		if (secondsTilStart<0)
		    secondsTilStart=0;
	    }
	    try { sleep(200); } catch (InterruptedException e) {}
	}
    }

    private boolean verify1() {
	if (confirmedPlayers>=minHumanPlayers) {
	    System.out.println("Game "+gameId+" is starting now...");
	    return true;
	}
	else {
	    System.out.println("Game "+gameId+" stopped for lack of Players");
	    status = "FAILED";
	    return false;
	}
    }

    private void determineRoles() {
	Iterator pIterator = potentialPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    int pref = aPlayer.getRolePreference();
	    if (pref==1) {
		numBuyers++;
		aPlayer.setIsBuyer(true);
	    }
	    else if (pref==2) {
		numSellers++;
		aPlayer.setIsBuyer(false);
	    }
	}
	pIterator = potentialPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    int pref = aPlayer.getRolePreference();
	    if (pref==3) {
		if (numSellers<numBuyers) {
		    numSellers++;
		    aPlayer.setIsBuyer(false);
		}
		else {
		    numBuyers++;
		    aPlayer.setIsBuyer(true);
		}
	    }
	}
    }

    private void initialize1() {
	Iterator pIterator = potentialPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    int role;
	    if (aPlayer.getType()==4)
		role = 4;
	    else if (aPlayer.isBuyer())
		role = 1;
	    else
		role = 2;
	    if (aPlayer.initialization1(gameType, gameId, numRounds, numPeriods, numTimes, maxTokens, maxBuyers, maxSellers, role, timeout)) {	
		System.out.println(aPlayer.getUserId()+" accepted to join game#"+gameId);
	    }
	    else {
		System.out.println("Error! "+aPlayer.getUserId()+" refused to join game#"+gameId);
		pIterator.remove();
		if (aPlayer.getType()==4)
		    numObservers--;
		else
		    confirmedPlayers--;
		if (aPlayer.isBuyer())
		    numBuyers--;
		else
		    numSellers--;
	    }
	}
    }

    private boolean verify2() {
	return true;
	// Add in other stuff to ensure the conditions of the game are met.
    }
    
    // This needs to be randomized, so that robots do not always have the lowest ids.
    private void assignIds() {
	buyerPlayerNumbers = new int[numBuyers+1];
	sellerPlayerNumbers = new int[numSellers+1];
	int bCount=0;
	int sCount=0;
	Iterator pIterator = potentialPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    if (aPlayer.getRolePreference()!=4) {
		if (aPlayer.isBuyer()) {
		    bCount++;
		    buyerPlayerNumbers[bCount]=aPlayer.getPlayerNumber();
		    aPlayer.setId(bCount);
		}
		else {
		    sCount++;
		    sellerPlayerNumbers[sCount]=aPlayer.getPlayerNumber();
		    aPlayer.setId(sCount);
		}
	    }
	}
	if ((bCount!=numBuyers)||(sCount!=numSellers)) {
	    System.out.println("Error!  COUNTS DON'T MATCH");
	}
    }

   private void initialize2() {
	Iterator pIterator = potentialPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    if (aPlayer.initialization2(numBuyers, numSellers, buyerPlayerNumbers, sellerPlayerNumbers, minPrice, maxPrice, aPlayer.getId())) {
		System.out.println(aPlayer.getUserId()+" is ready to play the game!");
	    }
	    else {
		System.out.println("Error! "+aPlayer.getUserId()+" failed to be ready!");
		pIterator.remove();
		if (aPlayer.getType()==4)
		    numObservers--;
		else
		    confirmedPlayers--;
	    }
	}
    }

    private void createGameRunner() { 
	GameHistory history = new GameHistory();
	history.setGameParameters(gameType,gameId);
	history.setDuration(numRounds, numPeriods, numTimes);
	history.setMaximums(maxBuyers, maxSellers, maxTokens);
	history.setTimeout(timeout);
	history.setBuyersSellers(numBuyers, numSellers);
	history.setPriceLimits(minPrice, maxPrice);
	history.setTokenLimits(minTokens, maxTokens);
	Iterator pIterator = potentialPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    history.addPlayerInfo(aPlayer.getId(), aPlayer.isBuyer(), aPlayer.getType(), aPlayer.getPlayerNumber(), aPlayer.getUserId());
	}
	status = "RUNNING";
	System.out.println("Game is starting with "+(potentialPlayers.size()-numObservers)+" players!");
	SGameRunner myRunner = new SGameRunner(this, myHandler, history, potentialPlayers, myTokenGenerator);
	myRunner.start();
    }

    public int getGameId() { return gameId; }

    public void setStatus(String s) { status = s; }

    public String getStatus() { return status; }

    private void setStatusInitialization() {
	status = "INITIALIZATION";
	secondsTilStart=0;
    }
}
