import java.util.*;

// SRobotLin
// playerNumber = 0005
public class SRobotLin extends SRobotSkeleton {

    public final static String robotType = "SRobotLin";
    public final static int robotNum = 5;
    public final static int rolePref = 3;

    public SRobotLin () {
	super(robotType, robotNum, rolePref);
    } 

    private int [] mean_price;




    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {
	mean_price = new int [nperiods+1];
}

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {}

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {
	
	int most, newbid;
	double mean, err, target, weight;

	if (nobidask>0) return 0;	        /* nothing left to trade */
	most = token[mytrades+1] - 1;       /* upper limit of bids */
	if (cbid>=most) return 0; 		/* no more profit to bid */
	/*    if (coffer>0 && coffer<most) most = coffer; */

	mean = get_target_price();
	err = get_stderr_price();	/* get std err of current prices */
	target = norm(mean, err);

	if (cbid > 0 && cbid > target) target = cbid + 1;
	if (target <= 0.0 || target > most) target = most;

	weight = (double) ( ((ntimes-t+1)/ntimes) * ((ntokens-mytrades)/ntokens) * (nsellers/nplayers) );

	if (cbid > 0)
	newbid = (int)(weight*(cbid+1)+(1.0-weight)*target);
	else
	newbid = (int)(weight*(token[ntokens]-1)+(1.0-weight)*target);

	return ((newbid<minprice)? minprice : newbid);
    }

    public int playerRequestAsk() {

	int least, newoffer;
	double mean, err, target, weight;

	if (nobidask>0) return 0;	      /* nothing left to trade */
	least = token[mytrades+1]+1;      /* lower limit of trade */
	if (cask>0 && cask<=least) return 0; /* no more profit to offer */
	/*    if (cbid>least) least = cbid;  */

	mean = get_target_price();
	err = get_stderr_price();	/* get std err of current prices */
	target = norm(mean, err);

	if (cask > 0 && cask < target) target = cask - 1;
	if (target <= 0.0 || target < least) target = least;

	weight = (double) (((ntimes-t+1)/ntimes)*
			   ((ntokens-mytrades)/ntokens)*
			   (nbuyers/nplayers));

	if (cask > 0)
	    newoffer = (int)(weight*(cask-1)+(1.0-weight)*target);
	else
	    newoffer = (int)(weight*(token[ntokens]+1)+(1.0-weight)*target);
	
	return ((newoffer>maxprice)? maxprice : newoffer);
    }
    
    public int playerRequestBuy() {

	double target;

	if (nobuysell>0) return 0;
	if (token[mytrades+1] <= cask) return 0;	/* don't buy at a loss! */
	if (id==bidder && cbid>=cask) return 1;	/* accept offer <= our bid */

	target = get_target_price() + get_stderr_price();

	return ((target<maxprice && cask < (int) target)? 1: 0);
    }

    public int playerWantToSell() {
	
	double target;

	if (nobuysell>0) return 0;
	if (cbid <= token[mytrades+1]) return 0;	/* don't sell at a loss! */
	if (id==asker && cask<=cbid) return 1;	/* accept bid >= our offer */

	target = get_target_price() - get_stderr_price();

	return ((target>minprice && cbid > (int) target)? 1: 0);

    } 

    private double get_mean_price() {
	/* compute mean price in current period */
	int i;
	double sum = 0.0;
	
	for (i=1; i<=ntrades; i++)
	    sum += Math.abs((double)prices[i]);	/* cast added by RGP */
	return ((ntrades!=0)? sum/ntrades : 0.0);
    }

    private double get_target_price() {
	int i;
	double target;
	
	target = get_mean_price();	/* get mean price in current period */
	
	for (i=1; i<p; i++) target += mean_price[i];
	/* add up with previous means if any */
	if (ntrades!=0)
	    target = target/p;      	/* average price with all periods */
	else
	    if (p > 1) target = target/(p-1);
	
	return target;
    }

    private double get_stderr_price(){
	/* compute stderr of prices in current period */
	int i;
	double mean, sum2 = 0.0;
	
	mean = get_mean_price();

	if (mean <= 0) return 1.0;

	for (i=1; i<=ntrades; i++)
	    sum2 += (Math.abs((double)prices[i])-mean)*(Math.abs((double)prices[i])-mean);
	return ((ntrades>1)? Math.sqrt(sum2)/(ntrades-1) : 1.0);
    }

    private double norm(double mean, double err) {
	double r1, r2, rn, s;

	do {
	    r1=2.0*drand()-1.0;
	    r2=2.0*drand()-1.0;
	    s=r1*r1+r2*r2;
	}
	while (s >= 1.0);
	rn=r1*Math.sqrt((-2*Math.log(s))/s);
	return (mean+rn*err);
    }
}
