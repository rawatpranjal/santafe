public class SObserverPlayer extends SSocketPlayer {
    
    SObserverPlayer(SPlayerCom pCom) {
	super(pCom, 4);
	setType(4);
    }

   // Sends the bid ask info to the player, and returns their bid/ask for the current time, which must be 0 if nobidask != 0
    public void bidAsk(int t, int noba) {
	sendPacket(Global.BIDASK, t, 1);
	nobidask = 1;
	hasResponded=false;
    }
    
    // Sends the buy sell info to the player, and returns whether they wish to make a trade.  Must return 0 if nobuysell != 0
    public void buySell(int t, int nobs) {
	sendPacket(Global.BUYSELL, t, 1);
	nobuysell=1;
	hasResponded=false;
    }

}
