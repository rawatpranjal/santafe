import java.util.*;

public class PeriodHistory {
    private int periodNumber;

    // Number of timesteps in this period.
    private int numTimes;

    // Number of buyers in this period.
    private int numBuyers;

    // Number of sellers in this period.
    private int numSellers;

    // The current time.  Used while running the game to keep track of what timestep is currently active.
    private int currentTime;

    // The allowed bid and ask ranges for this period.
    private int uPriceBound, lPriceBound;

    // bid[x][y] is the bid of buyer x in time y.  0 if none.
    private int[][] bid;

    // ask[x][y] is the ask of seller x in time y.  0 if none.
    private int[][] ask;

    // Number of new bids, indexed by time.  numBids[5] is the number of new bids in time step 5.
    private int[] numBids; 

    // Number of new asks, indexed by time.  numAsks[5] is the number of new asks in time step 5.
    private int[] numAsks;

    // highBidder[x] is the id of the high Bidder in time x.
    private int[] highBidder;

    // lowAsker[x] is the id of the low Asker in time x.
    private int[] lowAsker;

    // highBid[x] is the value of the high bid in time x.
    private int[] highBid;

    // lowAsk[x] is the value of the low ask in time x.
    private int[] lowAsk;

    // Variables storing whether the high bidder and low asker, respectively, accepted the trade at the opponents price.
    // Indexed by timestep.
    private boolean[] buyerAccepted;
    private boolean[] sellerAccepted;


    // Status variables for the results of the bid-ask round of currentTime.
    // old statuses are not stored.  Used while running game.
    // 0 = No new bid/ask, you are not the current bidder/asker.
    // 1 = No new bid/ask, you are still the current bidder/asker.
    // 2 = New bid/ask, you are the current bidder/asker.
    // 3 = New bid/ask, your offer was beaten by another bidder/asker.
    // 4 = New bid/ask, your offer was tied, and you lost the random tie-break.
    private int[] askStatus;
    private int[] bidStatus;


    // The price of the trade in each time.  0 if no trade.
    // The traders are necessarily the high bidder and low asker.
    private int[] tradePrice;
    
    // numBuys[x][y] is the total number of buys made by buyer x this period by the *end* of time y. 
    private int[][] numBuys;

    // numSells[x][y] is the total number of sells made by seller x this period by the *end* of time y.
    private int[][] numSells;

    private int[] buyerProfit; // Total profit this period, indexed by buyer id
    private int[] sellerProfit; // Total profit this period, indexed by seller id
    private int totalProfit; // Total profit of all buyers and sellers this period.

    private int[] buyerEff;
    private int[] sellerEff;
    private int totalEff;
    
    // Links to the token groups held by the RoundHistory
    private TokenGroup[] buyerTokenGroup;
    private TokenGroup[] sellerTokenGroup;

    // The following three fields are used only by client side PeriodHistory objects, and have no significant in the Server-side data.

    // Reference to the TokenGroup stored by the RoundHistory that this PeriodHistory belongs to.
    private TokenGroup myTokens;
    private boolean iAmBuyer;
    private int myId;
    
    
    public PeriodHistory(int pN, int nT, int nB, int nS, int uB, int lB, int id, boolean isBuyer, TokenGroup myT, TokenGroup[] bTG, TokenGroup[] sTG) {
	periodNumber = pN;
	numTimes = nT;
	numBuyers = nB;
	numSellers = nS;
	uPriceBound = uB;
	lPriceBound = lB;

	
	myId = id;
	iAmBuyer=isBuyer;
	myTokens = myT;

	bid = new int[nB+1][nT+1];
	ask = new int[nS+1][nT+1];
	tradePrice = new int[nT+1];
	lowAsker = new int[nT+1];
	highBidder = new int[nT+1];
	numBuys = new int[nB+1][nT+1];
	numSells = new int[nS+1][nT+1];
	highBid = new int[nT+1];
	lowAsk = new int[nT+1];
	askStatus = new int[nS+1];
	bidStatus = new int[nB+1];
	buyerAccepted = new boolean[nT+1];
	sellerAccepted = new boolean[nT+1];
	numBids = new int[nT+1];
	numAsks = new int[nT+1];
	buyerProfit = new int[nB+1];
	sellerProfit = new int[nS+1];
	buyerEff = new int[nB+1];
	sellerEff = new int[nS+1];
	buyerTokenGroup = bTG;
	sellerTokenGroup = sTG;
	currentTime=0;
    }

    public boolean incrementTime() {
	currentTime++;
	if (currentTime>numTimes)
	    return false;
	// if there was no trade, bids and asks carry over.
	if (tradePrice[currentTime-1]==0) {
	    for (int x=1;x<=numBuyers;x++)
		bid[x][currentTime]=bid[x][currentTime-1];
	    for (int x=1;x<=numSellers;x++)
		ask[x][currentTime]=ask[x][currentTime-1];
	}
	for (int x=1;x<=numBuyers;x++) {
	    numBuys[x][currentTime]=numBuys[x][currentTime-1];
	    bidStatus[x]=0;
	}
	for (int x=1;x<=numSellers;x++) {
	    numSells[x][currentTime]=numSells[x][currentTime-1];
	    askStatus[x]=0;
	}
	return true;
    }

    // If the bid is valid, adds it and returns true.  Otherwise returns false.
    public boolean addBid(int bidder, int b) {
	if (!isBidValid(b))
	    return false;
	numBids[currentTime]++;
	bidStatus[bidder]=3;
	bid[bidder][currentTime]=b;
	return true;
    }
    
    // Checks to see if the bid if the bid is valid.
    private boolean isBidValid(int b) {
	if (priceIsInRange(b)) {
	    if (tradePrice[currentTime-1]>0) // If there was a trade last time
		return true;
	    if (b>highBid[currentTime-1])
		return true;
	}		   
	return false;
    }

    // If the ask is valid, adds it and returns true.  Otherwise returns false.
    public boolean addAsk(int asker, int a) {
	if (!isAskValid(a))
	    return false;
	numAsks[currentTime]++;
	askStatus[asker] = 3;
	ask[asker][currentTime]=a;
	return true;
    }

    // Checks to see whether the given ask is valid.
    private boolean isAskValid(int a) {
    	if (priceIsInRange(a)) {
	    if (tradePrice[currentTime-1]>0)
		return true;
	    if (a<lowAsk[currentTime-1])
		return true;
	    if (lowAsk[currentTime-1]==0)
		return true;
	    if (currentTime==1)
		return true;
	}
	return false;
    }

    // Checks to see if a price is within the upper and lower bounds on price.
    private boolean priceIsInRange(int price) {
	if (price>uPriceBound)
	    return false;
	if (price<lPriceBound)
	    return false;
	return true;
    }

    // Returns the bid/ask of the player defined by the parameters in the current time.  Used during runtime only.
    public int getOffer(int id, boolean isBuyer) {
	if (isBuyer)
	    return bid[id][currentTime];
	else
	    return ask[id][currentTime];
    }

    // Returns the bid of a player in timestep t.
    public int getBid(int bidder, int t) {
	if (bidder==0)
	    return 0;
	if ((bidder>0)&&(bidder<=numBuyers))
	    if ((t>0)&&(t<=numTimes))
		return bid[bidder][t];
	return -1;
    }

    // Returns the ask of a player in timestep t.
    public int getAsk(int asker, int t) {
	if (asker==0)
	    return 0;
	if ((asker>0)&&(asker<=numSellers))
	    if ((t>0)&&(t<=numTimes))
		return ask[asker][t];
	return -1;
    }

    public void setHighBidder(int bidder) {
	highBidder[currentTime]=bidder;
	highBid[currentTime] = bid[bidder][currentTime];
    }

    // Returns the id of the high bidder in timestep t.
    public int getHighBidder(int t) {
	if ((t>0)&&(t<=numTimes))
	    return highBidder[t];
	return -1;
    }
    
    public void setLowAsker(int asker) {
	lowAsker[currentTime]=asker;
	lowAsk[currentTime] = ask[asker][currentTime];
    }

    // Returns the id of the low asker in timestep t.
    public int getLowAsker(int t) {
	if ((t>0)&&(t<=numTimes))
	    return lowAsker[t];
	return -1;
    }

    // Called only by server-side.
    public void addTrade(boolean bAccept, boolean sAccept) {
	buyerAccepted[currentTime] = bAccept;
	sellerAccepted[currentTime] = sAccept;
	int price=0;
	if (bAccept) {
	    if (sAccept) {
		Random ranGen = new Random();
		int r = ranGen.nextInt(2);
		if (r==1)
		    price = lowAsk[currentTime];
		else
		    price = highBid[currentTime];
	    }
	    else
		price = lowAsk[currentTime];
	}
	else if (sAccept)
	    price = highBid[currentTime];

	if ((bAccept)||(sAccept)) {
	    addTrade(price);
	    addTradeProfits();
	}
    }

    // Assumes that the highBidder and lowAsker have already been set for the currentTime.
    public void addTrade(int price) {
	tradePrice[currentTime]=price;
	numBuys[highBidder[currentTime]][currentTime]++;
	numSells[lowAsker[currentTime]][currentTime]++;
    }
		
    // MUST be called AFTER addTrade in a given time step.
    public void addTradeProfits() {
	int bidder = highBidder[currentTime];
	int asker = lowAsker[currentTime];
	int price = tradePrice[currentTime];
	int bTokenValue = buyerTokenGroup[bidder].getTokenValue(numBuys[bidder][currentTime]);
	int sTokenValue = sellerTokenGroup[asker].getTokenValue(numSells[asker][currentTime]);
	buyerProfit[bidder]+=(bTokenValue-price);
	sellerProfit[asker]+=(price-sTokenValue);
    }

    // Returns the trade price at timestep t.
    public int getTradePrice(int t) {
	if ((t>0)&&(t<=numTimes))
	    return tradePrice[t];
	return -1;
    }

    // Returns the high bid at timestep t.
    public int getHighBid(int t) {
	return highBid[t];
    }

    // Returns the low ask at timestep t.
    public int getLowAsk(int t) {
	return lowAsk[t];
    }

    // Used only client-side.  Returns the TokenGroup of the player.
    public TokenGroup getMyTokens() { return myTokens; }

    public int getPeriodNumber() { return periodNumber; }

    public int getNumTimes() { return numTimes; }
    
    public int getNumBuyers() { return numBuyers; }

    public int getNumSellers() { return numSellers; }

    // Valid only client side.
    public int getNumTokens() { return myTokens.getNumTokens(); }

    public int getCurrentTime() { return currentTime; }

    public int getUpperPriceBound() { return uPriceBound; }

    public int getLowerPriceBound() { return lPriceBound; }

    public int getNumTrades() {
	return myTradesArray()[myId][currentTime];
    }

    public String getCurrentTokenString() {
	return myTokens.getTokenString(getNumTrades());
    }

    // Returns the value of the last Token traded.
    public int getCurrentTokenValue() {
    	return myTokens.getTokenValue(getNumTrades());
    }

    public int getTokenValue(int t) {
	return myTokens.getTokenValue(t);
    }
    
    // Returns in what time the player's nth trade occurred.
    // -1 if that trade hasn't occurred yet.
    public int getTimeOfTrade(int n) {
	int cnt = 1;
	while ((cnt<=currentTime)&&((myTradesArray()[myId][cnt])!=n))
	    cnt++;
	if (cnt<=currentTime)
	    return cnt;
	else
	    return -1;
    }
    
    // Returns the tokenValue active at the *beginning* of time t.
    public int getTokenAtTime(int t) {
	return myTokens.getTokenValue((myTradesArray()[myId][t-1])+1);
    }

    private int[][] myTradesArray() {
	if (iAmBuyer)
	    return numBuys;
	else
	    return numSells;
    }

    public boolean iAmBuyer() {
	return iAmBuyer;
    }

    public int getMyId() {
	return myId;
    }

    public int getNumTrades(int id, boolean isB) {
	if (isB)
	    return numBuys[id][currentTime];
	else
	    return numSells[id][currentTime];
    }

    public boolean getAcceptedStatus(boolean isBuyer) {
	if (isBuyer)
	    return buyerAccepted[currentTime];
	else
	    return sellerAccepted[currentTime];
    }

    public int getOfferStatus(int i, boolean isBuyer) {
	if (isBuyer)
	    return bidStatus[i];
	else
	    return askStatus[i];
    }
    
    public boolean madeNewOffer(int i, boolean isBuyer) {
	if (isBuyer) {
	    if (bidStatus[i]>1)
		return true;
	}
	else
	    if (askStatus[i]>1)
		return true;
	return false;
    }

    public void determineTimeStepWinners() {
	determineHighBidLowAsk();
	determineHighBidder();
	determineLowAsker();
    }

    private void determineHighBidLowAsk() {
	highBid[currentTime]=0;
	lowAsk[currentTime]=Integer.MAX_VALUE;
	for (int x=1;x<=numBuyers;x++)
	    if ((bid[x][currentTime])>highBid[currentTime])
		highBid[currentTime] = bid[x][currentTime];
	for (int x=1;x<=numSellers;x++) {
	    if ((ask[x][currentTime])<lowAsk[currentTime])
		if (ask[x][currentTime]>0)
		    lowAsk[currentTime] = ask[x][currentTime];
	}
	if (lowAsk[currentTime]==Integer.MAX_VALUE)
	    lowAsk[currentTime]=0;
    }

    // MUST be called AFTER determineHighBidLowAsk() in a time step.
    private void determineHighBidder() {
	Random ranGen = new Random();
	int aBid = highBid[currentTime];
	if (aBid==0)
	    highBidder[currentTime]=0;
	else {
	    int bidderCount=0;
	    for (int x=1;x<=numBuyers;x++)
		if ((bid[x][currentTime])==aBid) {
		    highBidder[currentTime] = x;
		    bidderCount++;
		    if (bidStatus[x]==0)
			bidStatus[x]=1;
		    else
			bidStatus[x]=4;
		}
	    if (bidderCount==0)
		System.out.println("Error!  No bidders match the high bid of "+aBid);
	    else {
		if (bidderCount>1) {
		    int chosenBidder = ranGen.nextInt(bidderCount);
		    // Note that we associate 0 with the bidder already assigned in the previous part of this
		    // function.  So, if the result is 0, there is no need to change the assignment.
		    if (chosenBidder>0) {
			int y=1;
			for (int x=0; x<chosenBidder; x++)
			    while (bid[y][currentTime]!=aBid) y++;
			highBidder[currentTime]=y;
		    }
		}
	    }
	    if (bidStatus[highBidder[currentTime]]==4)
		bidStatus[highBidder[currentTime]]=2;
	}
    }

    private void determineLowAsker() {
	Random ranGen = new Random();
	int aAsk = lowAsk[currentTime];
	if (aAsk==0)
	    lowAsker[currentTime]=0;
	else {
	    int askerCount=0;
	    for (int x=1;x<=numSellers;x++)
		if ((ask[x][currentTime])==aAsk) {
		    lowAsker[currentTime] = x;
		    askerCount++;
		    if (askStatus[x]==0)
			askStatus[x]=1;
		    else
			askStatus[x]=4;
		}
	    if (askerCount==0)
		System.out.println("Error!  No askers match the low ask of "+aAsk);
	    else {
		if (askerCount>1) {
		    int chosenAsker = ranGen.nextInt(askerCount);
		    // Note that we associate 0 with the asker already assigned in the previous part of this
		    // function.  So, if the result is 0, there is no need to change the assignment.
		    if (chosenAsker>0) {
			int y=1;
			for (int x=0; x<chosenAsker; x++)
			    while (ask[y][currentTime]!=aAsk) y++;
			lowAsker[currentTime]=y;
		    }
		}
	    }
	    if (askStatus[lowAsker[currentTime]]==4)
		askStatus[lowAsker[currentTime]]=2;
	}
    }

    public int getNumNewBids() {
	return numBids[currentTime];
    }

    public int getNumNewAsks() {
	return numAsks[currentTime];
    }

    public void addToProfit(int a) {
	if (iAmBuyer)
	    buyerProfit[myId]+=a;
	else
	    sellerProfit[myId]+=a;
    }

    public int getMyProfit() {
	if (iAmBuyer)
	    return buyerProfit[myId];
	else
	    return sellerProfit[myId];
    }

    public void setMyEfficiency(int e) {
	if (iAmBuyer)
	    buyerEff[myId]=e;
	else
	    sellerEff[myId]=e;
    }
    
    public int getMyEfficiency() {
	if (iAmBuyer)
	    return buyerEff[myId];
	else
	    return sellerEff[myId];
    }

    public int getProfit(boolean buyer, int i) {
	if (buyer)
	    return buyerProfit[i];
	else
	    return sellerProfit[i];
    }

    public int getEfficiency(boolean buyer, int i) {
	if (buyer)
	    return buyerEff[i];
	else
	    return sellerEff[i];
    }

    public int getTotalProfit() { return totalProfit; }

    public int getTotalEfficiency() { return totalEff; }

    // maxSurplus is the maximum about of profit possible.
    // eqPrice is the competitive equilibrium price.
    public void calculateEfficiencies(int maxSurplus, int eqPrice) {
	totalProfit=0;
	int profit;
	int maxProfit;
	for (int x=1;x<=numBuyers;x++) {
	    profit = buyerProfit[x];
	    totalProfit+=profit;
	    if (profit!=0) {
		maxProfit = buyerTokenGroup[x].getMaxProfit(eqPrice);
		if (maxProfit<=0)
		    buyerEff[x]=-1;
		else 
		    buyerEff[x]=(100*profit)/maxProfit;
		
	    }
	    else
		buyerEff[x]=0;
	}
	for (int x=1;x<=numSellers;x++) {
	    profit = sellerProfit[x];
	    totalProfit+=profit;
	    if (profit!=0) {
		maxProfit = sellerTokenGroup[x].getMaxProfit(eqPrice);
		if (maxProfit<=0)
		    sellerEff[x]=-1;
		else 
		    sellerEff[x]=(100*profit)/maxProfit;
		
	    }
	    else
		sellerEff[x]=0;
	}
	if (maxSurplus<=0)
	    totalEff=-1;
	else
	    totalEff = (100*totalProfit)/maxSurplus;
    }
			
}
	

    
