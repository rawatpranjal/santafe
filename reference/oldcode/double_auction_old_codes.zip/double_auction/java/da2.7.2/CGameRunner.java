public class CGameRunner {
    private CGameController myController;
    private CServerCom myCom;
    private GameHistory history;
    private RoundHistory currentRound;
    private PeriodHistory currentPeriod;
    private boolean iAmBuyer;
    private int myId;
    private int currentAsk;
    private int currentBid;
    private int currentTime;
    private int currentAsker;
    private int currentBidder;

    public CGameRunner(CGameController c, CServerCom com, GameHistory h) {
	myController = c;
	myCom = com;
	history = h;
	iAmBuyer = history.iAmBuyer();
	myId = history.getMyId();
	currentTime=0;
    }

    public void receiveMessage(String s) {	   
	int[] m = myController.parseLine(s);
	if (m==null)
	    myController.givePlayerMessage(s);
	else {
	    int code = m[0];
	    int i1 = m[1];
	    int i2 = m[2];
	    
	    if (code==Global.BIDASK)
		propositionStep(i1, i2);
	    else if (code==Global.BADISP)
		propositionResult(i1);
	    else if (code==Global.BUYSELL)
		transactionStep(i2);
	    else if (code==Global.BSDISP)
		transactionResult(i1,i2);
	    else if (code==Global.ROUND)
		startRound(i1, i2);
	    else if (code==Global.PERIOD)
		startPeriod(i2);
	    else if (code==Global.ENDROUND)
		endRound(i1, i2);
	    else if (code==Global.ENDPERIOD)
		endPeriod(i1, i2);
	    else if (code==Global.ENDGAME)
		endGame(i1,i2);
	    else if (code==Global.ROUNDSUMMARY)
		roundSummary(i1,i2);
	    else
		myController.givePlayerMessage(s);
	}
    }

    private void startRound(int roundNum, int numTokens) {
	myController.newRound();
	history.incrementRound();	
	currentRound = history.getCurrentRound();

	TokenGroup tokens = new TokenGroup(numTokens, iAmBuyer);
	for (int x=1;x<=numTokens;x+=2) {
	    int[] m = getParsedMessage();
	    tokens.addTokenValue(m[1]);
	    if (x<numTokens)
		tokens.addTokenValue(m[2]);
	}
	currentRound.addTokenGroup(tokens, iAmBuyer, myId);
	message(" ");
	message(" ");
	message("Round "+roundNum+" is starting...");
	myCom.sendLine(Global.READY + " " + myId);
    }


	
    private void startPeriod(int periodNum) {
	currentRound.incrementPeriod();
	currentPeriod = currentRound.getCurrentPeriod();
	message(" ");
	message("Period "+periodNum+" of Round "+currentRound.getRoundNumber()+" is starting...");
	if (!history.iAmObserver())
	    message("Your token values for this period are: "+currentPeriod.getMyTokens().getTokenString(0));
	myController.newPeriod();
	myController.updateGraph(0,true);
	myCom.sendLine(Global.READY + " " + myId);
    }

    private void propositionStep(int timeNum, int nobidask) {
	message(" ");
	message("Round "+currentRound.getRoundNumber()+" | Period "+currentPeriod.getPeriodNumber()+" | Time "+timeNum);
	message("---------------------------------------------");
	currentPeriod.incrementTime();
	currentTime=timeNum;
	if (!history.iAmObserver())
	    message("Tokens: "+currentPeriod.getCurrentTokenString());
	if (currentAsk>0) {
	    if ((!iAmBuyer)&&(myId==currentAsker))
		message("You hold the current Low Ask of "+currentAsk+".");
	    else
		message("S"+currentAsker+" holds the current Low Ask of "+currentAsk+".");
	}
	else
	    message("There is no current Low Ask.");
	if (currentBid>0) {
	    if ((iAmBuyer)&&(myId==currentBidder))
		message("You hold the current High Bid of "+currentBid+".");
	    else
		message("B"+currentBidder+" holds the current High Bid of "+currentBid+".");
	}
	else
	    message("There is no current High Bid.");
	if (nobidask == 0) {
	    if (iAmBuyer)
		message("Offer a bid greater than the current High Bid, or hit None for no bid.");
	    else
		message("Ask for an amount lower than the current Low Ask, or hit None for no ask.");
	    myController.propositionStep(true);
	}
	else {
	    if (!history.iAmObserver())
		message("Sorry, but you don't have any tokens left!");
	    myController.propositionStep(false);
	    myCom.sendLine(Global.NONE+" 0");
	}	
    }

    private void propositionResult(int status) {
	if (status==-2)
	    message("ERROR: Late message in proposition step.");
	else if (status==-1)
	    message("ERROR: Unacceptable proposition.");

	int[] m = getParsedMessage();
	while (m[0]==Global.BID) {
	    if ((!iAmBuyer) || (myId != m[2])) 
		message("B"+m[2]+" just made a new bid of "+m[1]+".");
	    currentPeriod.addBid(m[2],m[1]);
	    m = getParsedMessage();
	}
	while (m[0]==Global.ASK) {
	    if ((iAmBuyer) || (myId != m[2]))
		message("S"+m[2]+" just made a new ask of "+m[1]+".");
	    currentPeriod.addAsk(m[2],m[1]);
	    m = getParsedMessage();
	}
	currentPeriod.setHighBidder(m[2]);
	if (m[2]>0) {
	    if ((iAmBuyer)&&(myId==m[2]))
		message("You are the current High Bidder!");
	    else
		message("The current High Bidder is B"+m[2]+".");
	}
	else
	    message("There is no current High Bidder.");
	currentBidder = m[2];
	currentBid = m[1];
	m = getParsedMessage();
	currentPeriod.setLowAsker(m[2]);
	currentAsker=m[2];
	currentAsk = m[1];
	if (m[2]>0) {
	    if ((!iAmBuyer) && (myId==m[2]))
		message("You are the current Low Asker!");
	    else
		message("The current Low Asker is S"+m[2]+".");
	}
	else
	    message("There is no current Low Asker.");
	myController.updateGraph(currentTime, false);
    }
	
    private void transactionStep(int nobuysell) {
	if (nobuysell!=0) {
	    if (!history.iAmObserver()) {
		message("Sorry, but you aren't qualified to make a trade this round, because:");
		if (nobuysell>3) {
		    nobuysell-=4;		
		    if (iAmBuyer) 
			message("  You aren't the high bidder at this time."); 
		    else
			message("  You aren't the low asker at this time.");
		}
		if (nobuysell>1) {
		    nobuysell-=2;
		    message("  There needs to be a High Bidder AND a Low Asker for a trade to occur.");
		}
		if (nobuysell>0)
		    message("  You have no tokens left.");
	    }
	    myController.transactionStep(false);
	    myCom.sendLine(Global.NONE + " 0");
	}
	else {
	    if (iAmBuyer)
		message("Would you like to buy a token from S"+currentAsker+" for "+currentAsk+"?");
	    else
		message("Would you like to sell a token to B"+currentBidder+" for "+currentBid+"?");
	    myController.transactionStep(true);
	}
    }
    
    private void transactionResult(int status, int trades) {
	if (status==-2)
	    message("ERROR: Transaction response received too late.");
	if (status==-1)
	    message("ERROR: Illegal transaction response.");
	int[] m = getParsedMessage();
	if (m[0]==Global.TRADE) {
	    message(" ");
	    message("A trade occurred:");
	    int p = m[2];
	    currentPeriod.addTrade(p);
	    m = getParsedMessage();
	    int bId = m[1];
	    int sId = m[2];
	    if ( (iAmBuyer) && (myId == bId) ) {
		message("You just bought a token for "+p+" from Seller "+sId+".");
		int profit = (currentPeriod.getCurrentTokenValue()-p);
		message("Your profit is "+profit);
		currentPeriod.addToProfit(profit);
	    }
	    else if ( (!iAmBuyer) && (myId == sId) ) {
		message("You just sold a token for "+p+" from Buyer "+bId);
		int profit = (p-currentPeriod.getCurrentTokenValue());
		message("Your profit is "+profit);
		currentPeriod.addToProfit(profit);
	    }
	    else
		message("B"+bId+" and S"+sId+" just traded at "+p);
	    m = getParsedMessage();
	    currentBidder=0;
	    currentBid=0;
	    currentAsker=0;
	    currentAsk=0;
	}
	else
	    message("No trade occurred this round.");
	m = getParsedMessage();
	myController.updateGraph(currentTime, true);
    }
    
    private void endRound(int p, int e) { 
	if (p!=currentRound.getMyProfit())
	    System.out.println("Error! Round profits don't match with client.");
	message("");
	message("Round "+currentRound.getRoundNumber()+" has finished.");
	message("");
	if (!history.iAmObserver()) {
	    message("Your profit for this round was: "+p+".");
	    message("Your efficiency this round was: "+e+".");
	    currentRound.setMyEfficiency(e);
	    message("");
	}
	message("");
	message("");
	myController.endRound();
    }

    private void roundSummary(int buyerValuesSize, int sellerValuesSize) {
	int[] buyerTokenValues = new int[buyerValuesSize];
	int[] sellerTokenValues = new int[sellerValuesSize];
	String bString = myCom.waitForLine();
	String sString = myCom.waitForLine();
	String[] buyerValues = bString.split("\\s",0);
	String[] sellerValues = sString.split("\\s",0);
	for (int x=0;x<buyerValues.length;x++) {
	    buyerTokenValues[x+1]=Integer.parseInt(buyerValues[x]);
	}
	currentRound.setBuyerTokenValues(buyerTokenValues);
	for (int x=0;x<sellerValues.length;x++) {
	    sellerTokenValues[x+1]=Integer.parseInt(sellerValues[x]);
	}
	currentRound.setSellerTokenValues(sellerTokenValues);
    }
	
    
    private void endPeriod(int p, int e) {
	if (p!=currentPeriod.getMyProfit())
	    System.out.println("Error! Period profits don't match with client.");
	message("");
	message("Period "+currentPeriod.getPeriodNumber()+" has finished.");
	message("");
	if (!history.iAmObserver()) {
	    message("Your profit for this period was: "+p+".");
	    message("Your efficiency this period was: "+e+".");
	    currentPeriod.setMyEfficiency(e);
	    message("");
	}
	currentBidder=0;
	currentBid=0;
	currentAsker=0;
	currentAsk=0;
	myController.endPeriod();
    }

    private void endGame(int p, int e) {
	if (p!=history.getMyProfit())
	    System.out.println("Error! Game profits don't match with client.");
	message("-----------------------------------");
	message(" ");
	message("End of Game");
	if (!history.iAmObserver()) {
	    message("Your total profit was: "+p+".");
	    message("Your total efficiency was: "+e+".");
	    history.setMyEfficiency(e);
	}
	myController.gameFinished();
    }

    public boolean propose(int p) {
	if (p==0) {
	    if (iAmBuyer) {
		message("You made no new bid this time step.");
		int oldBid = currentPeriod.getBid(myId, currentTime-1);
		if ((oldBid>0)&&(currentPeriod.getTradePrice(currentTime-1)==0))
		    message("Your previous bid of "+oldBid+" was carried over.");
	    }
	    else {
		message("You made no new ask this time step.");
		int oldOffer = currentPeriod.getAsk(myId, currentTime-1);
		if ((oldOffer>0)&&(currentPeriod.getTradePrice(currentTime-1)==0))
		    message("Your previous ask of "+oldOffer+" was carried over.");
	    }

	    myCom.sendLine(Global.NONE+" 0");
	    return true;
	}
	if (iAmBuyer) {
	    if (currentPeriod.addBid(myId, p)) {
		message("You made a new bid of "+p+".");
		myCom.sendLine(Global.BID + " " + p);
		return true;
	    } 
	}
	else {
	    if (currentPeriod.addAsk(myId, p)) {
		message("You made a new ask of "+p+".");
		myCom.sendLine(Global.ASK + " " + p);
		return true;
	    }
	}
	return false;
    }

    public void acceptTransaction(boolean a) {
	if (!a) {
	    message("You declined the proposed price.");
	    myCom.sendLine(Global.NONE + " 0");
	}
	else if (iAmBuyer) {
	    message("You expressed interest in buying at "+currentAsk+".");
	    myCom.sendLine(Global.BUY + " " + currentAsk);
	}
	else {
	    message("You expressed interest in selling at "+currentBid+".");
	    myCom.sendLine(Global.SELL + " " + currentBid);
	}
    }

    private int[] getParsedMessage() {
	String s = myCom.waitForLine();
	return myController.parseLine(s);
    }

    private void message(String s) {
	myController.givePlayerMessage(s);
    }
}
