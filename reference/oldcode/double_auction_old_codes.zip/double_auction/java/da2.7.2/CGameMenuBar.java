import javax.swing.*;
import java.awt.event.*;

public class CGameMenuBar extends JMenuBar implements ActionListener {
    JMenu framesMenu;
    JMenuItem textWindowChoice,historyWindowChoice;
    CGameController myController;

    public CGameMenuBar(CGameController myControl) {
	myController = myControl;

	setupFramesMenu();
	add(framesMenu);
    }

    private void setupFramesMenu() {
	framesMenu = new JMenu("Windows");
	textWindowChoice = new JMenuItem("Textual View");
	textWindowChoice.addActionListener(this);
	framesMenu.add(textWindowChoice);
	historyWindowChoice = new JMenuItem("Game History");
	historyWindowChoice.addActionListener(this);
	framesMenu.add(historyWindowChoice);
    }

    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if (source==textWindowChoice)
	    myController.toggleTextFrame();
	else if (source==historyWindowChoice)
	    myController.toggleHistoryFrame();
    }

}
	
	
