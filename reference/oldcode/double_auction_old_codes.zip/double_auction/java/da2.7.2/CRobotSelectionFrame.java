import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class CRobotSelectionFrame extends JFrame implements ActionListener {
	
    private JComboBox[] robotChoices;
    private JButton okButton;

    private static CRobotSelector robotSelector = new CRobotSelector();

    public CRobotSelectionFrame(int numRobots) {
	super("Robot Selection");
	robotChoices = new JComboBox[numRobots];
	setUndecorated(true);
	getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	setDefaultLookAndFeelDecorated(true);
	
	setSize(200,30*numRobots+60);
	setLocationRelativeTo(null);
	setResizable(false);
	setVisible(true);
	
	JPanel robotsPanel = new JPanel();
	robotsPanel.setLayout(new GridLayout(numRobots+1,1));
	
	add(robotsPanel);
	
	for (int x=0;x<numRobots;x++) {
	    JComboBox c = makeRobotChoice();
	    robotChoices[x]=c;
	    robotsPanel.add(c);
	}
	okButton = new JButton("Done Choosing Robots");
	okButton.addActionListener(this);
	robotsPanel.add(okButton);
    }
    
    private JComboBox makeRobotChoice() {
	return robotSelector.getRobotChooser();
    }
    
    public String getRobotString() {
	String s="";
	for (JComboBox c : robotChoices)
	    s = s + " robot "+getRobotNumber((String)c.getSelectedItem());
	System.out.println("|"+s+"|");
	return s;
    }
    
    public String getRobotNumber(String r) {
	return robotSelector.getIdNumber(r);
    }
    
    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if (source==okButton)
	    setVisible(false);
    }	       
}
