import javax.swing.*;
import java.awt.Color.*;
import java.awt.*;
import java.awt.geom.*;
import java.applet.*;
import java.util.*;
import java.awt.event.*;

public class CPeriodGraph extends JPanel {

    private GameHistory myGameHistory;
    private RoundHistory myRoundHistory;
    private int myPeriodNumber;
    private int myRoundNumber;
    private PeriodHistory myHistory;
    private CButtonPanel myButtonPanel;
    private CPeriodGraphFrame myFrame;
    private JTextArea miniHistory;
    private JPanel lowerPanel;

    private int leftSpacing = 40; // # of pixels to the left of the graph.
    private int topSpacing = 40; // # of pixels above the graph.
    private int bottomSpacing = 100; // # of pixels below the graph.
    private int rightSpacing = 20; // # of pixels to the right of the legend
    private int betweenSpacing = 10; // # of pixels between the graph and the legend.
    private int legendWidth = 120; // # of pixels wide for the RHS legend.

    private int upperGBound;
    private int lowerGBound;
    private int rightGBound;
    private int leftGBound;

    // The number of timesteps in this period.
    private int numTimes;
    private int currentTime;
    // Whether to draw the player's token value for the next round.
    private boolean projectTV;
    // The maximum possible value that could need to be graphed.
    // In most cases, this will be the highest token value among
    // the bidders.
    private int maxValue;

    private int xWindow; 
    private int yWindow;

    private int numBuyers;
    private int numSellers;
    private int numPlayers;

    private int xRange;
    private int yRange;
    private Color tokenTopColor;
    private Color tokenBottomColor;

    private Color[] buyerColor;
    private Color[] sellerColor;

    // These variables store how many pixels are equal to 1 in x or y terms respectively.
    private double xPixel, yPixel;
    private boolean iAmBuyer, isFinished, iAmObserver;
    private int myId;
    private String typeString;
    private double timeRemaining = 1.0; // fraction of time remaining
    private int secondsRemaining = 0; // seconds remaining
    
    // Used for graph lines.
    private BasicStroke dottedStroke = new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, new float[] {2f, 5f}, 0f);
    
    // Used for future token value lines.
    private BasicStroke dottedStroke2 = new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, new float[] {4f, 3f}, 0f);

    public CPeriodGraph(CButtonPanel myButtons, CPeriodGraphFrame myFra, GameHistory gh) {
	super();
	isFinished=false;
	myGameHistory = gh;
	iAmObserver = gh.iAmObserver();
	myFrame = myFra;
	myRoundHistory = gh.getCurrentRound();
	myRoundNumber = myRoundHistory.getRoundNumber();
	myHistory=myRoundHistory.getCurrentPeriod();
	myPeriodNumber = myHistory.getPeriodNumber();

	numTimes = myHistory.getNumTimes();
	maxValue = myHistory.getUpperPriceBound();
	setGraphSize();
	currentTime=0;
	projectTV = false;
	if (myHistory.iAmBuyer()) {
	    tokenTopColor = new Color(255,240,240);
	    tokenBottomColor = new Color(240,255,240);
	    iAmBuyer = true;
	}
	else {
	    tokenTopColor = new Color(240,255,240);
	    tokenBottomColor = new Color(255,240,240);
	    iAmBuyer = false;
	}
	myId = myHistory.getMyId();
	myButtonPanel=myButtons;
	numBuyers = myHistory.getNumBuyers();
	numSellers = myHistory.getNumSellers();
	numPlayers = numSellers+numBuyers;
	getColors();
	setTypeString();

	setupLowerPanel();
    }

    private void setupLowerPanel() {
	setLayout(new BorderLayout());
	lowerPanel = new JPanel();
	lowerPanel.setOpaque(false);
	
	

	miniHistory = new JTextArea(3,30);
	miniHistory.setLineWrap(true);
	miniHistory.setEditable(false);
	//JScrollPane historyScroller = new JScrollPane();
	//historyScroller.getViewport().add(miniHistory);
	
	miniHistory.setMaximumSize(new Dimension(300,50));
	//historyScroller.setMaximumSize(new Dimension(300,50));
	lowerPanel.add(miniHistory);
	lowerPanel.add(myButtonPanel);
	lowerPanel.add(Box.createRigidArea(new Dimension(120,10)));

	add("South", lowerPanel);
    }

    public void paintComponent(Graphics g) {
	g.setFont(new Font(null, Font.BOLD, 12));
	setGraphSize();

	g.clearRect(0,0,xWindow,yWindow);
	g.setColor(Color.WHITE);
	g.fillRect(leftGBound,upperGBound,rightGBound-leftGBound,lowerGBound-upperGBound);

	if (!iAmObserver)
	    drawProfitZones(g);
	   
	

	g.setColor(Color.BLACK);
	g.drawRect(leftGBound,upperGBound,rightGBound-leftGBound,lowerGBound-upperGBound);

	drawLinesAndLabels(g);

	if (!iAmObserver)
	    drawTokenLines(g);

	drawHistory(g);


	drawNumbers(g);
	if (!iAmObserver) {
	    if (isFinished)
		drawProfitAndEfficiency(g);
	    else
		drawTimer(g);
	}
    }

    private void drawProfitZones(Graphics g) {
	// Token Value Rects
	int p = myHistory.getTokenAtTime(1);
	g.setColor(tokenTopColor);
	fillGraphRect(g,0,yRange,.5,yRange-p);
	g.setColor(tokenBottomColor);
	fillGraphRect(g,0,p,.5,p);

	for (int x=1;x<=currentTime;x++) {
	    p = myHistory.getTokenAtTime(x);
	    if (p>=0) {
		g.setColor(tokenTopColor);
		fillGraphRect(g,x-.5,yRange,1,yRange-p);
		g.setColor(tokenBottomColor);
		fillGraphRect(g,x-.5,p,1,p);
	    }
	}
	p = myHistory.getTokenAtTime(currentTime+1);
	if ((projectTV)&&(p>=0)) {
	    double endWidth;
	    if (currentTime<numTimes)
		endWidth=1.0;
	    else
		endWidth=0.5;
	    g.setColor(tokenTopColor);
	    fillGraphRect(g,currentTime+.5,yRange,endWidth,yRange-p);
	    g.setColor(tokenBottomColor);
	    fillGraphRect(g,currentTime+.5,p,endWidth,p);
	}
    }

    private void drawTokenLines(Graphics graphics) {
	// Token Value Lines
	Graphics2D g = (Graphics2D)graphics;

	g.setColor(Color.RED);
	int tokenValue = myHistory.getTokenAtTime(1);
	drawGraphLine(g,0,tokenValue,0.5,tokenValue);

	int tradeNum=1;
	int timeOfTrade;
	int lastTrade=0;
	while ((timeOfTrade=myHistory.getTimeOfTrade(tradeNum))!=-1) {
	    tokenValue = myHistory.getTokenValue(tradeNum);;
	    drawGraphLine(g,lastTrade+.5,tokenValue,timeOfTrade+.5,tokenValue);
	    lastTrade=timeOfTrade;
	    tradeNum++;
	}
	
	int numTokens = myHistory.getNumTokens();
	if (numTokens>=tradeNum) {
	    tokenValue = myHistory.getTokenValue(tradeNum);
	    drawGraphLine(g,lastTrade+.5,tokenValue,currentTime+.5,tokenValue);
	    
	    double futureTokenShift = 0.5;
	    if (projectTV) {
		futureTokenShift=1.5;
		if (currentTime<numTimes)
		    drawGraphLine(g,currentTime+.5,tokenValue,currentTime+1.5,tokenValue);
		else
		    drawGraphLine(g,currentTime+.5,tokenValue,currentTime+1,tokenValue);
	    }
	    g.setColor(new Color(240,0,0));
	    g.setStroke(dottedStroke2);
	    for (int x=tradeNum+1;x<=numTokens;x++) {
		tokenValue = myHistory.getTokenValue(x);
		drawGraphLine(g,currentTime+futureTokenShift,tokenValue,numTimes+1,tokenValue);
	    }
	}

	g.setStroke(new BasicStroke());
    }

    private void drawHistory(Graphics g) {
	for (int i=1;i<=numBuyers;i++) {
	    Color myColor = buyerColor[i];
	    int lastBid, thisBid;
	    for (int t=1;t<=currentTime;t++) {
		thisBid=myHistory.getBid(i,t);
		lastBid=myHistory.getBid(i,t-1);
		if (thisBid!=0) {
		    drawProposal(g,t,thisBid,myColor,true);
		    if ((lastBid>0)&&(myHistory.getTradePrice(t-1)==0))
			connect(g,t-1,lastBid,thisBid);
		}
	    }
	}
	for (int i=1;i<=numSellers;i++) {
	    Color myColor = sellerColor[i];
	    int lastAsk,thisAsk;
	    for (int t=1;t<=currentTime;t++) {
		thisAsk=myHistory.getAsk(i,t);
		lastAsk=myHistory.getAsk(i,t-1);
		if (thisAsk!=0) {
		    drawProposal(g,t,thisAsk,myColor,false);
		    if ((lastAsk>0)&&(myHistory.getTradePrice(t-1)==0))
			connect(g,t-1,lastAsk,thisAsk);
		}
		lastAsk=thisAsk;
	    }
	}
	// Trades
	g.setColor(new Color(200,200,0));
	for (int t=1;t<=currentTime;t++) {
	    int price = myHistory.getTradePrice(t);
	    if (price>0)
		drawTransaction(g, t, price);   
	}
    }

    private void drawNumbers(Graphics g) {
	g.setFont(new Font(null, Font.BOLD, 16));
	int verticalSpacing = (lowerGBound-upperGBound-10)/numPlayers;
	int offset = (verticalSpacing-14)/2;
	int left = xWindow-rightSpacing-legendWidth;
	g.setColor(Color.WHITE);
	g.fillRect(left,upperGBound,legendWidth,lowerGBound-upperGBound);
	if (!isFinished) {
	    int highBidder=myHistory.getHighBidder(currentTime);
	    int lowAsker=myHistory.getLowAsker(currentTime);
	    g.setColor(Color.YELLOW);
	    if (highBidder>0)
		g.fillRect(left,upperGBound+(highBidder-1)*verticalSpacing,legendWidth,verticalSpacing);
	    if (lowAsker>0)
		g.fillRect(left,upperGBound+numBuyers*verticalSpacing+(lowAsker-1)*verticalSpacing+10,legendWidth,verticalSpacing);
	}

	g.setColor(Color.BLACK);
	g.drawRect(left,upperGBound,legendWidth,lowerGBound-upperGBound);
	g.fillRect(left,verticalSpacing*numBuyers+upperGBound,legendWidth,10);

	int y;

	for (int x=1;x<=numBuyers;x++) {
	    y = upperGBound+x*verticalSpacing-offset;
	    g.setColor(buyerColor[x]);
	    g.drawString("B"+x,left+5,y);
	    g.setColor(Color.BLACK);
	    if (!isFinished) {
		int bid = myHistory.getBid(x,currentTime);
		if (bid>0)
		    g.drawString(bid+"", left+35,y);
	    }
	    g.drawString(myHistory.getNumTrades(x,true)+"",left+legendWidth-20,y);
	}

	
	for (int x=1;x<=numSellers;x++) {
	    y = upperGBound+(numBuyers+x)*verticalSpacing-offset+10;
	    g.setColor(sellerColor[x]);
	    g.drawString("S"+x,left+5,y);
	    g.setColor(Color.BLACK);
	    if (!isFinished) {
		int ask = myHistory.getAsk(x,currentTime);
		if (ask>0)
		    g.drawString(ask+"",left+35,y);
	    }
	    g.drawString(myHistory.getNumTrades(x,false)+"",left+legendWidth-20,y);
	}
    }
	    
	

    // Updates the graph through time t
    public void update(int t, boolean project) {
	projectTV = project;
	currentTime=t;
	repaint();
    }

    public void drawGraphLine(Graphics g, double t1, double p1, double t2, double p2) {
	int x1 = (int)(xPixel*t1+leftGBound);
	int x2 = (int)(xPixel*t2+leftGBound);
	int y1 = (int)(lowerGBound-yPixel*p1);
	int y2 = (int)(lowerGBound-yPixel*p2);
	g.drawLine(x1,y1,x2,y2);
    }

    public void fillGraphRect(Graphics g, double t1, double p1, double tWidth, double pHeight) {
	int x1 = (int)(xPixel*t1+leftGBound);
	int y1 = (int)(lowerGBound-yPixel*p1);
	int width = (int)(xPixel*tWidth);
	int height = (int)(yPixel*pHeight);
	g.fillRect(x1+1,y1+1,width+1,height+1);
    }

    public void connect(Graphics g, int t, int p1, int p2) {
	if ((p1>0)&&(p2>0))
	    drawGraphLine(g, t,p1,t+1,p2);
    }

    public void drawProposal(Graphics g, int time, int price, Color c, boolean isBuyer) {
	g.setColor(c);
	if (price>0) {
	    int xVal = (int)(leftGBound+xPixel*time);
	    int yVal = (int)(lowerGBound-yPixel*price);
	    int[] xPoints = {xVal-4, xVal, xVal+4};
	    int[] yPoints = {yVal-8, yVal, yVal-8};
	    if (isBuyer) {
		yPoints[0]+=16;
		yPoints[2]+=16;
	    }
	    g.fillPolygon(xPoints,yPoints,3);
	}
    }
	
    public void drawTransaction(Graphics g, int time, int price){
	g.drawOval((int)(xPixel*time+leftGBound-6),(int)(lowerGBound-6-yPixel*price),12,12);
	g.drawOval((int)(xPixel*time+leftGBound-7),(int)(lowerGBound-7-yPixel*price),14,14);
    }

    public void getColors() {
	buyerColor = new Color[numBuyers+1];
	sellerColor = new Color[numSellers+1];	
	for (int x=1;x<=numBuyers;x++)
	    buyerColor[x] = myGameHistory.getPlayerColor(x,true);
	for (int x=1;x<=numSellers;x++)
	    sellerColor[x] = myGameHistory.getPlayerColor(x,false);
    }

    public void setGraphSize() {
	int xWindowNew, yWindowNew;
	if (isFinished) {
	    xWindowNew = getWidth(); 
	    yWindowNew = getHeight();
	}
	else {
	    xWindowNew = myFrame.getWidth()-5;
	    yWindowNew = myFrame.getHeight()-50;
	}
	if ((xWindowNew != xWindow) || (yWindowNew != yWindow)) {
	    yWindow = yWindowNew;
	    xWindow = xWindowNew;
	    calculateBounds();
	    calculateRanges();
	    calculatePixels();
	    setSize(xWindow,yWindow);
	}
    }

    private void calculateBounds() {
	upperGBound = topSpacing;
	lowerGBound = yWindow-bottomSpacing;
	leftGBound = leftSpacing;
	rightGBound = xWindow-betweenSpacing-rightSpacing-legendWidth;
    }

    public void calculateRanges() {
	xRange = numTimes+1;
	yRange = (((maxValue+110)/100)*100);
    }

    public void calculatePixels() {
	xPixel = ((double)(rightGBound-leftGBound))/((double)xRange);
	yPixel = ((double)(lowerGBound-upperGBound))/((double)yRange);
    }

    private void drawLinesAndLabels(Graphics g) {
       	Graphics2D myGraphics = (Graphics2D)g;

	g.setColor(Color.BLACK);



	for (int x=1;x<=numTimes;x++) {
	    int xCoord = leftGBound+(int)(x*xPixel);
	    myGraphics.drawLine(xCoord,lowerGBound,xCoord,lowerGBound+10);
	    myGraphics.drawString(""+x,xCoord-3,lowerGBound+25);
	}
	
	myGraphics.setStroke(dottedStroke);

	int yIncrement=yRange/10;
	for (int i=0;i<=9;i++) {
	    int y=upperGBound+(int)(i*yPixel*yIncrement);
	    myGraphics.drawLine(leftGBound,y,rightGBound,y);
	    myGraphics.drawString("" + (yIncrement*(10-i)),5,y+5);
	}

	myGraphics.setStroke(new BasicStroke());

	g.setFont(new Font(null, Font.BOLD, 16));
	g.drawString("Game History for Round "+myRoundNumber+" - Period "+myPeriodNumber+". You are "+typeString+".", ((xWindow-400)/2), 20);
    }

    public void pointClicked(int x, int y, int numClicks) {
	if ( (x>=0) && (x<=rightGBound) && (y>=upperGBound) && (y<=lowerGBound) ) {;
	    int offerValue = (int)((lowerGBound-y)/yPixel);
	    myButtonPanel.setOffer(offerValue);
	    if (numClicks >=2)
		myButtonPanel.submitOffer();
	}
    }

    public void finishGraph() { 
	isFinished = true; 
	legendWidth = 60; 
	remove(lowerPanel); 
    }

    public int getPeriodNumber() { return myPeriodNumber; }

    public void updateTimer(int s, double d) {
	secondsRemaining = s;
	timeRemaining = d;
	repaint();
    }
    
    private void drawTimer(Graphics g) {
	g.setFont(new Font(null, Font.BOLD, 16));
	double d = 1.0-timeRemaining;
	int x = xWindow-70;
	int y = yWindow-63;
	g.setColor(Color.WHITE);
	g.fillOval(x,y,50,50);
	g.setColor(Color.RED);
	g.fillArc(x,y,50,50,90,-(int)(d*360));
	g.setColor(Color.BLACK);
	g.drawOval(x,y,50,50);
	g.drawString("TIME",x-55,y+20);
	g.setFont(new Font(null, Font.BOLD, 14));
	g.drawString(secondsRemaining+" (s)",x-55,y+40);
    }

    private void drawProfitAndEfficiency(Graphics g) {
	g.setFont(new Font(null, Font.BOLD, 14));
	int x = xWindow-legendWidth-rightSpacing-betweenSpacing-20;
	int y = yWindow-bottomSpacing+30;
	g.setColor(Color.BLACK);
	g.drawString("Profit: "+myHistory.getMyProfit(),x+10,y);
	g.drawString("Efficiency: "+myHistory.getMyEfficiency(),x,y+20);
    }
	

    private void setTypeString() {
	typeString = "Seller "+myId;
	if (iAmBuyer)
	    typeString = "Buyer "+myId;
	if (iAmObserver)
	    typeString = "an observer";
    }

    public void givePlayerMessage(String s) {
	miniHistory.setText(s+"\n");
	miniHistory.setCaretPosition(miniHistory.getText().length());
    }

}
