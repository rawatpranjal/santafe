import java.util.*;

// Robot Skeleton
// playerNumber = 0
public class SRobotSkeleton extends SPlayer {

    int nplayers;  // number of players
    int nbuyers;   // number of buyers
    int nsellers;  // number of sellers
    int bnumber[]; // player-number for each buyer
    int snumber[]; // player-number for each seller
    int nrounds;   // maximum number of rounds
    int nperiods;  // maximum number of periods per round
    int ntimes;    // maximum number of times per period
    int minprice;  // minimum allowed price
    int maxprice;  // maximum allowed price
    int gameid;    // the game's id
    int gametype;  // token generation parameters
    int role;      // 1 if I'm a buyer, 2 if I'm a seller.
    int timeout;   // timeout time, 9999=infinity

    int r;         // current round
    int p;         // current period  
    int t;         // current time

    int cbid;      // current bid, or 0 for none
    int cask;      // current ask, or 0 for none
    int bidder;    // holder of current bid, or 0 for none
    int asker;     // holder of current ask, or 0 for none

    int nbids;     // Number of bids in the last bid-ask step
    int nasks;     // Number of asks in the last bid-ask step
    int bids[];    // bid values in the last bid-ask step
    int asks[];    // ask values in the last bid-ask step

    int bstype;    // For the last buy-sell step: 1=buy, 2=sell, 0=notrade
    int price;     // trade price if bstype>0, or 0.
    int buyer;     // buyer id if bstype>0, or 0.
    int seller;    // seller id if bstype>0, or 0.

    int btrades[]; // number of trades in period, by buyer
    int strades[]; // number of trades in period, by seller
    int ntrades;   // total number of trades this period.
    int prices[];  // Price of each trade, -1 if mine
    int lasttime;  // Time t when last trade occurred, or 0

    int ntokens;   // Number of tokens for the current round
    int token[];   // My current token values
    int mytrades;  // Number of trades I've made this period
    int mylasttime;// Time t when my last trade occurred, or 0
    int pprofit;   // My profit this period
    int rprofit;   // My profit this round
    int gprofit;   // My profit this game
    int nobidask;  // Non-zero if bid or ask not allowed.
    int ba;        // My outcome from last bid-ask step
    int nobuysell; // Non-zero if buy or sell not allowed
    int bs;        // My outcome from last buy-sell step
    int late;      // Number of times late in this period
    int tradelist[]; // List of my trades by period ??? number of trades per period
    int profitlist[];// List of my profit by period 
    int efficiency;  // Percentage of eqm profit
    int peff; // Percentage of eqm profit in last completed period.
    int reff; // Percentage of eqm profit in last completed round.
    
    // private int noblock;

    public SRobotSkeleton(String userId, int playNum, int rolePreference) {
	super(userId, rolePreference, 2);
	playerNumber = playNum;
	name = userId;
    }

    // RANDOM NUMBER GENERATION

    Random ranGen = new Random();

    // Returns a random double between 0.0 and 1.0
    final public double drand() {
	return ranGen.nextDouble();
    }

    // Returns a random integer between 0 and i, including 0, excluding i.
    final public int irand(int i) {
	return ranGen.nextInt(i);
    }

    // This was added to the skeleton because a lot of the old c-code uses the abs function, whereas in java one must refer to Math.abs()
    final public int abs(int i) {
	return Math.abs(i);
    }

    // END RANDOM NUMBER GENERATION

    // Called at the beginning of the game, to assign values.
    final public boolean initialization1(int gType, int gId, int nR, int nP, int nT, int maxTok, int maxBuy, int maxSel, int myRole, int time) {
	gametype = gType;
	gameid = gId;
	nrounds = nR;
	nperiods = nP;
	ntimes = nT;
	timeout = time;
	role=myRole;
	if (role==1)
	    isBuyer=true;
	else
	    isBuyer=false;    
	return true;
    }

    final public boolean initialization2(int nBuy, int nSell, int[] buyerNumbers, int[] sellerNumbers, int minPrice, int maxPrice, int myId) {
	nbuyers = nBuy;
	nsellers = nSell;
	nplayers = nBuy + nSell;
	bnumber = new int[nBuy+1];
	snumber = new int[nSell+1];
	for (int x=1;x<=nBuy;x++)
	    bnumber[x] = buyerNumbers[x];
	for (int x=1;x<=nSell;x++)
	    snumber[x] = sellerNumbers[x];
	minprice = minPrice;
	maxprice = maxPrice;
	id = myId;
	gprofit=0;
	
	playerGameBegin();
	return true;
    }

    final public boolean roundStart(int rNum, int numTokens, TokenGroup tokenGroup) {
	r = rNum;
	ntokens = numTokens;
	token = new int[numTokens+1];
	for (int x=1;x<=numTokens;x++) token[x] = tokenGroup.getTokenValue(x);
	tradelist = new int[nperiods+1];
	profitlist = new int[nperiods+1];
	rprofit=0;
	playerRoundBegin();
	return true;
    }

    final public boolean periodStart(int rNum, int pNum) {
	p = pNum;
	cbid=0;
	cask=0;
	bidder=0;
	asker=0;
	bstype=0;
	buyer=0;
	seller=0;
	price=0;
	nbids=0;
	nasks=0;
	bids = new int[0];
	asks = new int[0];
	btrades = new int[nbuyers+1];
	strades = new int[nsellers+1];
	ntrades=0;
	prices = new int[ntimes+1];
	lasttime=0;
	mytrades=0;
	mylasttime=0;
	late=0;
	ba=0;
	bs=0;
	pprofit=0;
	playerPeriodBegin();
	return true;
    }

    final public void bidAsk(int tNum, int noba) {
	t = tNum;
	nobidask = noba;
	hasResponded=false;
    }

    final public int bidAskResponse() {
	int result;
	if (isBuyer) {
	    result = playerRequestBid();
	    if (result<=cbid)
		result=0;
	}
	else {
	    result = playerRequestAsk();
	    if (cask>0)
		if (result>=cask)
		    result=0;
	}
	if (nobidask!=0)
	    result=0;
	hasResponded=true;
	return result;
    }


    final public void bidAskResult(int status, int numMyTrades, int numNewBids, int[] bidPrice, int[] newBidders, int numNewAsks, int[] askPrice, int[] newAskers, int currentBid, int currentBidder, int currentAsk, int currentAsker) {
	ba = status;
	mytrades = numMyTrades;
	nbids = numNewBids;
	nasks = numNewAsks;
	bids = new int[numNewBids+1];
	asks = new int[numNewAsks+1];
	for (int x=1;x<=nbids;x++)
	    bids[x]=bidPrice[x];
	for (int x=1;x<=nasks;x++)
	    asks[x]=askPrice[x];
	cbid = currentBid;
	cask = currentAsk;
	bidder = currentBidder;
	asker = currentAsker;
	playerBidAskEnd();
    }

    final public void buySell(int t, int nobs) {
	nobuysell=nobs;
	hasResponded=false;
    }

    final public int buySellResponse() {
	int result;
	if (isBuyer) {
	    result = playerRequestBuy();
	    if (result==1)
		result=cask;
	}
	else {
	    result = playerRequestSell();
	    if (result==1)
		result=cbid;
	}
	if (nobuysell!=0)
	    result=0;	
	hasResponded=true;
	return result;
    }
	

    
    final public void buySellResult(int status, int numMyTrades, int tradeType, int tradePrice, int b, int s, int currentBid, int currentBidder, int currentAsk, int currentAsker) {
	bs = status;
	if (tradeType!=0) { // Then there was a trade
	    ntrades++;
	    if (numMyTrades>mytrades) { // Then I was part of the trade.
		mytrades = numMyTrades;
		mylasttime=t;
		prices[ntrades]=-1;
		int myProfit;
		tradelist[p]++;
		if (isBuyer)
		    myProfit = token[mytrades] - tradePrice;
		else
		    myProfit = tradePrice - token[mytrades];
		gprofit+=myProfit;
		rprofit+=myProfit;
		pprofit+=myProfit;
		profitlist[p]+=myProfit;
	    }
	    else {
		prices[ntrades]=tradePrice;
	    }
	    lasttime = t;
	    btrades[b]++;
	    strades[s]++;
	}
	bstype = tradeType;
	price = tradePrice;
	buyer = b;
	seller = s;
	cbid = currentBid;
	cask = currentAsk;
	asker = currentAsker;
	bidder = currentBidder;
	playerBuySellEnd();
    }


    final public void periodEnd(int profit, int eff) {
	System.out.println(name+" P:"+profit+" E:"+eff);
	if (profit!=pprofit)
	    System.out.println("Error!  Robot "+userId+"'s profit does not match correctly at the end of the game.");
	peff = eff;
	playerPeriodEnd();
    }

    // !!!!!!  Still need to 'copy' the tokenValue information into the robot's memory
    final public void roundEnd( int profit, int eff, int buyerTokenValues[], int sellerTokenValues[] ) {
	System.out.println(name+" P:"+profit+" E:"+eff);
	if (profit!=rprofit)
	    System.out.println("Error!  Robot "+userId+"'s profit does not match correctly at the end of the game.");
	reff = eff;
	playerRoundEnd();
    }


    final public void gameEnd(int profit, int eff) {
	System.out.println(name+" P:"+profit+" E:"+eff);
	if (profit!=gprofit) {
	    System.out.println("Error!  Robot "+userId+"'s profit "+gprofit+" does not match correctly at the end of the game.");
	}
	efficiency = eff;
	playerGameEnd();
    }








    //
    // Past this point are the methods that may be overridden
    //

    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {}

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {}

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {
	
	return 0;
    }

    public int playerRequestAsk() {
	
	return 0;
    }
    
    public int playerRequestBuy() {
	
	return 0;
    }

    public int playerRequestSell() {
	
	return 0;
    } 



}
