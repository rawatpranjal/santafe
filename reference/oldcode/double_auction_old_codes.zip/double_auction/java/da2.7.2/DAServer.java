import java.net.*;
import java.io.*;
import java.sql.*;

// The servlet allows users to log on and verifies their login information.
// If it is valid, the DAPlayerCom object is passed to DAPlayerHandler for
// further processing.
public class DAServer {
    private SPlayerHandler playerHandler;
    private Connection conn = null;
    private PreparedStatement loginQuery;
    private DatabaseMetaData dbmd;

    public static void main(String[] args) {
	DAServer myServlet = new DAServer();
	myServlet.running();
    }

    public void running() {
	playerHandler = new SPlayerHandler();
	playerHandler.start();
	try {
	    connectToDatabase();
	    ServerSocket serverSock = new ServerSocket(1453);
	    while(true) {
		Socket sock = serverSock.accept();
		SPlayerCom com = new SPlayerCom(sock);
		if (verify(com))
		    playerHandler.takePlayer(com);
		else
		    com.close();
		try { Thread.sleep(200); } catch (InterruptedException e) {}
	    }
	}
	catch (IOException ex) { System.out.println("DAServlet IO Exception"); }
	catch (SQLException ex) { System.out.println("Connection to database failed."); }
    }

    private boolean verify(SPlayerCom com) throws SQLException {
	String username = com.waitForLine();
	String password = com.waitForLine();
	loginQuery.setString(1, username);
	loginQuery.setString(2, password);
	ResultSet rs = loginQuery.executeQuery();
	if (rs.next()) {
	    com.sendLine("accepted");
	    System.out.println(username +" logged on successfully.");
	    com.setUser(username);
	    return true;
	}
	com.sendLine("rejected");
	System.out.println(username +" gave an invalid password.");
	return false;
    }

    private void connectToDatabase() throws SQLException {
	try { Class.forName(Global.driver); }
	catch ( ClassNotFoundException e ) { System.out.println("postgresql Driver not found."); }
	conn = DriverManager.getConnection(Global.database, Global.username, Global.password);
	dbmd = conn.getMetaData();
  	System.out.println("Connection to "+dbmd.getDatabaseProductName()+" "+dbmd.getDatabaseProductVersion()+" successful.\n");
	loginQuery = conn.prepareStatement("select * from users where username = ? and password = ?");
    }
}
