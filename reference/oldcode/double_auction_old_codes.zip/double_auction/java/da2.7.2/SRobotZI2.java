import java.util.*;

// Zero Intelligence 2
// playerNumber = 0004
public class SRobotZI2  extends SRobotSkeleton {

    public final static String robotType = "Zero Intelligence 2";
    public final static int robotNum = 4;
    public final static int rolePref = 3;

    public SRobotZI2 () {
	super(robotType, robotNum, rolePref);
    } 

    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {}

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {}

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {


	int newbid;
	
	if (nobidask>0) return 0;	/* nothing left to trade */

	if ((cbid > 0) && (cbid <= token[mytrades+1]))
	    newbid=token[mytrades+1]-(int)(drand()*(token[mytrades+1]-cbid));
	else if ((cbid > 0) && (cbid > token[mytrades+1]))
	    newbid=minprice;
	else
	    newbid=token[mytrades+1]-(int)(drand()*(token[mytrades+1]-minprice));
	
	newbid=(newbid < minprice)? minprice : newbid;
	newbid=(newbid > maxprice)? maxprice : newbid;
	
	return (newbid);
    }

    public int playerRequestAsk() {

	int newoffer;

	if (nobidask>0) return 0;	/* nothing left to trade */

	if ((cask > 0) && (cask >= token[mytrades+1]))
	    newoffer=token[mytrades+1]+(int)(drand()*(maxprice-token[mytrades+1]));
	else if ((cask > 0) && (cask < token[mytrades+1]))
	    newoffer=maxprice;
	else
	    newoffer=token[mytrades+1]+(int)(drand()*(maxprice-token[mytrades+1]));

	newoffer=(newoffer > maxprice)? maxprice : newoffer;
	newoffer=(newoffer < minprice)? minprice : newoffer;
   
	return (newoffer);
    }
    
    public int playerRequestBuy() {
	if (nobuysell>0) return 0;
	if (token[mytrades+1] <= cask) return 0;	/* don't buy at a loss! */
	if (id==bidder && cbid>=cask) return 1;	/* accept offer <= our bid */
	return 0;
  }



	public int playerWantToSell() {

	    if (nobuysell>0) return 0;
	    if (cbid <= token[mytrades+1]) return 0;	/* don't sell at a loss! */
	    if (id==asker && cask<=cbid) return 1;	/* accept bid >= our offer */
	    return 0;
	} 


}
