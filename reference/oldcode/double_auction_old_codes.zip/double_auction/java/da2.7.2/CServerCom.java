import java.io.*;
import java.net.*;

public class CServerCom extends Thread {

    private int port;
    private String location;
    private Socket socket = null;
    private PrintWriter out = null;
    private BufferedReader in = null;

    private boolean keepRunning=true;
    private boolean isConnected;

    private CGameController myRegistrant = null;

    public CServerCom(CServerCom oldCom) {
	oldCom.stopListening();
	port = oldCom.port;
	location = oldCom.location;
	socket = oldCom.socket;
	out = oldCom.out;
	in = oldCom.in;
	keepRunning = true;
	isConnected = true;
	myRegistrant = null;
    }

    public CServerCom(String l, int p) {
        location = l;
	port = p;
	isConnected=true;
	try {
	    socket = new Socket(location, port);
	    out = new PrintWriter(socket.getOutputStream(), true);
	    in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	} catch (IOException e) {
	    System.out.println("Error creating new CServerCom");
	    isConnected=false;
	}
    }

    public void sendLine(String s) { 
	if (Global.DEBUG_MODE)
	    System.out.println("Sending:"+s);
	out.println(s); 
    }

    public String waitForLine() {
	String line = "";
	try {
	    line = in.readLine();
	} catch (IOException e) {
	    keepRunning=false;
	    System.out.println("Error in waitForLine()");
	}
	if (Global.DEBUG_MODE)
	    System.out.println("Received:"+line);
	return line;
   }

    public void register(CGameController reg) {
	myRegistrant = reg;
    }

    public void run() {
	while (keepRunning) {
	    try {
		if (in.ready()) {
		    String line=in.readLine();
		    if (Global.DEBUG_MODE)
			System.out.println("Received:"+line);
		    myRegistrant.receiveMessage(line);
		}
	    } catch (IOException e) {
		myRegistrant.receiveMessage("FATAL ERROR");
		System.out.println("Error in communications in run()!");
		keepRunning=false;
	    }
	}
    }

    public void stopListening() { keepRunning = false; }

    public boolean isConnected() { return isConnected; }
}

