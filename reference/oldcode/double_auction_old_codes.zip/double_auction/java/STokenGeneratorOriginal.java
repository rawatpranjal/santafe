import java.util.*;

public class STokenGeneratorOriginal extends STokenGenerator {

    private int[] w;
    private int A;
    private int B1, B2;
    private int[] C;

    public STokenGeneratorOriginal (int i) {
	typeId=i;
	determineRandomWeights(i);
    }

    private void determineRandomWeights(int i) {
	w = new int[5];
	for (int x=1;x<=4;x++) {
	    w[x]=i/((int)Math.pow(10,4-x));
	    i-=w[x]*Math.pow(10,4-x);
	    w[x]=(int)Math.pow(3,w[x])-1;
	}
	System.out.println(w[1]+" "+w[2]+" "+w[3]+" "+w[4]);
    }

    public void newRoundCalculations() {
	A = ranGen.nextInt(w[1]+1);
	B1 = ranGen.nextInt(w[2]+1);
	B2 = ranGen.nextInt(w[2]+1);
	C = new int[numTokens*2+1];
	for (int x=1;x<=numTokens*2;x++)
	    C[x] = ranGen.nextInt(w[3]+1);
    }
	
    public TokenGroup generateTokens(boolean isBuyer) {
	TokenGroup result = new TokenGroup(numTokens, isBuyer);
	int[] tokens = new int[numTokens+1];
	if (isBuyer)
	    for (int x=1;x<=numTokens;x++)
		tokens[x] = A+B1+C[x]+ranGen.nextInt(w[4]+1);
	else
	    for (int x=1;x<=numTokens;x++)
		tokens[x] = A+B2+C[numTokens+x]+ranGen.nextInt(w[4]+1);
	Arrays.sort(tokens);
	if (isBuyer)
	    for (int x=numTokens;x>=1;x--)
		result.addTokenValue(tokens[x]);
	else	
	    for (int x=1;x<=numTokens;x++)
		result.addTokenValue(tokens[x]);

	return result;
    }
}
	
