import java.util.*;

// Handles the player communication objects while they are in the menu, and
// hands them off to the appropriate Handler when the player makes a menu
// selection
public class SPlayerHandler extends Thread {
    ArrayList<SPlayerCom> myPlayers;
    SGameHandler myGameHandler;

    public SPlayerHandler() {
	myPlayers = new ArrayList<SPlayerCom>();
	myGameHandler = new SGameHandler(this);
	myGameHandler.start();
    }
    
    public void takePlayer(SPlayerCom com) {
	synchronized (myPlayers) {
	    myPlayers.add(com);
	}
	System.out.println(com.getUser()+" accepted by player handler");
    }

    public void run() {
	while (true) {
	    try { sleep(200); } catch (InterruptedException e) {}
	    synchronized (myPlayers) {
		Iterator pIterator = myPlayers.iterator();
		while (pIterator.hasNext()) {
		    SPlayerCom pCom = ((SPlayerCom)(pIterator.next()));
		    String message = pCom.getLine();
		    if (!message.equals("")) {
			if (message.equals("logout")) {
			    pIterator.remove();
			    System.out.println(pCom.getUser()+" has logged out.");
			}
			else if (message.equals("game")) {
			    System.out.println(pCom.getUser()+" would like to join a game.");
			    pIterator.remove();
			    myGameHandler.takePlayer(pCom);
			}
			else if (message.equals("close")) {
			    System.out.println(pCom.getUser()+" has closed the applet without logging out.");
			    pIterator.remove();
			}
		    }
		    else if (!pCom.isConnected()) {
			pIterator.remove();
			System.out.println("Communications failed with "+pCom.getUser()+"!");
		    }
		}
	    }	
	    try { sleep(200); } catch (InterruptedException e) {}
	}
    }
}
