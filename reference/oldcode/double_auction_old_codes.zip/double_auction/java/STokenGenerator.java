import java.util.*;

public abstract class STokenGenerator {
    
    int numTokens;
    int typeId;
    Random ranGen = new Random();
    
    // Tells the Token Generator that a new round has begun, and that all TokenGroups in this
    // round have numT tokens. Calls newRoundCalculations(), which extending classes must
    // implement.
    final public void newRound(int numT) {
	numTokens = numT;
	newRoundCalculations();
    }

    final public int getTypeId() { return typeId; }

    // Returns a random integer between 0 and i, inclusive.
    final public int randInt(int i) { return ranGen.nextInt(i+1); }

    // Returns a random double between 0.0 and 1.0
    final public double randDouble() { return ranGen.nextDouble(); }


    // Implemented by subclasses to do any necessary calculations each round, such as calculating
    // random weights that change each round. numTokens has already been set to the correct number
    // of tokens for the round when this method is called.  If no calculations are necessary, it
    // can be implemented as an empty method.
    public abstract void newRoundCalculations();
    
    // Returns a TokenGroup of token values for a buyer is isBuyer is true, and for a seller
    // if isBuyer is false.  The token group must have numTokens tokens in it.
    public abstract TokenGroup generateTokens(boolean isBuyer);

}
    
