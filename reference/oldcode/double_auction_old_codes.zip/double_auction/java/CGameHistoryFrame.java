import javax.swing.*;

public class CGameHistoryFrame extends JFrame {

    private JTabbedPane roundPanes;
    private CRoundHistoryPane currentRound;
    private int roundCount;
    
    public CGameHistoryFrame() {
	super("Game History");
	setSize(700,500);
	setLocation(450,500);
	setVisible(true);
	roundPanes = new JTabbedPane();
	roundCount=0;
	add(roundPanes);
	setDefaultCloseOperation(HIDE_ON_CLOSE);
    }

    public void newRound() {
	roundCount++;
	currentRound = new CRoundHistoryPane();
	roundPanes.addTab("Round "+roundCount, currentRound);
	roundPanes.setSelectedComponent(currentRound);
    }

    public void addPeriodGraph(CPeriodGraph graph) {
	if (graph.getPeriodNumber()==1)
	    newRound();
	currentRound.addPeriodGraph(graph);
    }

    public void addRoundGraph(CRoundGraph graph) {
	currentRound.addRoundGraph(graph);
    }

}
