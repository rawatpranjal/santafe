import java.util.*;

public class RoundHistory {
    private int roundNumber	;

    private int numPeriods;

    private int numTimes;

    private int numBuyers;

    private int numSellers;

    private int numTokens;

    private int currentPeriod;

    private int uPriceBound, lPriceBound;

    private PeriodHistory[] period;

    private TokenGroup[] sellerTokenGroup;
    private TokenGroup[] buyerTokenGroup;

    private int[] buyerTokenValues;
    private int[] sellerTokenValues;
    private int eqPrice;
    private int maxSurplus;

    private int[] buyerProfit;
    private int[] sellerProfit;
    private int totalProfit;

    private int[] buyerEff;
    private int[] sellerEff;
    private int totalEff;


    // Used by RoundHistory objects on the client side.
    private int myId; // 0 for a server side object
    private boolean iAmBuyer;

    public RoundHistory(int rN, int nP, int nT, int nB, int nS, int uB, int lB, int id, int nTk, boolean buyer) {
	roundNumber=rN;
	numPeriods=nP;
	numTimes=nT;
	numBuyers=nB;
	numSellers=nS;
	uPriceBound = uB;
	lPriceBound = lB;
	numTokens = nTk;
	myId=id;
	iAmBuyer=buyer;

	period = new PeriodHistory[numPeriods+1];
	sellerTokenGroup = new TokenGroup[numSellers+1];
	buyerTokenGroup = new TokenGroup[numBuyers+1];
	buyerProfit = new int[nB+1];
	sellerProfit = new int[nS+1];
	buyerEff = new int[nB+1];
	sellerEff = new int[nS+1];
	currentPeriod=0;
    }

    public boolean incrementPeriod() {
	if (currentPeriod>0) {
	    for (int x=1;x<=numBuyers;x++)
		buyerProfit[x]+=period[currentPeriod].getProfit(true, x);
	    for (int x=1;x<=numSellers;x++)
		sellerProfit[x]+=period[currentPeriod].getProfit(false, x);
	}
	currentPeriod++;
	if (currentPeriod>numPeriods)
	    return false;
	TokenGroup t;
	if (iAmBuyer)
	    t=buyerTokenGroup[myId];
	else
	    t=sellerTokenGroup[myId];
	PeriodHistory p = new PeriodHistory(currentPeriod, numTimes, numBuyers, numSellers, uPriceBound, lPriceBound, myId, iAmBuyer, t, buyerTokenGroup, sellerTokenGroup);
	period[currentPeriod]=p;
	return true;
    }

    public void addTokenGroup(TokenGroup tg, boolean isBuyer, int i) {
	if (isBuyer)
	    buyerTokenGroup[i]=tg;
	else
	    sellerTokenGroup[i]=tg;
    }

    public int getTokenValue(boolean isBuyer, int i, int t) {
	TokenGroup tg;
	if (isBuyer)
	    tg = buyerTokenGroup[i];
	else
	    tg = sellerTokenGroup[i];
	return
	    tg.getTokenValue(t);
    }

    public PeriodHistory getCurrentPeriod() { return period[currentPeriod]; }

    public int getNumPeriods() { return numPeriods; }

    public int getRoundNumber() { return roundNumber; }

    public PeriodHistory getPeriod(int p) { return period[p]; }

    public int getCurrentPeriodNumber() { return currentPeriod; }

    public int getNumTokens() { return numTokens; }

    public int getUpperPriceBound() { return uPriceBound; }

    public int getLowerPriceBound() { return lPriceBound; }
    
    public void setMyEfficiency(int e) {
	if (iAmBuyer)
	    buyerEff[myId]=e;
	else
	    sellerEff[myId]=e;
    }

    public int getMyEfficiency() {
	if (iAmBuyer)
	    return buyerEff[myId];
	else
	    return sellerEff[myId];
    }

    public boolean iAmBuyer() { return iAmBuyer; }

    public int getMyProfit() {
	if (iAmBuyer)
	    return buyerProfit[myId];
	else
	    return sellerProfit[myId];
    }

    public int getProfit(boolean buyer, int i) {
	if (buyer)
	    return buyerProfit[i];
	else
	    return sellerProfit[i];
    }

    public int getTotalProfit() { return totalProfit; }

    public int getTotalEfficiency() { return totalEff; }

    public int getEfficiency(boolean buyer, int i) {
	if (buyer)
	    return buyerEff[i];
	else
	    return sellerEff[i];
    }

    public int getEquilibriumPrice() { return eqPrice; }

    public int getMaxSurplus() { return maxSurplus; }

    public void setBuyerTokenValues(int[] values) {
	buyerTokenValues = values;
    }

    public void setSellerTokenValues(int[] values) {
	sellerTokenValues = values;
    }

    public int[] getBuyerTokenValues() { return buyerTokenValues; }

    public int[] getSellerTokenValues() { return sellerTokenValues; }

    // Determined the clearing price in competitive equilibrium
    // as well as the total possible surplus.
    // MUST be called AFTER all TokenGroups have been assigned.
    public void calculateEquilibrium() {
	buyerTokenValues = new int[numTokens*numBuyers+1];
	sellerTokenValues = new int[numTokens*numSellers+1];
	for (int x=1;x<=numBuyers;x++) {
	    TokenGroup tg = buyerTokenGroup[x];
	    if (tg!=null)
		for (int y=1;y<=numTokens;y++)
		    buyerTokenValues[(x-1)*numTokens+y] = tg.getTokenValue(y);
	}
	Arrays.sort(buyerTokenValues);
	for (int x=1;x<=numSellers;x++) {
	    TokenGroup tg = sellerTokenGroup[x];
	    if (tg!=null)
		for (int y=1;y<=numTokens;y++)
		    sellerTokenValues[(x-1)*numTokens+y] = tg.getTokenValue(y);
	}
	Arrays.sort(sellerTokenValues);
	System.out.println("Buyer Token Values:");
	for (int x=numBuyers*numTokens;x>0;x--)
	    System.out.print(buyerTokenValues[x]+" ");
	System.out.println();
	System.out.println("Seller Token Values:");
	for (int x=1;x<=numSellers*numTokens;x++)
	    System.out.print(sellerTokenValues[x]+" ");
	System.out.println();


	int x=1;
	while (sellerTokenValues[x]==0) x++;
	int y=1;
	while (buyerTokenValues[y]==0) y++;
	int maxTradesPossible = Math.min(numSellers*numTokens-x+1,numBuyers*numTokens-y+1);
	System.out.println("Max Trades Possible: "+maxTradesPossible);
	maxSurplus=0;
	y = numBuyers*numTokens;
	int diff = 0;
	for (int z=1;z<=maxTradesPossible;z++) {
	    diff = buyerTokenValues[y]-sellerTokenValues[x];
	    System.out.println("Difference "+z+": "+diff);
	    if (diff>0)
		maxSurplus += diff;
	    else {
		if (z==1) // no trades are possible.
		    System.out.println("Error, no profitable trades are possible.");
		else {
		    int d2 = Math.abs(diff);
		    double p2 = (double)(buyerTokenValues[y]+sellerTokenValues[x])/2.0;
		    y++;
		    x--;
		    int d1 = buyerTokenValues[y]-sellerTokenValues[x];
		    double p1 = (double)(buyerTokenValues[y]+sellerTokenValues[x])/2.0;

		    double p1weight = (double)d2/(double)(d1+d2);
		    double p2weight = (double)d1/(double)(d1+d2);
		    eqPrice = (int)(p1*p1weight+p2*p2weight);
		    System.out.println("EqPrice: "+eqPrice);
		}
		z = maxTradesPossible+1;
	    }
	    x++;
	    y--;
	}
	// if diff > 0 here, it means all possible trades were profitable ones.  Can happen with small number of players, or
	// if buyer token values tend to be much greater than seller token values.
	if (diff > 0) {
	    x--;
	    y++;
	    eqPrice = (int)(buyerTokenValues[y]+sellerTokenValues[x])/2;
	}
    }

    public void calculateEfficiencies() {
	totalProfit=0;
	for (int x=1;x<=numPeriods;x++)
	    totalProfit+=period[x].getTotalProfit();
	totalEff = (100*totalProfit)/(maxSurplus*numPeriods);
	TokenGroup tg;
	for (int x=1;x<=numBuyers;x++) {
	    if (buyerProfit[x]==0)
		buyerEff[x]=0;
	    else {
		int maxProfit = buyerTokenGroup[x].getMaxProfit(eqPrice);
		if (maxProfit<=0)
		    buyerEff[x]=-1;
		else
		    buyerEff[x] = (100*buyerProfit[x])/(maxProfit*numPeriods);
	    }
	}
	for (int x=1;x<=numSellers;x++) {
	    if (sellerProfit[x]==0)
		sellerEff[x]=0;
	    else {
		int maxProfit = sellerTokenGroup[x].getMaxProfit(eqPrice);
		if (maxProfit<=0)
		    sellerEff[x]=-1;
		else
		    sellerEff[x] = (100*sellerProfit[x])/(maxProfit*numPeriods);
	    }
	}

    }


}
