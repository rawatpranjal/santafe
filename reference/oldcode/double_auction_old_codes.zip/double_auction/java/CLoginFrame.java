import javax.swing.*;
import java.awt.event.*;
import java.net.*;

public class CLoginFrame extends JFrame implements ActionListener {

    private String userId, password;
    private DAClient myClient;
    private JTextField messageField, userIdEntry;
    private JPanel buttonPanel, userPanel;
    private JButton loginButton, quitButton;
    private JLabel userIdLabel, passwordLabel;
    private JPasswordField passwordEntry;

    //
    private JTextField addressField, portField; 

    public CLoginFrame (DAClient c) {
	super("Double Auction Client");
	setup();
	myClient = c;
    }
	
    private void setup() {
	setUndecorated(true);
	getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	setDefaultLookAndFeelDecorated(true);

	setupUserPanel();
	setupButtonPanel();

	messageField = new JTextField(20);
	messageField.setEditable(false);

	add("North", userPanel);
	add("Center", messageField);
	add("South", buttonPanel);

	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
 
	setVisible(true);
	setSize(700,150);
	setLocationRelativeTo(null);
	setResizable(false);

    }

    private void setupUserPanel() {
	userPanel = new JPanel();
	
	passwordLabel = new JLabel("Password:");
	passwordEntry = new JPasswordField(6);
	passwordEntry.setEchoChar('*');

	userIdLabel = new JLabel("UserId:");
	userIdEntry = new JTextField(15);

	addressField = new JTextField(20);
	portField = new JTextField(5);
	addressField.setText("bach.econ.umd.edu");
	portField.setText("1453");

	userPanel.add(userIdLabel);
	userPanel.add(userIdEntry);
	userPanel.add(passwordLabel);
	userPanel.add(passwordEntry);
	userPanel.add(addressField);
	userPanel.add(portField);
    }

    private void setupButtonPanel() {
	buttonPanel = new JPanel();

	loginButton = new JButton("Login");
	loginButton.addActionListener(this);

	quitButton = new JButton("Quit");
	quitButton.addActionListener(this);
	
	buttonPanel.add(loginButton);
	buttonPanel.add(quitButton);
    }


    private void quitButtonPressed() {
	setVisible(false);
	dispose();
	System.exit(0);
    }

    private void loginButtonPressed() {
	userId = getId();
	password = getPassword();
	if ((userId.equals(""))||(password.equals("")))
	    setMessageText("Sorry, but password and userId must be non-empty.");
	else {
	    CServerCom com = new CServerCom(addressField.getText(), Integer.parseInt(portField.getText()));
	    if (com.isConnected()) {
		com.sendLine(userId);
		com.sendLine(password);
		String response = com.waitForLine();
		System.out.println(response);
		if (response.equals("accepted")) {
		    setMessageText("");
		    myClient.selectLogIn(com, userId);
		}
		else {
		    setMessageText("Sorry, that login is invalid.");
		}
	    }
	    else
		setMessageText("Sorry, unable to connect at this time.");
	}
    }

    public String getId() {
	return userIdEntry.getText().trim();
    }
        
    public String getPassword() {
	return (new String(passwordEntry.getPassword())).trim();
    } 

    public void setMessageText(String s) {
	messageField.setText(s);
    }
    
    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if (source==loginButton)
	    loginButtonPressed();
	else if (source==quitButton)
	    quitButtonPressed();
    }

}
