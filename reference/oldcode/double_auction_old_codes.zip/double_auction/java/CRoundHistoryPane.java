import javax.swing.*;

public class CRoundHistoryPane extends JTabbedPane {

    public CRoundHistoryPane() {
	super();
    }

    public void addPeriodGraph(CPeriodGraph graph) {
	addTab(("Period "+graph.getPeriodNumber()), graph);
	setSelectedComponent(graph);
    }

    public void addRoundGraph(CRoundGraph graph) {
	addTab("Trading Summary",graph);
	setSelectedComponent(graph);
    }
}
