import java.net.*;

public class Global {
 
    public static URL codeBaseURL;
    public static boolean runningAsApplet=true;
    public static final boolean DEBUG_MODE=false;

    public static final int ACCEPT = 1;
    public static final int BID = 2;
    public static final int BIDASK = 3;
    public static final int BADISP = 4;
    public static final int BSDISP = 5;
    public static final int BUY = 6;
    public static final int BUYSELL = 7;
    public static final int CBID = 8;
    public static final int CASK = 9;
    public static final int GAME = 11;
    public static final int KILLED = 98;
    public static final int LENGTH = 12;
    public static final int LIMITS = 13;
    public static final int NONE = 14;
    public static final int NUMBER = 15;
    public static final int ASK = 16;
    public static final int PERIOD = 17;
    public static final int PLAYER = 18;
    public static final int PRICES = 19;
    public static final int QUIT = 99;
    public static final int READY = 20;
    public static final int REFUSE = 21;
    public static final int ROUND = 27;
    public static final int ROLE = 22;
    public static final int SELL = 23;
    public static final int BUYERS = 29;
    public static final int SELLERS = 30;
    public static final int TEST = 31;
    public static final int TOKENS = 28;
    public static final int TRADE = 24;
    public static final int TRADERS = 25;
    public static final int TYPE = 26;
    public static final int ENDPERIOD = 40;
    public static final int ENDROUND = 41;
    public static final int ENDGAME = 42;
    public static final int ROUNDSUMMARY = 101;

    public static final String database="jdbc:postgresql://beethoven.econ.umd.edu/da?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
    public static final String username="rthenkel";
    public static final String password="ot9Aihae";
    public static final String driver="org.postgresql.Driver";
}
