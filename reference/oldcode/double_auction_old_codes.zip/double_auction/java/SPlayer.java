public abstract class SPlayer {
    String userId="";
    int playerNumber=0;
    String name="";
    int type=0; // 1=Human 2=Robot 4=Observer
    int rolePreference=0; // 1=B 2=S 3=E 4=Observer
    boolean isBuyer;
    int id;
    boolean hasResponded=false;

    public SPlayer(String id, int pref, int t) {
	userId = id;
	rolePreference = pref;
	type = t;
    }

    final public void setPlayerNumber(int pN) { playerNumber = pN; }

    final public void setIsBuyer(boolean b) { isBuyer = b; }

    final public void setName(String n) { name = n; }

    final public void setId(int i) {id = i;}

    final public void setType(int t) {type = t;}

    final public String getUserId() { return userId; }

    final public String getName() { return name; }
    
    final public int getRolePreference() { return rolePreference; }

    final public int getType() { return type; }

    final public int getPlayerNumber() { return playerNumber; }

    final public boolean isBuyer() { return isBuyer; }
    
    final public int getId() { return id; }
    
    final public boolean hasResponded() { return hasResponded; }

    final public String getIdTag() {
	if (isBuyer)
	    return "B"+id;
	else
	    return "S"+id;
    }
    
    // Sends the initialization 1 info to the player, and returns true if they are willing to play.
    abstract public boolean initialization1(int gameType, int gameId, int nR, int nP, int nT, int maxTok, int maxBuy, int maxSel, int role, int timeout);

    // Sends the initialization 2 info to the player, and returns true if they are ready to play.
    abstract public boolean initialization2(int nBuy, int nSell, int[] buyerNumbers, int[] sellerNumbers, int minPrice, int maxPrice, int id);
	
    // Sends the information on a new round to the player, and returns true if they are ready to play.
    abstract public boolean roundStart(int r, int nTokens, TokenGroup tokenGroup);

    // Sends the information on a new round to the player, and returns true if they are ready to play.
    abstract public boolean periodStart(int r, int p);

    // Sends the bid ask info to the player
    // MUST SET hasResponded to false!!!
    abstract public void bidAsk(int t, int nobidask);

    // Gets the bid ask response from the player.
    // 0 is no bid/ask
    // -1 is Quit
    // -2 is Error
    // MUST SET hasResponded to true if there is a real response.  If there is no response yet, hasResponded should remain false, 
    // and the return value should be -3
    abstract public int bidAskResponse();

    // Sends the results of the bidAsk stage to the player
    abstract public void bidAskResult(int status, int numTrades, int numNewBids, int[] bidPrice, int[] bidder, int numNewAsks, int[] askPrice, int[] asker, int currentBid, int currentBidder, int currentAsk, int currentAsker);

    // Sends the buy sell info to the player.
    // MUST SET hasResponded to false!!!
    abstract public void buySell(int t, int nobuysell);

    // Gets the buy sell response from the player.
    // 0 is no bid/ask
    // -1 is Quit
    // -2 is Error
    // MUST SET hasResponded to true if there is a real response.  If there is no response yet, hasResponded should remain false, 
    // and the return value should be -3
    // A positive response should equal the amount the buy or sell request is for.
    abstract public int buySellResponse();
    
    // tradeType == 0 for no trade, 1 for BUY request accepted, 2 for SELL request accepted
    abstract public void buySellResult(int status, int numTrades, int tradeType, int tradePrice, int buyer, int seller, int currentBid, int currentBidder, int currentAsk, int currentAsker);
    
    abstract public void periodEnd(int profit, int efficiency);

    abstract public void roundEnd(int profit, int efficiency, int[] buyerTokenValues, int[] sellerTokenValues);
    
    abstract public void gameEnd(int profit, int efficiency);

    public String getLine() {
	return "";
    }
    
    public void sendLine(String s) {} 

    public SPlayerCom getPlayerCom() {
	return null;
    }



}
