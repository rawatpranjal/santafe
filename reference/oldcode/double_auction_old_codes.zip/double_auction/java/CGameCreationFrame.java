import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class CGameCreationFrame extends JFrame implements ActionListener {
 
    private JComboBox minHumansChoice;
    private JComboBox maxHumansChoice;
    private static int minHumans=0;
    private static int maxHumans=4;

    private JComboBox numRobotsChoice;
    private static int minRobots=0;
    private static int maxRobots=16;

    private JComboBox minTokensChoice;
    private JComboBox maxTokensChoice;
    private static int minTokens = 2;
    private static int maxTokens = 8;

    private JComboBox minWaitTimeChoice;
    private JComboBox maxWaitTimeChoice;
    private static String[] waitTimeOptions = {"0","10", "30", "60", "120", "300", "600"};
    private JComboBox timeoutChoice;
    private static String[] timeoutOptions = {"15", "30", "60"};

    private JComboBox numRoundsChoice;
    private static String[] numRoundsOptions = {"1", "2", "3", "5", "10"};
    private JComboBox numPeriodsChoice;
    private static String[] numPeriodsOptions = {"1", "2", "3", "5", "10"};
    private JComboBox numTimesChoice;
    private static String[] numTimesOptions = {"5", "10", "15", "25", "40"};

    private JButton submitButton, cancelButton;
    private JPanel optionPanel, buttonPanel, myPanel;
    private CRobotSelectionFrame robotSelectionFrame;
    
    private CServerCom myCom;
    private CGameSelectionFrame mySelector;
    
    public CGameCreationFrame(CServerCom com, CGameSelectionFrame gameSelector) {
	super("Game Specifications");
	mySelector=gameSelector;
	myCom=com;
	setup();
    }
    
    private void setup() {
	setUndecorated(true);
	getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	setDefaultLookAndFeelDecorated(true);
	
	setupOptionPanel();
	setupButtonPanel();


	add("North", optionPanel);
	add("South", buttonPanel);
    
	setSize(500,500);
	setLocationRelativeTo(null);
	setResizable(false);
	setVisible(false);
    }

    private void setupOptionPanel() {
	optionPanel = new JPanel();
	// GridLayout must be passed the number of options as its first parameter. 
	GridLayout aLayout = new GridLayout(11,1);
	optionPanel.setLayout(aLayout);
	
	optionPanel.add(numRoundsPanel());
	optionPanel.add(numPeriodsPanel());
	optionPanel.add(numTimesPanel());
	optionPanel.add(minHumansPanel());
	optionPanel.add(maxHumansPanel());
	optionPanel.add(numRobotsPanel());
	optionPanel.add(minTokensPanel());
	optionPanel.add(maxTokensPanel());
	optionPanel.add(minWaitTimePanel());
	optionPanel.add(maxWaitTimePanel());
	optionPanel.add(timeoutPanel());
    }
	
    private JPanel numRoundsPanel() {
	myPanel = new JPanel();
	numRoundsChoice = new JComboBox(numRoundsOptions);
	numRoundsChoice.setSelectedIndex(2);
	myPanel.add(new JLabel("Number of Rounds in the Game:"));
	myPanel.add(numRoundsChoice);
	return myPanel;
    }
    
    private JPanel numPeriodsPanel() {
	myPanel = new JPanel();
	numPeriodsChoice = new JComboBox(numPeriodsOptions);
	numPeriodsChoice.setSelectedIndex(2);
	myPanel.add(new JLabel("Number of Periods per Round:"));
	myPanel.add(numPeriodsChoice);
	return myPanel;
    }
    
    private JPanel numTimesPanel() {
	myPanel = new JPanel();
	numTimesChoice = new JComboBox(numTimesOptions);
	numTimesChoice.setSelectedIndex(2);
	myPanel.add(new JLabel("Number of Timesteps per Period:"));
	myPanel.add(numTimesChoice);
	return myPanel;
    }
    
    private JPanel minHumansPanel() {
	myPanel = new JPanel();
	minHumansChoice = new JComboBox();
	for (int x=minHumans;x<=maxHumans;x++)
	    minHumansChoice.addItem(x);
	minHumansChoice.setSelectedIndex(1);
	minHumansChoice.addActionListener(this);
	myPanel.add(new JLabel("Minimum number of Human Players: "));
	myPanel.add(minHumansChoice);
	return myPanel;
    }
    
    private JPanel maxHumansPanel() {
	myPanel = new JPanel();
	maxHumansChoice = new JComboBox();
	for (int x=minHumans;x<=maxHumans;x++)
	    maxHumansChoice.addItem(x);
	maxHumansChoice.setSelectedIndex(1);
	maxHumansChoice.addActionListener(this);
	myPanel.add(new JLabel("Maximum number of Human Players: "));
	myPanel.add(maxHumansChoice);
	return myPanel;
    }
    
    private JPanel numRobotsPanel() {
	myPanel = new JPanel();
	numRobotsChoice = new JComboBox();
	for (int x=minRobots;x<=maxRobots;x++)
	    numRobotsChoice.addItem(x);
	numRobotsChoice.addActionListener(this);
	myPanel.add(new JLabel("Number of Robots:"));
	myPanel.add(numRobotsChoice);
	return myPanel;
    }
    
    private JPanel minTokensPanel() {
	myPanel = new JPanel();
	minTokensChoice = new JComboBox();
	for (int x=minTokens;x<=maxTokens;x++)
	    minTokensChoice.addItem(x);
	minTokensChoice.setSelectedIndex(1);
	minTokensChoice.addActionListener(this);
	myPanel.add(new JLabel("Minimum number of Tokens per period: "));
	myPanel.add(minTokensChoice);
	return myPanel;
    }

    private JPanel maxTokensPanel() {
	myPanel = new JPanel();
	maxTokensChoice = new JComboBox();
	for (int x=minTokens;x<=maxTokens;x++)
	    maxTokensChoice.addItem(x);
	maxTokensChoice.setSelectedIndex(3);
	maxTokensChoice.addActionListener(this);
	myPanel.add(new JLabel("Maximum number of Tokens per period: "));
	myPanel.add(maxTokensChoice);
	return myPanel;
    }
    
    private JPanel minWaitTimePanel() {
	myPanel = new JPanel();
	minWaitTimeChoice = new JComboBox(waitTimeOptions);
	minWaitTimeChoice.setSelectedIndex(0);
	myPanel.add(new JLabel("Minimum Wait Time (seconds): "));
	myPanel.add(minWaitTimeChoice);
	return myPanel;
    }

    private JPanel maxWaitTimePanel() {
	myPanel = new JPanel();
	maxWaitTimeChoice = new JComboBox(waitTimeOptions);
	maxWaitTimeChoice.setSelectedIndex(2);
	myPanel.add(new JLabel("Maximum Wait Time (seconds): "));
	myPanel.add(maxWaitTimeChoice);
	return myPanel;
    }

    private JPanel timeoutPanel() {
	myPanel = new JPanel();
	timeoutChoice = new JComboBox(timeoutOptions);
	timeoutChoice.setSelectedIndex(1);
	myPanel.add(new JLabel("Timeout Length (seconds): "));
	myPanel.add(timeoutChoice);
	return myPanel;
    }
    
    private void setupButtonPanel() {
	submitButton = new JButton("Create Game");
	submitButton.addActionListener(this);
	
	cancelButton = new JButton("Cancel");
	cancelButton.addActionListener(this);

	buttonPanel = new JPanel();
	buttonPanel.add(submitButton);
	buttonPanel.add(cancelButton);
    }

    private void cancelButtonPressed() {
	setVisible(false);
	dispose();
	mySelector.setVisible(true);
    }

    private void submitButtonPressed() {
	String gameDetails = "game";
	gameDetails += " maxHumans " +maxHumansChoice.getSelectedItem();
	gameDetails += " minHumans "+minHumansChoice.getSelectedItem();
	gameDetails += " minWaitTime "+minWaitTimeChoice.getSelectedItem();
	gameDetails += " maxWaitTime "+maxWaitTimeChoice.getSelectedItem();
	gameDetails += " minTokens "+minTokensChoice.getSelectedItem();
	gameDetails += " maxTokens "+maxTokensChoice.getSelectedItem();
	gameDetails += " timeout "+timeoutChoice.getSelectedItem();
	gameDetails += " numRounds "+numRoundsChoice.getSelectedItem();
	gameDetails += " numPeriods "+numPeriodsChoice.getSelectedItem();
	gameDetails += " numTimes "+numTimesChoice.getSelectedItem();
	if (robotSelectionFrame!=null) {
	    gameDetails = gameDetails + robotSelectionFrame.getRobotString();
	    robotSelectionFrame.setVisible(false);
	    robotSelectionFrame.dispose();
	    robotSelectionFrame=null;
	}
	System.out.println("|"+gameDetails+"|");
	myCom.sendLine(gameDetails);
	mySelector.submittedGame();
    }

    private void numRobotsChanged() {
	int numRobots = ((Integer)numRobotsChoice.getSelectedItem()).intValue();
	setTitle(""+numRobots);
	if (robotSelectionFrame!=null) {
	    robotSelectionFrame.setVisible(false);
	    robotSelectionFrame.dispose();
	}
	robotSelectionFrame = new CRobotSelectionFrame(numRobots);
	robotSelectionFrame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	int index;
	if (source==cancelButton)
	    cancelButtonPressed();
	else if (source==submitButton)
	    submitButtonPressed();
	else if (source==numRobotsChoice)
	    numRobotsChanged();
	else if (source==minHumansChoice) {
	    index = minHumansChoice.getSelectedIndex();
	    if (index>maxHumansChoice.getSelectedIndex())
		maxHumansChoice.setSelectedIndex(index);
	}
	else if (source==maxHumansChoice) {
	    index = maxHumansChoice.getSelectedIndex();
	    if (index<minHumansChoice.getSelectedIndex())
		minHumansChoice.setSelectedIndex(index);
	}   
	else if (source==minTokensChoice) {
	    index = minTokensChoice.getSelectedIndex();
	    if (index>maxTokensChoice.getSelectedIndex())
		maxTokensChoice.setSelectedIndex(index);
	}
	else if (source==maxTokensChoice) {
	    index = maxTokensChoice.getSelectedIndex();
	    if (index<minTokensChoice.getSelectedIndex())
		minTokensChoice.setSelectedIndex(index);
	}   
	else if (source==minWaitTimeChoice) {
	    index = minWaitTimeChoice.getSelectedIndex();
	    if (index>maxWaitTimeChoice.getSelectedIndex())
		maxWaitTimeChoice.setSelectedIndex(index);
	}
	else if (source==maxWaitTimeChoice) {
	    index = maxWaitTimeChoice.getSelectedIndex();
	    if (index<minWaitTimeChoice.getSelectedIndex())
		minWaitTimeChoice.setSelectedIndex(index);
	}   

    } 
}
