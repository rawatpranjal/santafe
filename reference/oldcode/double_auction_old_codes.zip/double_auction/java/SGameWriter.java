import java.net.*;
import java.io.*;
import java.sql.*;
//import java.sql.Timestamp;

public class SGameWriter extends Thread {

   private GameHistory myHistory;
   private Connection myConnect;
   private PreparedStatement mySQLStatement;
   private DatabaseMetaData myDbMd;

   public SGameWriter(GameHistory gh) {
      myHistory=gh;
   }

   public void run() {
       connectToDatabase();
       writeGameInfo();
       //      writePlayers();
       //      writeTokens();
       //      writeTransactions();
       //      writeProposals();
       //      writeTimeSteps();
       //      disconnectFromDatabase();
   }

   public boolean connectToDatabase() {

      try {
         Class.forName(Global.driver);
      }
      catch(ClassNotFoundException e) {
         System.out.println("Cannot find driver to database");
         return false;
      }
      try {
        myConnect=DriverManager.getConnection(Global.database,Global.username,Global.password);
        myDbMd=myConnect.getMetaData();
        System.out.println("Connection to"+myDbMd.getDatabaseProductName()+" "+myDbMd.getDatabaseProductVersion()+" successful.\n");
      }
      catch(SQLException ex) {
         System.out.println("Connection to DA database failed: unable to write game history for GameID "+myHistory.getGameId());
         return false;
      }

      return true;
   }

   public void disconnectFromDatabase() {
       try {
          myConnect.close();
       }
       catch(SQLException ex) {
        System.out.println("Problem closing connection to database.\n");
       }
       System.out.println("Successfully disconnected from DA database.\n");
   }

   public void writeGameInfo() {

      System.out.println("entered writeGameInfo for game ID "+myHistory.getGameId()+".\n");
      try {
         String sqlStatement="insert into game (gameid,user_id,gamename,gametype,notes,gamestart,gameend) values(?,?,?,?,?,?,?)";
	 System.out.println("1");
	 mySQLStatement=myConnect.prepareStatement(sqlStatement);
	 System.out.println("2");
         mySQLStatement.setInt(1,1);
	 System.out.println("3");
         mySQLStatement.setString(2,"test user");
         mySQLStatement.setString(3,myHistory.getGameName());
         mySQLStatement.setInt(4,myHistory.getGameType());
         mySQLStatement.setString(5,"test notes text goes here");
         mySQLStatement.setTimestamp(6,new Timestamp(System.currentTimeMillis()));
         mySQLStatement.setTimestamp(7,new Timestamp(System.currentTimeMillis()));
	 System.out.println("4");
         mySQLStatement.executeUpdate();
	 System.out.println("5");
      }
      catch(SQLException ex) {
        System.out.println("Problem writing game info.\n");
	System.out.println(ex.getMessage()+" "+ex.getSQLState());

      }
      System.out.println("finished writeGameInfo.\n");


   }
}
