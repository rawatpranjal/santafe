import java.util.*;

public class SGameHandler extends Thread {
    static int gameIds=0;
    ArrayList<SPlayerCom> myPlayers;
    ArrayList<SPlayerCom> waitingPlayers;
    ArrayList<SGameInitializer> myGames;
    SPlayerHandler myPlayerHandler;
    SGameStringParser myParser;

    public SGameHandler(SPlayerHandler myPH) {
	myPlayerHandler = myPH;
	myPlayers = new ArrayList<SPlayerCom>();
	waitingPlayers = new ArrayList<SPlayerCom>();
	myGames = new ArrayList<SGameInitializer>();
	myParser = new SGameStringParser(this);
    }

    public void takePlayer(SPlayerCom com) {
	synchronized (waitingPlayers) {
	    waitingPlayers.add(com);
	}
	System.out.println(com.getUser()+" accepted by game handler");
    }

    public void run() {
	while (true) {
	    Iterator pIterator = myPlayers.iterator();
	    while (pIterator.hasNext()) {
		SPlayerCom pCom = ((SPlayerCom)(pIterator.next()));
		String message = pCom.getLine();
		if (!message.equals(""))
		    if (message.equals("refresh")) {
			System.out.println(pCom.getUser()+" would like to refresh their list of games.");
			sendGameList(pCom);
		    }
		    else if (message.equals("back")) {
			System.out.println(pCom.getUser()+" is going back to the main menu.");
			pIterator.remove();
			myPlayerHandler.takePlayer(pCom);
		    }
		    else if (message.equals("close")) {
			System.out.println(pCom.getUser()+" has closed the applet without logging out.");
			pIterator.remove();
		    }
		    else {
			String messageType = message.substring(0,4);
			if (messageType.equals("game")) {
			    if (playerCreateGame(pCom, message)) {
				System.out.println(pCom.getUser()+" has created a new game.");
				pCom.sendLine("game");
			    }
			    else {
				System.out.println(pCom.getUser()+" has failed to create a new game.");
				pCom.sendLine("fail");
			    }	    
			}
			else if (messageType.equals("join")) {
			    if (playerJoinGame(pCom))
				pIterator.remove();
			    else
				pCom.sendLine("fail");
			}
		    }
		else if (!pCom.isConnected()) {
		    pIterator.remove();
		    System.out.println("Communications failed with "+pCom.getUser()+"!");
		}
	    }
	    synchronized (waitingPlayers) {
		pIterator = waitingPlayers.iterator();
		while (pIterator.hasNext()) {
		    SPlayerCom pCom = ((SPlayerCom)(pIterator.next()));
		    pIterator.remove();
		    myPlayers.add(pCom);
		}
	    }	
	    try { sleep(200); } catch (InterruptedException e) {}
	}
    }	    

    private void sendGameList(SPlayerCom pCom) {
	synchronized (myGames) {
	    pCom.sendLine(myGames.size()+"");
	    Iterator gIterator = myGames.iterator();
	    while (gIterator.hasNext()) {
		SGameInitializer aGame = (SGameInitializer)(gIterator.next());
		if (aGame.getStatus().equals("CLEARING"))
		    gIterator.remove();
		String status[] = aGame.getStatusString();
		for (String s : status)
		    pCom.sendLine(s);
	    }
	}
    }

    private boolean playerCreateGame(SPlayerCom pCom, String gameDetails) {
	gameIds++;
	SGameInitializer newGame = myParser.parseGameString(pCom, gameIds, gameDetails);
	synchronized (myGames) {
	    myGames.add(newGame);
	}
	newGame.start();
	return true;
    }

    private boolean playerJoinGame(SPlayerCom pCom) {
	int gameId = Integer.parseInt(pCom.getLine());
	System.out.println("Game "+gameId);
	SGameInitializer desiredGame = null;
	synchronized (myGames) {
	    Iterator gIterator = myGames.iterator();
	    while ((gIterator.hasNext())&&(desiredGame==null)) {
		SGameInitializer aGame = (SGameInitializer)(gIterator.next());
		if (aGame.getGameId()==gameId)
		    desiredGame=aGame;
	    }   
	}
	if (desiredGame==null)
	    return false;
	else
	    return desiredGame.addPlayer(pCom);
    }
	
}
