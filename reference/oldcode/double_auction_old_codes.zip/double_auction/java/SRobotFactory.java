public class SRobotFactory {

    public SPlayer makeRobot(int robotNumber) {
	if (robotNumber < 100)
	    return oldRobot(robotNumber);
	else
	    return newRobot(robotNumber);
    }

    private SPlayer robotGroupChooser(int rN) {
	return null;
    }

    private SPlayer oldRobot(int rN) {
	if (rN==1)
	    return new SRobotExample();
	else if (rN==2)
	    return new SRobotKaplan();
	else if (rN==3)
	    return new SRobotZI1();
	else if (rN==4)
	    return new SRobotZI2();
	else if (rN==5)
	    return new SRobotLin();
	else if (rN==6)
	    return new SRobotJacobson();
	else if (rN==7)
	    return new SRobotPerryOriginal();
	else
	    return null;
    }

    private SPlayer newRobot(int rN) {
	return null;
    }
}
      
