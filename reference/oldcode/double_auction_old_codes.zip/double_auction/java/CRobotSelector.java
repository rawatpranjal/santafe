import java.net.*;
import java.io.*;
import javax.swing.*;
import java.util.*;

public class CRobotSelector {

    private String[] selectionName;

    private int numRobots;
    private String[] robotId;
    private String[] robotName;

    private int numGroups;
    private RobotGroup[] group;

    private Random rand = new Random();

    private URL robotConfigURL;

    private BufferedReader infile;

    public CRobotSelector() {
	if (Global.runningAsApplet)
	    createURLConnection();
	readConfigFile();
	createSelectionNames();
    }

    public JComboBox getRobotChooser() {
	return new JComboBox(selectionName);
    }

    public String getIdNumber(String selection) {
	for (int x=0;x<numRobots;x++)
	    if (robotName[x].equals(selection))
		return robotId[x];
	for (int x=0;x<numGroups;x++)
	    if (group[x].getName().equals(selection))
		return group[x].chooseMember();
	return null;
    }

    private void createURLConnection() {
	if (Global.runningAsApplet) {
	    try { robotConfigURL = new URL(Global.codeBaseURL, "robots.config.txt"); }
	    catch ( MalformedURLException e ) { System.out.println("Error connecting to URL:robots.config"); }
	}
    } 

    private void setInput() throws IOException {
	if (Global.runningAsApplet) {
	    URLConnection conn = robotConfigURL.openConnection();
	    conn.connect();
	    System.out.println("URL connected to...");
	    infile = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	}
	else {
	    infile = new BufferedReader(new FileReader("robots.config.txt"));
	}
    }
	    
    private void readConfigFile() {
	countSelections();
	readSelections();
    }

    private void createSelectionNames() {
	for (int x=0;x<numGroups;x++)
	    selectionName[x]=group[x].getName();
	for (int x=numGroups;x<numGroups+numRobots;x++)
	    selectionName[x]=robotName[x-numGroups];
	for (String s : selectionName)
	    System.out.println("|"+s+"|");
    }

    private void countSelections() {
	numRobots=0;
	numGroups=0;
	try {
	    setInput();
	    String s = infile.readLine();
	    while (s!= null) {
		s = s.trim();
		if (!s.equals("")) {
		    char c = s.charAt(0);
		    if (c=='"')
			numGroups++;
		    else if ((c>='0')&&(c<='9'))
			numRobots++;
		}
		s = infile.readLine();
	    }
	    infile.close();
	} catch (IOException e) { System.out.println("Failed to read robots.config"); }
	robotId = new String[numRobots];
	robotName = new String[numRobots];
	group = new RobotGroup[numGroups];
	selectionName = new String[numRobots+numGroups];

    }

    private void readSelections() {
	int robotIndex=0;
	int groupIndex=0;
	try {
	    setInput();
	    String s = infile.readLine();
	    while (s!= null) {
		s = s.trim();
		if (!s.equals("")) {
		    char c = s.charAt(0);
		    if (c=='"') {
			group[groupIndex]=new RobotGroup(s);
			groupIndex++;
		    }
		    else if ((c>='0')&&(c<='9')) {
			int nameBeginsAt = s.indexOf('"');
			int nameEndsAt = s.indexOf('"', nameBeginsAt+1);
			robotId[robotIndex]= s.substring(0,nameBeginsAt).trim();
			robotName[robotIndex]=s.substring(nameBeginsAt+1,nameEndsAt);
			robotIndex++;
		    }
		}
		s = infile.readLine();
					}
	} catch (IOException e) { System.out.println("Failed to read robots.config"); }
    }

    private class RobotGroup {

	private String name;
	private int numMembers;
	private String[] memberId;

	public RobotGroup(String s) {
	    processString(s);
	}

	private void processString(String s) {
	    s = s.trim();
	    int firstQuote = s.indexOf('"');
	    int secondQuote = s.indexOf('"',firstQuote+1);
	    name = s.substring(firstQuote+1,secondQuote);
	    s = s.substring(secondQuote+1,s.length()).trim();
	    String[] terms = s.split("\\s",0);
	    countMembers(terms);
	    parseMembers(terms);
	}

	private void countMembers(String[] t) {
	    numMembers=0;
	    for (String s : t)
		if (!s.equals(""))
		    numMembers++;
	    memberId = new String[numMembers];
	}

	private void parseMembers(String[] t) {
	    int index=0;
	    for (String s : t)
		if (!s.equals("")) {
		    memberId[index]=s;
		    index++;
		}
	}

	public String chooseMember() {
	    int index=(rand.nextInt(numMembers));
	    return memberId[index];
	}

	public String getName() {
	    return name;
	}

	public int getNumMembers() {
	    return numMembers;
	}
    }
}



