public class STokenGeneratorFactory {
    
    public STokenGenerator makeFactory(int i) {
	return new STokenGeneratorOriginal(i);
    }
}
