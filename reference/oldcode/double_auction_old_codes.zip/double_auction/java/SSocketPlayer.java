public class SSocketPlayer extends SPlayer {
    
    SPlayerCom myPlayerCom;
    int nobuysell;
    int nobidask;

    SSocketPlayer(SPlayerCom pCom, int pref) {
	super(pCom.getUser(), pref, 1);
	name = pCom.getName();
	playerNumber = pCom.getPlayerNumber();
	myPlayerCom = pCom;
    }
  
    // Sends the initialization 1 info to the player, and returns true if they are willing to play.
    public boolean initialization1(int gameType, int gameId, int nR, int nP, int nT, int maxTok, int maxBuy, int maxSell, int role, int timeout) {
	myPlayerCom.sendLine("start");
	sendPacket(Global.GAME,gameType,gameId);
	sendPacket(Global.LENGTH,nR,0);
	sendPacket(Global.LENGTH,nP,nT);
	sendPacket(Global.TOKENS,maxTok,0);
	sendPacket(Global.NUMBER,maxBuy,maxSell);
	sendPacket(Global.ROLE,role,timeout);
	if (role==1)
	    isBuyer=true;
	else
	    isBuyer=false;
	int[] r = getPlayerResponse();
	if (r.length!=2)
	    return false;
	if ((r[0]==Global.ACCEPT)&&(r[1]==playerNumber))
	    return true;
	return false;
    }

    // Sends the initialization 2 info to the player, and returns true if they are ready to play.
    public boolean initialization2(int nBuy, int nSell, int[] buyerNumbers, int[] sellerNumbers, int minPrice, int maxPrice, int i) {
	sendPacket(Global.NUMBER, nBuy, nSell);
	int x;
	for (x=1;x<nBuy;x+=2)
	    sendPacket(Global.BUYERS, buyerNumbers[x], buyerNumbers[x+1]);
	if (x==nBuy)
	    sendPacket(Global.BUYERS, buyerNumbers[x], 0);
	for (x=1;x<nSell;x+=2)
	    sendPacket(Global.SELLERS, sellerNumbers[x], sellerNumbers[x+1]);
	if (x==nSell)
	    sendPacket(Global.SELLERS, sellerNumbers[x], 0);
	sendPacket(Global.LIMITS, minPrice, maxPrice);
	sendPacket(Global.PLAYER, i, 0);
	id = i;
	return isReady();
    }
	
    // Sends the information on a new round to the player, and returns true if they are ready to play.
    public boolean roundStart(int r, int nTokens, TokenGroup tokenGroup) {
	sendPacket(Global.ROUND, r, nTokens);
	int x;
	for (x=1;x<nTokens;x+=2)
	    sendPacket(Global.PRICES,tokenGroup.getTokenValue(x),tokenGroup.getTokenValue(x+1));
	if (x==nTokens)
	    sendPacket(Global.PRICES,tokenGroup.getTokenValue(x),0);
	return isReady();
    }

    // Sends the information on a new round to the player, and returns true if they are ready to play.
    public boolean periodStart(int r, int p) {
	sendPacket(Global.PERIOD, r, p);
	return isReady();
    }

    // Sends the bid ask info to the player, and returns their bid/ask for the current time, which must be 0 if nobidask != 0
    public void bidAsk(int t, int noba) {
	sendPacket(Global.BIDASK, t, noba);
	nobidask = noba;
	hasResponded=false;
    }
    
    public int bidAskResponse() {
	String response = getLine();
	if (response.equals(""))
	    return -3;

	int r[] = parsePlayerResponse(response);
	hasResponded=true;

	if (r.length != 2)
	    return -2;
	else if (r[0]==Global.QUIT)
	    return -1;
	else if ((r[0]==Global.BID)&&isBuyer&&(nobidask==0))
	    return r[1];
	else if ((r[0]==Global.ASK)&&(!isBuyer)&&(nobidask==0))
	    return r[1];
	else if ((r[0]==Global.NONE)&&(r[1]==0))
	    return 0;
	else {
	    System.out.println("Error! "+userId+" responded in the bid/ask stage with invalid code/offer: "+r[0]+"|"+r[1]);
	    return 0;
	}
    }
   

    // Sends the results of the bidAsk stage to the player
    public void bidAskResult(int status, int numTrades, int numNewBids, int[] bidPrice, int[] bidder, int numNewAsks, int[] askPrice, int[] asker, int currentBid, int currentBidder, int currentAsk, int currentAsker) {
	sendPacket(Global.BADISP, status, numTrades);
	for (int x=1;x<=numNewBids;x++)
	    sendPacket(Global.BID, bidPrice[x], bidder[x]);
	for (int x=1;x<=numNewAsks;x++)
	    sendPacket(Global.ASK, askPrice[x], asker[x]);
	sendPacket(Global.CBID, currentBid, currentBidder);
	sendPacket(Global.CASK, currentAsk, currentAsker);
    }

    // Sends the buy sell info to the player, and returns whether they wish to make a trade.  Must return 0 if nobuysell != 0
    public void buySell(int t, int nobs) {
	sendPacket(Global.BUYSELL, t, nobs);
	nobuysell=nobs;
	hasResponded=false;
    }

    public int buySellResponse() {
	String response = getLine();
	if (response.equals(""))
	    return -3;

	int r[] = parsePlayerResponse(response);
	hasResponded=true;
	if (r.length != 2)
	    return -2;
	else if (r[0]==Global.QUIT)
	    return -1;
	else if ((r[0]==Global.BUY)&&isBuyer&&(nobuysell==0))
	    return r[1];
	else if ((r[0]==Global.SELL)&&(!isBuyer)&&(nobuysell==0))
	    return r[1];
	else if ((r[0]==Global.NONE)&&(r[1]==0))
	    return 0;
	else {
	    System.out.println("Error! "+userId+" responded in the buy/sell stage with invalid code/request: "+r[0]+"|"+r[1]);
	    return 0;
	}
    }


    // 
    // tradeType == 0 for no trade, 1 for BUY request accepted, 2 for SELL request accepted
    public void buySellResult(int status, int numTrades, int tradeType, int tradePrice, int buyer, int seller, int currentBid, int currentBidder, int currentAsk, int currentAsker) {
	sendPacket(Global.BSDISP, status, numTrades);
	if (tradeType!=0) {
	    sendPacket(Global.TRADE, tradeType, tradePrice);
	    sendPacket(Global.TRADERS, buyer, seller);
	}
	sendPacket(Global.CBID, currentBid, currentBidder);
	sendPacket(Global.CASK, currentAsk, currentAsker);
    }
    
    public void periodEnd(int profit, int efficiency) {
	sendPacket(Global.ENDPERIOD, profit, efficiency);
    }

    public void roundEnd(int profit, int efficiency, int[] buyerTokenValues, int[] sellerTokenValues) {
	sendPacket(Global.ROUNDSUMMARY, buyerTokenValues.length, sellerTokenValues.length);
	String buyerTokenString = "";
	String sellerTokenString = "";
	for (int x=1;x<buyerTokenValues.length;x++)
	    buyerTokenString = buyerTokenString.concat(buyerTokenValues[x]+" ");
	for (int x=1;x<sellerTokenValues.length;x++)
	    sellerTokenString = sellerTokenString.concat(sellerTokenValues[x]+" ");
	sendLine(buyerTokenString);
	sendLine(sellerTokenString);
	sendPacket(Global.ENDROUND, profit, efficiency);
    }
    
    public void gameEnd(int profit, int efficiency) {
	sendPacket(Global.ENDGAME, profit, efficiency);
    }

    public void sendPacket(int code, int a, int b) {
	myPlayerCom.sendLine(code + " "+a+" "+b);
    }

    private boolean isReady() {
	int[] r = getPlayerResponse();
	if (r.length!=2)
	    return false;
	if (r[0]!=Global.READY)
	    return false;
	if (r[1]!=id)
	    return false;
	return true;
    }

    private int[] getPlayerResponse() {
	String r = myPlayerCom.waitForLine();
	return parsePlayerResponse(r);
    }

    private int[] parsePlayerResponse(String r) {
	if (r.equals("")) {
	    System.out.println("Error! "+userId+"is asking to parse an empty string!");
	    return new int[0];
	}
	String[] reply = r.split("\\s");
	if (reply.length != 2) {
	    System.out.println("Error! "+userId+" responded with an invalid format! : "+r);
	    return new int[0];
	}
	int[] result = new int[2];
	result[0] = Integer.parseInt(reply[0]);
	result[1] = Integer.parseInt(reply[1]);
	return result;
    }
	
    public String getLine() {
	return myPlayerCom.getLine();
    }

    public void sendLine(String s) {
	myPlayerCom.sendLine(s);
    }

    public SPlayerCom getPlayerCom() {
	return myPlayerCom;
    }

}
