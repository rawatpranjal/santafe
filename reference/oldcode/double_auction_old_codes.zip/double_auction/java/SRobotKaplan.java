import java.util.*;

// KaplanRobot
// playerNumber = 0002
public class SRobotKaplan extends SRobotSkeleton {

    public final static String robotType = "KaplanRobot";
    public final static int robotNum = 2;
    public final static int rolePref = 3;

    public SRobotKaplan() {
	super(robotType, robotNum, rolePref);
    } 



    public int minpr, maxpr, avepr;

    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {}

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {
	int t1;
	avepr=0;
	minpr=abs(prices[1]);
	maxpr=abs(prices[1]);
	if (role==1) maxpr+=-100; else minpr+=100;
	for (t1=1; t1<=ntrades; t1++)
	    {if (role==2)  
		{if (maxpr<abs(prices[t1])) maxpr=abs(prices[t1]);
		if (minpr>(prices[t1]) && prices[t1]>0) minpr=abs(prices[t1]);}
	    else 
		{if (maxpr<prices[t1]) maxpr=abs(prices[t1]);
		if (minpr>abs(prices[t1])) minpr=abs(prices[t1]);}  
	    avepr+=abs(prices[t1]); } 
	if (ntrades>0) avepr=avepr/ntrades; 
    }

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {
	int most, newbid;

	if (nobidask>0) return 0;	/* nothing left to trade */
	if (cbid == 0) {
	    most = token[ntokens]-1;
	    if (cask>0 && cask<most) most = cask;
	    newbid = minprice+1;
	}
	else {
	    most = token[mytrades+1]-1;
	    newbid = minprice+1;
	    if (cask>0 && cask<most) most = cask;
	    if (most <= cbid) return 0;
	    
	    /* jump in if it is profitable and cbid is close to coffer */
	    if ((((double)(cask-cbid))/((double)(cask+1)))<0.10) {
		if (((((double)(token[mytrades+1]+1))*.98-cask)>0) && (p==1 ||
									 cask<=maxpr)) newbid=cask;} 
	    /* jump in if price is better than last period */
	    if ((p>1) && (cask<=minpr)) newbid=cask; 
	    
	    /* if time is running out or if its been a while, jump in */
	    if ((t-lasttime)>=(ntimes-t)/2 || ((t-mylasttime)>=2*(ntimes-t)/3 && t-lasttime>=5)) newbid = cask;
	    if (newbid > most) newbid=most;
	}
	
	return ((newbid<minprice)? minprice : newbid);
    }

    public int playerRequestAsk() {
	int least, newoffer;

	if (nobidask>0) return 0;	/* nothing left to trade */
	if (cask == 0) {
	    least = token[ntokens]+1;
	    if (cbid > least) least = cbid;
	    newoffer = maxprice - 1;
	}
	else {
	    newoffer= maxprice - 1;
	    least = token[mytrades+1]+1;
	    if (cbid > least) least = cbid;
	    if (least >= cask) return 0;
	    if ((((double)(cask-cbid))/((double)(cbid+1)))<.10) {
		if (((((double)(token[mytrades+1]+1))*1.02-cbid)<0)  && (p==1 ||
									 cbid>=minpr)) newoffer=cbid;}
	    if ((p>1) && (cbid>=maxpr)) newoffer=cbid;
	    if ((t-lasttime)>=(ntimes-t)/2 || ((t-mylasttime)>=2*(ntimes-t)/3 && t-lasttime>=5)) newoffer=cbid;
	    if (newoffer < least) newoffer=least;
	}
	
	return ((newoffer>maxprice)? maxprice : newoffer);
    }
    
    public int playerRequestBuy() {
	if (nobuysell>0) return 0;
	if (token[mytrades+1] <= cask) return 0;	/* don't buy at a loss! */
	if (id==bidder && cbid>=cask) return 1;	/* accept offer <= our bid */
	if  (ntimes-t<=2)
	    return 1;
	else
	    return 0;
    }

    public int playerWantToSell() {
	if (nobuysell>0) return 0;
	if (cbid <= token[mytrades+1]) return 0;	/* don't sell at a loss! */
	if (id==asker && cask<=cbid) return 1;	/* accept bid >= our offer */
	if  (ntimes-t<=2)                           /* accept if time is short */
	    return 1;
	else
	    return 0;
    } 


}
