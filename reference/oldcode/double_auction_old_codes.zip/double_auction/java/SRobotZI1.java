import java.util.*;

// ZeroIntelligence1
// playerNumber = 0003
public class SRobotZI1 extends SRobotSkeleton {

    public final static String robotType = "ZeroIntelligence1";
    public final static int robotNum = 3;
    public final static int rolePref = 3;

    public SRobotZI1() {
	super(robotType, robotNum, rolePref);
    } 

    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {}

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {}

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {
	int newbid;
	if (nobidask>0) return 0;	/* nothing left to trade */
	newbid=token[mytrades+1]-(int)(drand()*(token[mytrades+1]-minprice));
	return ((newbid<minprice)? minprice : newbid);
    }

    public int playerRequestAsk() {
	int newask;
	if (nobidask>0) return 0;	/* nothing left to trade */
	newask=token[mytrades+1]+(int)(drand()*(maxprice-token[mytrades+1]));
	return ((newask>maxprice)? maxprice : newask);
    }
    
    public int playerRequestBuy() {
	if (nobuysell>0) return 0;
	if (token[mytrades+1] <= cask) return 0;	/* don't buy at a loss! */
	if (id==bidder && cbid>=cask) return 1;	/* accept offer <= our bid */
	return 0;
    }

    public int playerWantToSell() {
	if (nobuysell>0) return 0;
	if (cbid <= token[mytrades+1]) return 0;	/* don't sell at a loss! */
	if (id==asker && cask<=cbid) return 1;	/* accept bid >= our offer */
	return 0;
    } 


}
