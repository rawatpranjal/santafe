import java.net.*;
import javax.swing.*;
import javax.swing.plaf.metal.*;
import java.applet.*;

// The Mediator and Controller for the program
public class DAClient extends Applet {
    private String myUserId;
    private CLoginFrame loginFrame;
    private CMenuFrame menuFrame;
    private CGameSelectionFrame gameSelectionFrame;
    private CGameController gameController;

    private CServerCom myCom;
    private int[] resolution = {800,600};

    public static void main(String[] args) {
	DAClient client = new DAClient();
	Global.runningAsApplet=false;
	client.init();
    }
       
    public void init() {
	try {
	    UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
	    MetalLookAndFeel.setCurrentTheme(new DefaultMetalTheme());
	} 
	catch (UnsupportedLookAndFeelException e) {}
	catch (ClassNotFoundException e) {}
	catch (InstantiationException e) {}
	catch (IllegalAccessException e) {}

	if (Global.runningAsApplet)
	    Global.codeBaseURL=(getCodeBase());

	startClient();
    }

    public void stop() {
	if (myCom!=null)
	    myCom.sendLine("close");
    }

    private void startClient() {
	loginFrame = new CLoginFrame(this);
    }

    public void selectLogIn(CServerCom com, String userId) {
	myUserId = userId;
	myCom=com;
	loginFrame.setVisible(false);
	menuFrame = new CMenuFrame(this);
    }

    public void selectPlayGame() {
	myCom.sendLine("game");
	menuFrame.setVisible(false);
	gameSelectionFrame = new CGameSelectionFrame(myCom, this);
    }

    public void selectLogOut() {
	myCom.sendLine("logout");
	myCom=null;
	disposeOfFrame(menuFrame);
	menuFrame=null;
	loginFrame.setVisible(true);
    }
	
    public void selectBackToMenu() {
	gameSelectionFrame = null;
	menuFrame.setVisible(true);
	myCom.sendLine("back");
    }

    public void selectJoinGame(int rolePreference) {
	gameSelectionFrame = null;
	myCom = new CServerCom(myCom);
	gameController = new CGameController(this, myCom, rolePreference);
    }
	
    public void selectGameFinished() {
	gameController=null;
	gameSelectionFrame = new CGameSelectionFrame(myCom, this);
    }

    private void disposeOfFrame(JFrame frame) {
	if (frame!=null) {
	    frame.dispose();
	    frame.setVisible(false);
	}
    }

    public int[] getResolution() { return resolution; }

    public String getUser() { return myUserId; }
    
    
}

    
