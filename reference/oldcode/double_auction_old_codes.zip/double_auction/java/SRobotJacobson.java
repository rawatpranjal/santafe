import java.util.*;

// SRobotJacobson
// playerNumber = 0006
public class SRobotJacobson extends SRobotSkeleton {

    public final static String robotType = "SRobotJacobson";
    public final static int robotNum = 6;
    public final static int rolePref = 3;

    public SRobotJacobson () {
	super(robotType, robotNum, rolePref);
    } 


    private double roundpricesum;
    private double roundweight;
    private int lastgap;


    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {
	lastgap = 10000000;
	roundpricesum = 0.0;
	roundweight = 0.0;
    }

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {}

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {
	double weight;

	if (bstype!=0) {
	    weight = p + ntrades * 2;
	    roundpricesum += price * weight;
	    roundweight += weight;
	    lastgap = 10000000;
	}
	else
	    lastgap = cask - cbid;
    }
    
    public int playerRequestBid() {
       	double oldBid, newBid;
	double est, conf;
	
	if (nobidask > 0)
	    return 0;	/* nothing left to trade */
	
	oldBid = (double) ((cbid == 0) ? minprice : cbid);
	est = eqest();
	conf = eqconf();
	
	/* convex combination of old and equil est, baced on confidence */
	newBid = oldBid * (1.0 - conf) + est * conf + 1.0;
	
	if (newBid >= token[mytrades+1])
	    return 0;
	return (int) newBid;	
    }

    public int playerRequestAsk() {
	double oldAsk, newAsk;
	double est, conf;

	if (nobidask > 0)
	    return 0;	/* nothing left to trade */
	
	oldAsk = (double) ((cask == 0) ? maxprice : cask);
	est = eqest();
	conf = eqconf();
	
	/* convex combination of old and equil est, baced on confidence */
	newAsk = oldAsk * (1.0 - conf) + est * conf - 1.0;
	
	if (newAsk <= token[mytrades+1])
	    return 0;
	return (int) newAsk;
    }
    
    public int playerRequestBuy() {
	double          profit, gap;

	if (nobuysell > 0 || id != bidder)
	    return 0;
	
	profit = token[mytrades + 1] - cask;
	gap = cask - cbid;
	
	if (profit <= 0.0)
	    return 0;
	if (gap <= 0.0)
	    return 1;
	
	/* maybe capitulate if time left is getting low relative to
	   speed of gap closing */
	if ((int) gap == lastgap ||
	    (gap / (lastgap - gap)) * (ntokens - mytrades) * 2 + t > ntimes)
	    {
		if (profit / (profit + gap) > drand ())
		    return 1;
	    }
	return 0;
    }

    public int playerWantToSell() {
	double          profit, gap;
	
	if (nobuysell > 0 || id != seller)
	    return 0;
	
	profit = cbid - token[mytrades + 1];
	gap = cask - cbid;
	
	if (profit <= 0.0)
	    return 0;
	if (gap <= 0.0)
	    return 1;
	
	/* maybe capitulate if time left is getting low relative to
	   speed of gap closing */
	if ((int) gap == lastgap ||
	    (gap / (lastgap - gap)) * (ntokens - mytrades) * 2 + t > ntimes)
	    {
		if (profit / (profit + gap) > drand ())
		    return 1;
	    }
	
	return 0;
    }	

    private double eqest () {
	if (roundweight == 0.0)
	    return (double) token[ntokens];
	else
	    return roundpricesum/roundweight;
    }

    /* confidence in eq estimate, from 0.0 to 1.0 */
    private double eqconf () {
	if (roundweight == 0.0)
	    return 0.0;
	return Math.pow(.01, 1.0 / roundweight);
    }
} 



