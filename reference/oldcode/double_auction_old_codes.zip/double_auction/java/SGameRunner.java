import java.util.*;

public class SGameRunner extends Thread {

    private SGameInitializer myInitializer;
    private GameHistory history;
    private ArrayList<SPlayer> myPlayers;
    private STokenGenerator myTokenGenerator;
    private int rN, pN, tN;
    private int numPlayers;
    private PeriodHistory pHistory; // The current PeriodHistory
    private RoundHistory rHistory; // The current RoundHistory
    private int currentBidder, currentBid, currentAsker, currentAsk;
    private SGameHandler myHandler;
    private boolean failState=false;
    private int failReason=0; // 1 means either all buyers or all sellers dropped out.
    private int numSellers, numBuyers;

    public SGameRunner(SGameInitializer init, SGameHandler myH, GameHistory h, ArrayList<SPlayer> p, STokenGenerator myGen) {
	myInitializer = init;
	history = h;
	myPlayers = p;
	myTokenGenerator = myGen;
	numPlayers = myPlayers.size();
	myHandler = myH;
	numSellers = history.getNumSellers();
	numBuyers = history.getNumBuyers();
    }

    public void run() {
	while ((history.incrementRound())&&(!failState)) {
	    rHistory = history.getCurrentRound();
	    runRound();
	}
	if (!failState) {
	    history.calculateEfficiencies();
	    runEnd();
	    gameFinished();
	}
    }
    
    private void runEnd() {
       	Iterator pIterator = myPlayers.iterator();
	System.out.println("Total Game Profit: "+history.getTotalProfit());
	System.out.println("Total Game Efficiency: "+history.getTotalEfficiency());
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));	
	    int id = aPlayer.getId();
	    boolean isBuyer = aPlayer.isBuyer();
	    if (isBuyer)
		System.out.print("B"+id);
	    else
		System.out.print("S"+id);
	    aPlayer.gameEnd(history.getProfit(isBuyer,id), history.getEfficiency(isBuyer, id));
	}
	SGameWriter myWriter = new SGameWriter(history);
	myWriter.start();
    }

    private void runRound() {
	Iterator pIterator = myPlayers.iterator();
	int numTokens = rHistory.getNumTokens();
	myTokenGenerator.newRound(numTokens);
	TokenGroup tg;
	rN = rHistory.getRoundNumber();
	//System.out.println("Round: "+rN);
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    boolean ready;
	    if (aPlayer.getType()!=4) {
		tg = myTokenGenerator.generateTokens(aPlayer.isBuyer());
		rHistory.addTokenGroup(tg, aPlayer.isBuyer(), aPlayer.getId());
		ready = aPlayer.roundStart(rN, numTokens, tg);
	    }
	    else
		ready = aPlayer.roundStart(rN,0,null);

	    if (!ready) {
		    pIterator.remove();
		    sendPlayer(aPlayer);
		    playerFail(aPlayer);
	    }
	}
	rHistory.calculateEquilibrium();
	while ((rHistory.incrementPeriod())&&(!failState)) {
	    pHistory = rHistory.getCurrentPeriod();
	    runPeriod();
	}
	if (!failState) {
	    rHistory.calculateEfficiencies();
	    pIterator = myPlayers.iterator();
	    System.out.println("Round "+rN+" Profit: "+rHistory.getTotalProfit());
	    System.out.println("Round "+rN+" Efficiency: "+rHistory.getTotalEfficiency());
	    int[] buyerTokenValues = rHistory.getBuyerTokenValues();
	    int[] sellerTokenValues = rHistory.getSellerTokenValues();
	    while (pIterator.hasNext()) {
		SPlayer aPlayer = ((SPlayer)(pIterator.next()));
		boolean isBuyer = aPlayer.isBuyer();
		int id = aPlayer.getId();
		if (aPlayer.getType()!=4) {
		    if (isBuyer)
			System.out.print("B"+id);
		    else
			System.out.print("S"+id);
		}
		aPlayer.roundEnd(rHistory.getProfit(isBuyer,id),rHistory.getEfficiency(isBuyer,id),buyerTokenValues,sellerTokenValues);
	    }
	}
    }

    private void runPeriod() {
	pN = pHistory.getPeriodNumber();
	//System.out.println("Period: "+pN);
	Iterator pIterator = myPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    if (!aPlayer.periodStart(rN, pN)) {
		pIterator.remove();
		sendPlayer(aPlayer);
		playerFail(aPlayer);
	    }
	}
	while ((pHistory.incrementTime())&&(!failState))
	    runTime();
	if (!failState) {
	    pIterator = myPlayers.iterator();
	    pHistory.calculateEfficiencies(rHistory.getMaxSurplus(), rHistory.getEquilibriumPrice());
	    System.out.println("Period "+pN+" Profit: "+pHistory.getTotalProfit());
	    System.out.println("Period "+pN+" Efficiency: "+pHistory.getTotalEfficiency());
	    while (pIterator.hasNext()) {
		SPlayer aPlayer = ((SPlayer)(pIterator.next()));
		boolean isBuyer = aPlayer.isBuyer();
		int id = aPlayer.getId();
		if (aPlayer.getType()!=4) {
		    if (isBuyer)
			System.out.print("B"+id);
		    else
			System.out.print("S"+id);
		}
		aPlayer.periodEnd(pHistory.getProfit(isBuyer,id),pHistory.getEfficiency(isBuyer, id));
	    }
	}
    }
	
    private void runTime() {
	tN = pHistory.getCurrentTime();
	//System.out.println("Time: "+tN);
	bidAskStage();
	bidAskResponse();
	bidAskResult();
	buySellStage();
	buySellResponse();
	buySellResult();
	checkFailState();
    }

    private void bidAskStage() {
	Iterator pIterator = myPlayers.iterator();
	int numTokens = rHistory.getNumTokens();
	int nobidask;
	while (pIterator.hasNext()) {
	    nobidask=0;
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));	
	    if ((pHistory.getNumTrades(aPlayer.getId(),aPlayer.isBuyer())) >= numTokens)
		nobidask=1;
	    aPlayer.bidAsk(tN, nobidask);
	}
    }

    private void bidAskResponse() {
	ArrayList<SPlayer> yetToRespond = new ArrayList<SPlayer>();
	Iterator pIterator = myPlayers.iterator();
	SPlayer aPlayer;
	while (pIterator.hasNext()) {
	    aPlayer = ((SPlayer)(pIterator.next()));
	    yetToRespond.add(aPlayer);
	}
	while (yetToRespond.size()>0) {
	    pIterator = yetToRespond.iterator();
	    while (pIterator.hasNext()) {
		aPlayer = ((SPlayer)(pIterator.next()));
		int bidAskValue = aPlayer.bidAskResponse();
		if (aPlayer.hasResponded()) {
		    pIterator.remove();
		    if (bidAskValue==-1) {
			removePlayer(aPlayer);
			playerQuit(aPlayer);
		    }
		    else if (bidAskValue==-2) {
			removePlayer(aPlayer);
			playerFail(aPlayer);
		    }
		    else if (bidAskValue>0) {
			if (aPlayer.isBuyer()) {
			    if (!pHistory.addBid(aPlayer.getId(),bidAskValue))
				System.out.println("Error! "+aPlayer.getId()+" bid an invalid amount! : "+bidAskValue);
			}
			else
			    if (!pHistory.addAsk(aPlayer.getId(),bidAskValue))
				System.out.println("Error! "+aPlayer.getId()+" asked for an invalid amount! : "+bidAskValue);
		    }
		}	 
	    }   
	}
    }

    private void bidAskResult() {
	pHistory.determineTimeStepWinners();
	currentAsker=pHistory.getLowAsker(tN);
	currentBidder=pHistory.getHighBidder(tN);
	currentAsk=pHistory.getAsk(currentAsker,tN);
	currentBid=pHistory.getBid(currentBidder,tN);
	int newBids = pHistory.getNumNewBids();
	int newAsks = pHistory.getNumNewAsks();
	int[] bidPrices = new int[newBids+1];
	int[] bidders = new int[newBids+1];
	int[] askPrices = new int[newAsks+1];
	int[] askers = new int[newAsks+1];
	int index=0;
	for (int x=1;x<=pHistory.getNumBuyers();x++)
	    if (pHistory.madeNewOffer(x, true)) {
		index++;
		bidPrices[index]=pHistory.getBid(x,tN);
		bidders[index]=x;
	    }
	if (index!=newBids)
	    System.out.println("Error! new bids numbers don't match!");
	index=0;

	for (int x=1;x<=pHistory.getNumSellers();x++)
	    if (pHistory.madeNewOffer(x, false)) {
		index++;
		askPrices[index]=pHistory.getAsk(x,tN);
		askers[index]=x;
	    }
	if (index!=newAsks)
	    System.out.println("Error! new asks numbers don't match!");

	Iterator pIterator = myPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    int myStatus = pHistory.getOfferStatus(aPlayer.getId(), aPlayer.isBuyer());
	    int myTrades = pHistory.getNumTrades(aPlayer.getId(), aPlayer.isBuyer());
	    aPlayer.bidAskResult(myStatus, myTrades, newBids, bidPrices, bidders, newAsks, askPrices, askers, currentBid, currentBidder, currentAsk, currentAsker);
	}
    }

    private void buySellStage() {
	Iterator pIterator = myPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    int id=aPlayer.getId();
	    int numTrades;
	    int nobuysell=0;
	    if (aPlayer.isBuyer()) {
		numTrades = pHistory.getNumTrades(id,true);
		if (id!=currentBidder)
		    nobuysell+=4;
	    }
	    else {
		numTrades = pHistory.getNumTrades(id,false);
		if (id!=currentAsker)
		    nobuysell+=4;
	    }
	    if ((currentAsker==0)||(currentBidder==0))
		nobuysell+=2;
	    if (numTrades==rHistory.getNumTokens())
		nobuysell+=1;
	    aPlayer.buySell(tN, nobuysell);
	}
    }

    private void buySellResponse() {
	boolean buy=false;
	boolean sell=false;
	ArrayList<SPlayer> yetToRespond = new ArrayList<SPlayer>();
	Iterator pIterator = myPlayers.iterator();
	SPlayer aPlayer;
	while (pIterator.hasNext()) {
	    aPlayer = ((SPlayer)(pIterator.next()));
	    yetToRespond.add(aPlayer);
	}
	
	while (yetToRespond.size()>0) {
	    pIterator = yetToRespond.iterator();
	    while (pIterator.hasNext()) {
		aPlayer = ((SPlayer)(pIterator.next()));
		int buySellResult = aPlayer.buySellResponse();
		if (aPlayer.hasResponded()) {
		    pIterator.remove();
		    if (buySellResult==-1) {
			removePlayer(aPlayer);
			playerQuit(aPlayer);
		    }
		    else if (buySellResult==-2) {
			removePlayer(aPlayer);
			playerFail(aPlayer);
		    }
		    else if (buySellResult>0) {
			if ( (aPlayer.isBuyer()) && (buySellResult==currentAsk) && (aPlayer.getId() == currentBidder) )
			    buy=true;
			else if ( (!aPlayer.isBuyer()) && (buySellResult==currentBid) && (aPlayer.getId() == currentAsker) )
			    sell=true;
			else
			    System.out.println("Error in buy/sell responses!");
		    }
		}	 
	    }   
	}
	pHistory.addTrade(buy,sell);
    }

    private void buySellResult() {
	Iterator pIterator = myPlayers.iterator();
	int tradePrice = pHistory.getTradePrice(tN);
	int type=0;
	if (tradePrice>0) {
	    type=1; // 1 Means Buy request was accepted: sold at currentOffer
	    if (tradePrice==currentBid)
		type=2; // 2 means sell request was accepted: sold at currentBid
	}
	int buyer = currentBidder;
	int seller = currentAsker;
	if (tradePrice>0) {
	    currentBidder=0;
	    currentAsker=0;
	    currentBid=0;
	    currentAsk=0;
	}
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    int id = aPlayer.getId();
	    boolean isBuyer = aPlayer.isBuyer();
	    int status=0;
	    if (tradePrice>0) {
		if ((id==currentBidder)&&(isBuyer)&&(pHistory.getAcceptedStatus(isBuyer))) {
		    if (tradePrice==currentAsk)
			status=1;
		    else
			status=2;
		}
		if ((id==currentAsker)&&(!isBuyer)&&(pHistory.getAcceptedStatus(isBuyer))) {
		    if (tradePrice==currentBid)
			status=1;
		    else
			status=2;
		}
	    }
	    int myTrades = pHistory.getNumTrades(id, isBuyer);
	    aPlayer.buySellResult(status, myTrades, type, tradePrice, buyer, seller, currentBid, currentBidder, currentAsk, currentAsker);
	}
    }

    private void checkFailState() {
	if (failState) {
	    gameFailed();
	    Iterator pIterator = myPlayers.iterator();
	    while (pIterator.hasNext()) {
		SPlayer aPlayer = ((SPlayer)(pIterator.next()));
		pIterator.remove();
		sendPlayer(aPlayer);
	    }
	}
    }

    private void gameFinished() {
	myInitializer.setStatus("FINISHED");
	System.out.println("Game "+history.getGameId()+" has finished.");
	Iterator pIterator = myPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer aPlayer = ((SPlayer)(pIterator.next()));
	    sendPlayer(aPlayer);
	}
	try {
	    sleep (10000);
	    myInitializer.setStatus("CLEARING");
	} catch (InterruptedException e) {}
    }

    private void gameFailed() {
	myInitializer.setStatus("FAILED");
	if (failReason==1) {
	    allPlayerMessage("The game has failed due to either all buyers or all sellers dropping out.");
	    System.out.println("Game "+history.getGameId()+" has failed due to either all buyers or all sellers dropping out.");
	}
	else {
	    allPlayerMessage("The game has failed for an unknown reason.");
	    System.out.println("Game "+history.getGameId()+" has failed for an unknown reason.");
	}  
    }

    private void playerFail(SPlayer aPlayer) {
	System.out.println(aPlayer.getUserId()+" has dropped out of game "+history.getGameId()+" unexpectedly.");
	String tag = aPlayer.getIdTag();
	allPlayerMessage("Communications have failed with "+tag);
    }

    private void playerQuit(SPlayer aPlayer) {
	System.out.println(aPlayer.getUserId()+" has quit game "+history.getGameId()+".");
	String tag = aPlayer.getIdTag();
	allPlayerMessage(tag+" has chosen to quit the game.  Loser.");
    }

    private void allPlayerMessage(String s) {
	Iterator pIterator = myPlayers.iterator();
	while (pIterator.hasNext()) {
	    SPlayer anotherPlayer = ((SPlayer)(pIterator.next()));
	    anotherPlayer.sendLine(s);
	}
    }
	
    private void removePlayer(SPlayer aPlayer) {
	myPlayers.remove(aPlayer);
	sendPlayer(aPlayer);
    }
    
    private void sendPlayer(SPlayer aPlayer) {
	if (aPlayer.isBuyer())
	    numBuyers--;
	else
	    numSellers--;
	if ((numBuyers==0)||(numSellers==0)) {
	    failState=true;
	    failReason=1;
	}
	if (aPlayer.getType()!=2)
	    myHandler.takePlayer(aPlayer.getPlayerCom());
    }
	
}
	    
	    
	
