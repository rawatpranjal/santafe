import javax.swing.*;
import java.awt.event.*;

public class CMenuFrame extends JFrame implements ActionListener {
    DAClient myClient;
    JButton logoutButton, playGameButton, recordsButton;
    JPanel midPanel;
    
    public CMenuFrame(DAClient client) {
	super("Double Auction Menu");
	myClient = client;
	setup();
    }

    private void setup() {
	setUndecorated(true);
	getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	setDefaultLookAndFeelDecorated(true);

	setupButtons();
	midPanel = new JPanel();
	midPanel.add(playGameButton);
	midPanel.add(recordsButton);
	midPanel.add(logoutButton);

	add("Center", midPanel);

	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
 
	setVisible(true);
	setSize(150,300);
	setLocationRelativeTo(null);
	setResizable(false);
    }

    private void setupButtons() {
	logoutButton = new JButton("Logout");
	logoutButton.addActionListener(this);

	playGameButton = new JButton("Play a Game");
	playGameButton.addActionListener(this);

	recordsButton = new JButton("Review Records");
	recordsButton.addActionListener(this);
	recordsButton.setEnabled(false);
    }

    private void playGameButtonPressed() {
	myClient.selectPlayGame();
    }

    private void logoutButtonPressed() {
	myClient.selectLogOut();
    }

    private void recordsButtonPressed() {
    }

    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if (source == playGameButton)
	    playGameButtonPressed();
	else if (source == logoutButton)
	    logoutButtonPressed();
	else if (source == recordsButton)
	    recordsButtonPressed();
    }
}
    

