import java.util.*;

// PerryOriginalRobot
// playerNumber = 0007
public class SRobotPerryOriginal extends SRobotSkeleton {

    public final static String robotType = "PerryOriginalRobot";
    public final static int robotNum = 7;
    public final static int rolePref = 3;

    public SRobotPerryOriginal() {
	super(robotType, robotNum, rolePref);
    }

/* 4. User variables
 * -----------------
 * Put definitions of your own global variables after this heading.
 * Names must be distinct from the variables and routines defined above.
 * If FILEBASED, these variables will NOT be saved unless you also put
 * them into the savedata and retrievedata routines.
 */

/* 'extern' removed from the next 10 lines -- RGP */
    private long r_price_sum = 0;  /* sum of the prices within a round */
    private long r_price_ss = 0;   /* price sum of squares in the round */
    private int rtrades =0;            /* number of trades in the round */
    private int ctrades =0;            /* trade counter */
    private int r_price_ave =0;        /* average trading price in the round */
    private int r_price_std = 50;      /* price standard deviation within the round */
    private int round_count =0;        /* round number */
    private float a0 = (float) 2.0;            /* tuneable parameter */
    private int p_ave_price=0;         /* average price in the period */
    private int price_std = 0;         /* price standard deviation in the round */

    private int mprice;                /* Maximum trade price so far this *game* ??? [DCM] */

    public void playerGameBegin() {}

    public void playerGameEnd() {}

    public void playerRoundBegin() {

    /* At the begining of each round set the period average price and
       price standard deviation to 0
    */
        p_ave_price=0;
        price_std=0;
    }

    public void playerRoundEnd() {}

    public void playerPeriodBegin() {}

    public void playerPeriodEnd() {
        evaluate();  /* call the evaluation function at the end of each round */
    }

    public void playerBidAskEnd() {}

    public void playerBuySellEnd() {}

    public int playerRequestBid() {
        int most, newbid,t1,s;
        int i;
        float db,pi,da,a1;
        int low;

/* a1 is a tuneable parameter depending on the number of players,
*  the time in the period, and the seller/buyer ratio.
*/

        a1 = (float) a0 * (ntimes-t)/ntimes * (nplayers-1)/nplayers * nsellers/nbuyers ;


        round_average_price();
        s=(drand()>0.5)? 1: -1;

/* Set average price equal to the previous periods average price.
* Weight the standard devation by last periods standard deviation and the round
* price standard deviation.
*/

        if(p_ave_price != 0) {
            r_price_ave=p_ave_price;
            r_price_std = (3*price_std + r_price_std)/3;
        }


        if (nobidask>0) return 0;	/* nothing left to trade */
/*************************************************************************/
/* For the first 3 trades of the first period use a conservative approach*/

        if (ntrades < 3 && p == 1) {
            if(cask == 0){                     /* The first bid is random */
                newbid = (int) ( token[ntokens] *  drand() );
    			return newbid;                 /* and is less than the smallest token. */
	  		}
            else{                           /* Other bids increase gradually */
                newbid = (int) ( (float) cbid *(1+((float) (cask-cbid)/((float) (1.2+drand()) * (cbid+cask)))) );
                return ( (newbid < token[mytrades+1] ) ? newbid : 0);
			}                      /*Do not bid higher than the next token value. */
        }
/* After the first 3 trades change strategy to a statistical approach */

        else{

/* The maximum opening bid on any item is the smaller of
* the round average price and the current token value. The minimum opening bid
* is 3 standard deviations below the round average price. The actual bid
* depends on the round average price, standard deviation, and the weighting
* factor a1.
*/

/* Lowest opening bid */
            low = r_price_ave - 3*r_price_std;

            if(cask == 0 && cbid == 0 ){
                most = (r_price_ave < token[mytrades+1]-1)? r_price_ave : token[mytrades+1]-1;
                newbid = (int) (r_price_ave - a1*r_price_std);
                newbid = (newbid > low)? newbid : low;
				newbid = (newbid > minprice)? newbid : 0;
                return (newbid < most )? newbid : most;
			}


    		else {      /* cbid not equal to 0 -- don't bid more than current offer */
                most = ( token[mytrades+1]-1);
                if (most <= cbid) return 0;
                most = (most < cask) ? most : cask;  /* highest possible bid */


                /* Newbid can be up to 0.2 standard deviation above the average price.
                 *  In addition, the weighting factor, a1 shrinks towards 0 as the period progresses.
                 *  A little noise is also added, and then newbid is tested to see that it is
                 *  greater than the current bid.  The upper limit is reached only at the end
                 *  of the period.
                 */


                newbid = (int) (r_price_ave+ 0.2*r_price_std - a1 * r_price_std + drand()*4*s);
                t1 = t;
                while(newbid <= cbid && ++t1 < ntimes) {
/* to prevent returning a bid that is less than the current bid
 *  continue until an acceptable bid is generated
 */
                    a1 = (float) a0 * (ntimes-t1)/ntimes * (nplayers-1)/nplayers * nsellers/nbuyers *nsellers/nbuyers * nsellers/nbuyers;
                    newbid = (int) (r_price_ave+0.2*r_price_std - a1*r_price_std);
                    if( t1 == ntimes-1 ) newbid = cbid + 1;
				}

                newbid =(newbid>low)? newbid : 0;
                return (newbid < most )? newbid : most;

			}
        }
    }


    public int playerRequestAsk() {
        int newoffer,least;
        int i,t1;
        float a,a1,s;

        if (nobidask>0) return 0;	/* nothing left to trade */

        if (cask !=0 && cask < token[mytrades+1]) return 0;

        round_average_price();

        for(i=1;i<=ntrades;i++) mprice = (mprice > abs(prices[i]))? mprice : abs(prices[i]);

        if(p_ave_price != 0) {
            r_price_ave=p_ave_price;
            r_price_std=  (3 * price_std + r_price_std)/3;
        }
        a1 = a0 * (float) (ntimes-t)/ntimes * nbuyers/nsellers * (nplayers-1)/nplayers;
/*********************/

/* for the first 3 trades use a conservative strategy */

        if (p== 1 && ntrades <=3  ) {
            if(cbid==0 && cask == 0 ){
                newoffer = maxprice;
                newoffer = (int) (maxprice* drand());
                while(newoffer <= token[ntokens] ) {
                    newoffer =  (int) (maxprice * drand());
                }

                return (int) newoffer;
            }
            else{
                if(cask>cbid){
                    least = token[ntokens]+1;
                    /* simply return a linear decrease in the offer */
                    newoffer = (int) ( cask * (0.97 + 0.05*drand()) );
                    return ( (newoffer<cask)? newoffer : (int) (cask * 0.99) );
                }
            }

        }

/*********************************************/
/* After the first 3 trades use a statistical offer adjustment */

        if(cbid == 0 ){  /* first bid strategy after first 3 bids of the round*/

			newoffer = (int) ( r_price_ave  + (float) (a1 * r_price_std) + (20 *drand()));
            newoffer = ( (newoffer > token[mytrades+1]) ? newoffer : (int) (token[mytrades+1] * (1.1 + drand())) );

            if (newoffer  >= maxprice) {

                while(newoffer>=maxprice){
                    newoffer =  (int) (token[ntokens] * (1+drand()));
                }
                return (int) newoffer;
            }
            return (int) newoffer;


        }


        else {       /* cbid not = 0 */
			least = token[mytrades+1]+1;
			if (cbid>least) least = cbid;

            /* statistical bid adjustment begins here */
			if(r_price_ave>0){

				newoffer = (int) (r_price_ave + (a1 * r_price_std) + ( 20  * drand()) );
                if(newoffer>cask){
					newoffer = (int) (cask - 5 * drand() );
                }
                return(newoffer>least)? newoffer:least;
            }
            else {

                newoffer = (int) (cask * 0.99);
                return ( (newoffer>least)? newoffer:least);
					}
        }
    }

    public int playerRequestBuy() {
        int ap;
        float a1;


/* a1 is a weighting factor that depends on the number of players, the
*  time remaining in the period, and the seller/buyer ratio.
*/

        a1 =  (float) (2 * (ntimes-t)/ntimes*(nplayers-1)/nplayers + drand() );

/*a1 = (float) a0 * (ntimes-t)/ntimes * (nplayers-1)/nplayers * nsellers/nbuyers ;*/


        if (nobuysell>0) return 0;
        if (token[mytrades+1] <= cask) return 0;	/* don't buy at a loss! */
        if (id==bidder && cbid>=cask) return 1;   /* accept offer <= my bid */


/* Buy if the current offer is in the acceptance region */
        if (id == bidder)
            return (cask <= (float) r_price_ave + 0.2* r_price_std - a1*r_price_std)?  1 : 0;

        else return 0;

	}

    public int playerWantToSell() {

        int ap, least, answer;
        float a,a1;

        a1 = 2* (float) (ntimes-t)/ntimes *(nplayers-1)/nplayers;

        if (nobuysell>0) return 0;
        if (token[mytrades+1]-1 >= cbid) return 0;	/* don't sell at a loss! */
        if (id==asker && cbid >= cask) {
            return 1;	/* accept bid >= our offer */
        }
        if(ntrades >0)	{
            round_average_price();

            if(p_ave_price != 0) {
                r_price_ave=p_ave_price;
                r_price_std =  (3 * price_std + r_price_std)/3;
            }

            answer =(cbid >= ( r_price_ave  + (a1 * r_price_std )) ) ? 1 : 0;
            if (answer == 0 && (float) (ntimes-t)/ntimes <= 0.20) {
                least = token[mytrades+1] +2;	/* added by RGP by request */
                answer = (cbid > least) ? 1 : 0;
            }
            return answer;


		}
        else return 0;

    }



/* 6. Strategy routines
 * --------------------

 */

/* The function evaluate adjusts the parameter a0 based on the
*  players performance at the end of each period. If the estimated
*  efficiency is acceptable no change is made.  In addition, an
*  adjustment may be made to the computed standard deviation.
*/

    private void evaluate()
	{

      int x=1,i,feasible_trades=0;
	float e=1;
	long price_ss = 0;
	int price_var = 0;
	int  price_sum=0;


      p_ave_price=ave_price();
	for(i=1;i<=ntrades;i++){
            price_sum += abs(prices[i]);
        	price_ss += (long) prices[i] * prices[i];
		}

	if (ntrades >1) price_var = (int) ( (price_ss -  price_sum * (float) price_sum / ntrades)/(ntrades));
	price_std = (int) Math.sqrt(Math.abs((double)price_var));




if(role==1)
	{
      for(i=1;i<=ntokens;i++) {
		if( token[i]-p_ave_price >= 0) {
			feasible_trades++;
			x += token[i]-p_ave_price;
			}
		}
	}

if(role==2){

for(i=1;i<=ntokens;i++) {
	if( p_ave_price - token[i] >= 0) {
		feasible_trades++;
		x += p_ave_price-token[i];
	}
	}
	}

      e = (float) pprofit/x;




	if(e<1.0 && mytrades < feasible_trades){
      	if(e==0) a0=a0/3;
	 	else a0=a0*e;
            }
	 if(e<=0.8 && mytrades < feasible_trades && price_std < 10) price_std = 30;
       if(e<=0.9 && mytrades >= feasible_trades) {
            a0 = a0 * (2-e);
            }
       if(e<=0.8 && mytrades >= feasible_trades && price_std<10) {
            a0 = a0 * (2-e);
		price_std=30;
            }

	}


/* returns the average price within the current period */

    private int ave_price()
	{
         int ap = 0, i;
       if(ntrades==0) return 0;

	for(i=1;i<=ntrades;i++)	ap += abs(prices[i]);

        return (int)  ap/ntrades ;
        }

/* computes the average price within the round
*  and the round price standard deviation
*/

    private void round_average_price()
	{

        int last_price, r_price_var;


        if(r != round_count){
		++round_count;
		r_price_sum = 0;
		r_price_ss=0;
		rtrades=0;
		ctrades=0;
		r_price_ave=0;
		r_price_std=30;  /* default value of standard deviation used initially to prevent zero division error*/
		}
	if(ntrades > 0 && ntrades != ctrades) {
	if(ntrades == 1 && ctrades != 0) ctrades = 0;
	++ctrades;
        rtrades++;



        last_price = abs(prices[ntrades]);
	r_price_sum +=last_price;
        r_price_ss +=(long) last_price*last_price;
	r_price_ave = (int) r_price_sum/rtrades;
	if (rtrades >1) r_price_var = (int) ((r_price_ss - r_price_sum*r_price_sum/rtrades)/(rtrades));
        else r_price_var = 900;
	r_price_std = (int) Math.sqrt(Math.abs((double)r_price_var));

	}

	}
/******************************************************************/


}
