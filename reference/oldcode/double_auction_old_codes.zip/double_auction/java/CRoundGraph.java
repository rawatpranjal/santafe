import javax.swing.*;
import java.awt.Color.*;
import java.awt.*;
import java.awt.geom.*;
import java.applet.*;
import java.util.*;
import java.awt.event.*;

public class CRoundGraph extends JPanel implements ActionListener {

    private GameHistory myGameHistory;
    private RoundHistory myHistory;
    private int myRoundNumber;
    private int numPeriods;
    private Color[] periodColors;

    private int leftSpacing = 40; // # of pixels to the left of the graph.
    private int topSpacing = 40; // # of pixels above the graph.
    private int bottomSpacing = 70; // # of pixels below the graph.
    private int rightSpacing = 20; // # of pixels to the right of the legend
    private int betweenSpacing = 10; // # of pixels between the graph and the legend.
    private int legendWidth = 75; // # of pixels wide for the RHS legend.

    private int upperGBound;
    private int lowerGBound;
    private int rightGBound;
    private int leftGBound;

    // The maximum possible value that could need to be graphed.
    // In most cases, this will be the highest token value among
    // the bidders.
    private int maxValue;
    
    private int[] buyerTokenValues;
    private int[] sellerTokenValues;
    private int numBuyerTokens;
    private int numSellerTokens;

    // The maximum of the total tokens of the sellers and the total tokens of the buyers
    private int numTokens;
    
    private int xWindow;
    private int yWindow;

    private int numBuyers;
    private int numSellers;
    private int numPlayers;

    private int xRange;
    private int yRange;
    private Color sellerGraphColor = new Color(150,0,0);
    private Color buyerGraphColor = new Color(0,150,0);

    // These variables store how many pixels are equal to 1 in x or y terms respectively.
    private double xPixel, yPixel;
    private boolean iAmBuyer, iAmObserver;
    private int myId;
    private String typeString;
    

    private BasicStroke dottedStroke = new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, new float[] {2f}, 0f);

    private BasicStroke thickStroke = new BasicStroke(3f);

    private boolean stepFunction = true;

    private JButton graphStyleButton = new JButton("Graph Style");

    public CRoundGraph(GameHistory gh) {
	super();
	myGameHistory = gh;
	iAmObserver = gh.iAmObserver();
	myHistory = gh.getCurrentRound();
	myRoundNumber = myHistory.getRoundNumber();
	numPeriods = myHistory.getNumPeriods();

	setPeriodColors();

	sellerTokenValues = myHistory.getSellerTokenValues();
	buyerTokenValues = myHistory.getBuyerTokenValues();
	numBuyerTokens = buyerTokenValues.length-1;
	numSellerTokens = sellerTokenValues.length-1;
	numTokens = Math.max(numBuyerTokens,numSellerTokens);
	maxValue = Math.max(sellerTokenValues[numSellerTokens],buyerTokenValues[numBuyerTokens]);

	setGraphSize();

	iAmBuyer = myGameHistory.iAmBuyer();
	myId = myGameHistory.getMyId();
	setTypeString();

	myId = myGameHistory.getMyId();

	numBuyers = myGameHistory.getNumBuyers();
	numSellers = myGameHistory.getNumSellers();
	numPlayers = numSellers+numBuyers;
	
	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));

	graphStyleButton.setAlignmentX(0.0f);
	graphStyleButton.setAlignmentY(1.0f);
	graphStyleButton.addActionListener(this);
	add(graphStyleButton);
    }

    public void paintComponent(Graphics g) {

	setGraphSize();

	g.clearRect(0,0,xWindow,yWindow);
	g.setColor(Color.WHITE);
	g.fillRect(leftGBound,upperGBound,rightGBound-leftGBound,lowerGBound-upperGBound);

	g.setColor(Color.BLACK);
	g.drawRect(leftGBound,upperGBound,rightGBound-leftGBound,lowerGBound-upperGBound);

	drawLinesAndLabels(g);
	drawSupplyAndDemand(g);
	drawTransactions(g);
	drawLegend(g);
    }

    private void drawGraphLine(Graphics g, double t1, double p1, double t2, double p2) {
	int x1 = (int)(xPixel*t1+leftGBound);
	int x2 = (int)(xPixel*t2+leftGBound);
	int y1 = (int)(lowerGBound-yPixel*p1);
	int y2 = (int)(lowerGBound-yPixel*p2);
	g.drawLine(x1,y1,x2,y2);
    }

    private void setGraphSize() {
	int xWindowNew, yWindowNew;
	xWindowNew = getWidth();
	yWindowNew = getHeight();
	if ((xWindowNew != xWindow) || (yWindowNew != yWindow)) {
	    yWindow = yWindowNew;
	    xWindow = xWindowNew;
	    calculateBounds();
	    calculateRanges();
	    calculatePixels();
	    setSize(xWindow,yWindow);
	}
    }

    private void calculateBounds() {
	upperGBound = topSpacing;
	lowerGBound = yWindow-bottomSpacing;
	leftGBound = leftSpacing;
	rightGBound = xWindow-rightSpacing-betweenSpacing-legendWidth;
    }

    private void calculateRanges() {
	xRange = numTokens+1;
	yRange = (((maxValue+110)/100)*100);
    }

    private void calculatePixels() {
	xPixel = ((double)(rightGBound-leftGBound))/((double)xRange);
	yPixel = ((double)(lowerGBound-upperGBound))/((double)yRange);
    }

    private void drawLinesAndLabels(Graphics g) {
       	Graphics2D myGraphics = (Graphics2D)g;

	g.setColor(Color.BLACK);
	g.setFont(new Font(null, Font.BOLD, 12));
	for (int x=1;x<=numTokens;x++) {
	    int xCoord = leftGBound+(int)(x*xPixel);
	    myGraphics.drawLine(xCoord,lowerGBound,xCoord,lowerGBound+10);
	    myGraphics.drawString(""+x,xCoord-3,lowerGBound+25);
	}

	myGraphics.setStroke(dottedStroke);

	int yIncrement=yRange/10;
	for (int i=0;i<=9;i++) {
	    int y=upperGBound+(int)(i*yPixel*yIncrement);
	    myGraphics.drawLine(leftGBound,y,rightGBound,y);
	    myGraphics.drawString("" + (yIncrement*(10-i)),5,y+5);
	}

	myGraphics.setStroke(new BasicStroke());

	g.setFont(new Font(null, Font.BOLD, 16));
	g.drawString("Round Summary for Round "+myRoundNumber+". You are "+typeString+".", ((xWindow-350)/2), 20);
    }

    private void drawSupplyAndDemand(Graphics g) {
	Graphics2D myGraphics = (Graphics2D)g;
	myGraphics.setStroke(thickStroke);

	// DEMAND
	myGraphics.setColor(buyerGraphColor);
	int x = buyerTokenValues.length;
	int y=0;
	int nextValue = buyerTokenValues[x-1];
	int currentValue;
	while ((x>1)&&(nextValue>0)) {
	    x--;
	    currentValue=nextValue;
	    nextValue = buyerTokenValues[x];
	    if (stepFunction) {
		drawGraphLine(myGraphics, y, currentValue, y+1, currentValue);
		drawGraphLine(myGraphics, y+1, currentValue, y+1, nextValue);
	    }
	    else
		drawGraphLine(myGraphics,y,currentValue,y+1,nextValue);
	    y++;
	}
	
	// SUPPLY
	myGraphics.setColor(sellerGraphColor);
	x = 0;
	y = 0;
	nextValue = sellerTokenValues[1];
	while ((x<(sellerTokenValues.length-1))&&(nextValue>0)) {
	    x++;
	    currentValue=nextValue;
	    nextValue = sellerTokenValues[x];
	    if (stepFunction) {
		drawGraphLine(myGraphics, y, currentValue, y+1, currentValue);
		drawGraphLine(myGraphics, y+1, currentValue, y+1, nextValue);
	    }
	    else
		drawGraphLine(myGraphics, y, currentValue, y+1, nextValue);
	    y++;
	}

	myGraphics.setStroke(new BasicStroke());
    }
    
    private void drawTransactions(Graphics g) {
	int tradePrice, x, t, lastPrice;
	PeriodHistory pHistory;
	for (int p=1;p<=numPeriods;p++) {
	    pHistory = myHistory.getPeriod(p);
	    g.setColor(periodColors[p]);
	    x=1;
	    t=1;
	    tradePrice=0;
	    lastPrice=0;
	    while (tradePrice!=-1) {
		tradePrice = pHistory.getTradePrice(x);
		if (tradePrice>0) {   
		    drawTransaction(g,t,tradePrice);
		    if (lastPrice>0)
			connect(g, t-1, lastPrice, tradePrice);
		    t++;
		    lastPrice=tradePrice;
		}
		x++;
	    }
	}
    }	

    private void drawLegend(Graphics g) {
	int verticalSpacing = ((lowerGBound-upperGBound)/numPeriods)/2;
	int left = xWindow-rightSpacing-legendWidth;
	int y = upperGBound;
	int p=0;
	g.setFont(new Font(null, Font.BOLD, 14));
	while (p<numPeriods) {
	    p++;
	    g.setColor(periodColors[p]);
	    g.fillRect(left+5, y+verticalSpacing/2,legendWidth-5,verticalSpacing);
	    g.setColor(Color.BLACK);
	    g.drawString("Period "+p, left+10, y+verticalSpacing);
	    y+=verticalSpacing*2;
	}
    }
	    
    private void drawTransaction(Graphics g, int token, int price){
	g.fillOval((int)(xPixel*token+leftGBound-3),(int)(lowerGBound-3-yPixel*price),6,6);
    }

    private void connect(Graphics g, int t, int p1, int p2) {
	if ((p1>0)&&(p2>0))
	    drawGraphLine(g, t,p1,t+1,p2);
    }

    private void setTypeString() {
	typeString = "Seller "+myId;
	if (iAmBuyer)
	    typeString = "Buyer "+myId;
	if (iAmObserver)
	    typeString = "an observer";
    }

    public int getRoundNumber() { return myRoundNumber; }

    private void setPeriodColors() {
	periodColors = new Color[numPeriods+1];
	periodColors[1] = new Color(150,150,0);
	periodColors[2] = new Color(150,0,150);
	if (numPeriods>2)
	    periodColors[3] = new Color(0,150,150);
	if (numPeriods>3)
	    periodColors[4] = new Color(0, 0, 200);
	if (numPeriods>4)
	    periodColors[5] = new Color(100,100,100);
    }

    public void setStepFunction(boolean b) {
	stepFunction = b;
	repaint();
    }
    
    public void switchStepFunction() {
	if (stepFunction)
	    stepFunction=false;
	else
	    stepFunction=true;
	repaint();
    }
    
    public boolean getStepFunction() {
	return stepFunction;
    }

    public void actionPerformed(ActionEvent e) {
	Object source = e.getSource();
	if (source==graphStyleButton)
	    switchStepFunction();
    }
    
}
