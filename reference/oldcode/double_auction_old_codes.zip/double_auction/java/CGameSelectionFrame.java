import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.awt.*;

public class CGameSelectionFrame extends JFrame implements ActionListener {

    private JPanel rolePreferencePanel, buttonPanel;
    private JScrollPane gameScroller;
    
    private CGameCreationFrame myCreationFrame;

    private JTable gameTable;
    private GameTableModel gameData;

    private int rolePreference; //1 = B 2 = S 3 = E
    private DAClient myClient;
    private CServerCom myCom;

    private JTextField messageField;

    private ButtonGroup preferenceButtonGroup;
    private JRadioButton buyerRB, sellerRB, eitherRB, observerRB;

    private JButton refreshButton, joinGameButton, newGameButton, backButton;

    private JLabel playerRoleLabel;

    private Timer refreshTimer;

    public CGameSelectionFrame (CServerCom com, DAClient c) {
	super("Double Auction Game Selection");
	myCom = com;
	myClient = c;
	setup();
    }

    private void setup() {
	setUndecorated(true);
	getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	setDefaultLookAndFeelDecorated(true);

	setupGameList();
	setupRolePreferencePanel();
	setupButtonPanel();

	add("North",gameScroller);
	add("Center",rolePreferencePanel);
	add("South",buttonPanel);

	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
 
	setVisible(true);
	setSize(800,500);
	setLocationRelativeTo(null);
	setResizable(false);

	refreshButton.doClick();

	myCreationFrame = new CGameCreationFrame(myCom, this);
    }
	
    private void setupGameList() {
	gameData = new GameTableModel();
	gameTable = new JTable(gameData);
	gameTable.setPreferredScrollableViewportSize(new Dimension(750,350));
	gameTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	gameScroller = new JScrollPane(gameTable);
    }

    private void setupRolePreferencePanel() {
	playerRoleLabel = new JLabel("What would you prefer to play as?");
	
	setupRolePreferenceChoice();
	messageField = new JTextField(20);
	messageField.setEditable(false);
	rolePreferencePanel = new JPanel();
	rolePreferencePanel.add(playerRoleLabel);
	rolePreferencePanel.add(buyerRB);
	rolePreferencePanel.add(sellerRB);
	rolePreferencePanel.add(eitherRB);
	rolePreferencePanel.add(observerRB);
	
	rolePreferencePanel.add(messageField);
    }

    private void setupButtonPanel() {
	setupButtons();
	buttonPanel = new JPanel();
	buttonPanel.add(joinGameButton);
	buttonPanel.add(newGameButton);
	buttonPanel.add(refreshButton);
	buttonPanel.add(backButton);
    }

    private void setupRolePreferenceChoice() {
	buyerRB = new JRadioButton("Buyer");
	sellerRB = new JRadioButton("Seller");
	eitherRB = new JRadioButton("Either");
	observerRB = new JRadioButton("Observer Mode");
	preferenceButtonGroup = new ButtonGroup();
	preferenceButtonGroup.add(buyerRB);
	preferenceButtonGroup.add(sellerRB);
	preferenceButtonGroup.add(eitherRB);
	preferenceButtonGroup.add(observerRB);
	eitherRB.setSelected(true);
    }

    private void setupButtons() {
	refreshButton = new JButton("Refresh Games");
	refreshButton.addActionListener(this);
	
	joinGameButton = new JButton("Join Game");
	joinGameButton.addActionListener(this);
	
	newGameButton = new JButton("New Game");
	newGameButton.addActionListener(this);

	backButton = new JButton("Back to Menu");
	backButton.addActionListener(this);
    }

    public void setMessageText(String s) {
	messageField.setText(s);
    }

    // Returns 1 for buyer, 2 for seller, 3 for either
    public int getPlayerPreference() {
	if (buyerRB.isSelected())
	    return 1;
	else if (sellerRB.isSelected())
	    return 2;
	else if (eitherRB.isSelected())
	    return 3;
	else if (observerRB.isSelected())
	    return 4;
	else
	    return -1;
    }

    public void submittedGame() {
	myCreationFrame.setVisible(false);
	setVisible(true);
	String s = myCom.waitForLine();
	if (s.equals("game"))
	    setMessageText("Your game was added to the list!");
	else
	    setMessageText("Sorry, that game could not be created for some reason...");
	refreshButton.doClick();
    }

    private void refreshButtonPressed() {
	myCom.sendLine("refresh");
	int col = gameData.getColumnCount();
	int numGames = Integer.parseInt(myCom.waitForLine());
	gameData.setRowCount(0);
	gameData.setRowCount(numGames);
	for (int x=0;x<numGames;x++)
	    for (int y=0;y<col;y++)
		gameData.setValueAt(myCom.waitForLine(),x,y);
	stopRefreshTimer();
	setRefreshTimer(5);
    }

    private void newGameButtonPressed() {
	stopRefreshTimer();
	setVisible(false);
	myCreationFrame.setVisible(true);
    }

    private void joinGameButtonPressed() {
	int selectedRow = gameTable.getSelectedRow();
	if (selectedRow == -1)
	    setMessageText("You haven't selected a Game!");
	else { 
	    int gameId = Integer.parseInt((String)gameData.getValueAt(selectedRow,0));
	    myCom.sendLine("join");
	    myCom.sendLine(gameId+"");
	    myCom.sendLine(getPlayerPreference()+"");
	    String response=myCom.waitForLine();
	    if (response.equals("join")) {
		myCleanup();
		myClient.selectJoinGame(getPlayerPreference());
	    }
	    else if (response.equals("fail"))
		setMessageText("Sorry, couldn't join that game.");
	}
    }

    private void myCleanup() {
	stopRefreshTimer();
	myCreationFrame.dispose();
	myCreationFrame=null;
        setVisible(false);
	dispose();
    }

    private void backButtonPressed() {
	myCleanup();
	myClient.selectBackToMenu();
    }   

    private void setRefreshTimer(int secs) {
	int delay = secs*1000;
	refreshTimer = new Timer(delay, this);
	refreshTimer.setRepeats(false);
	refreshTimer.start();
    }

    private void stopRefreshTimer() {
	if (refreshTimer!=null)
	    refreshTimer.stop();
	refreshTimer=null;
    }

    public void actionPerformed(ActionEvent e) {
	synchronized (this) {
	    Object source = e.getSource();
	    if (source==refreshButton)
		refreshButtonPressed();
	    else if (source==newGameButton)
		newGameButtonPressed();
	    else if (source==joinGameButton)
		joinGameButtonPressed();
	    else if (source==backButton)
		backButtonPressed();
	    else if (source==refreshTimer)
		refreshButton.doClick();
	}
    }

    private class GameTableModel extends DefaultTableModel {
	private String[] columnNames = {"GameId", "CreatorId", "Starting In", "Min Humans", "Max Humans", "Robots", "Players Joined", "Status"};
	
	public GameTableModel() {
	    super();
	    setColumnIdentifiers(columnNames);
	}

	public boolean isCellEditable(int row, int column) { return false; }
    }
    
}
