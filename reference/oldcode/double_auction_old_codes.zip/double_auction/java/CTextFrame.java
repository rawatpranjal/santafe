import java.awt.*;
import javax.swing.*;

// This handles the graphical end of things.
public class CTextFrame extends JFrame {
    private JTextArea history;
    private JScrollPane historyScroller;
    private CGameController myController;
    
    public CTextFrame() {
	super("Game Text");
	setup();
    }
    
    private void setup() {
	setDefaultCloseOperation(HIDE_ON_CLOSE);
	setupHistoryField();
	setupAppearance();

	getContentPane().setLayout(new BorderLayout());
	getContentPane().add("Center", historyScroller);
	pack();
    }

    private void setupAppearance() {
	setUndecorated(true);
	getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	setDefaultLookAndFeelDecorated(true);
	setVisible(true);
    }

    private void setupHistoryField() {
	history = new JTextArea(30,40);
	history.setLineWrap(true);
	history.setEditable(false);
	historyScroller = new JScrollPane();
	historyScroller.getViewport().add(history);
    }

    public void givePlayerMessage(String s) { 
	history.append(s + "\n");  
	history.setCaretPosition(history.getText().length());
    }

}
