import java.io.*;
import java.net.*;

public class SPlayerCom {
    private static int numInstantiated=1;
    
    // An id#, starting with 1 for the first created.
    private int comNumber;
    private Socket mySocket;
    private PrintWriter myOut;
    private BufferedReader myIn;
    private boolean isConnected;

    private String userId="NO_USER";
    private int playerNumber=7777;
    private String name;

    public SPlayerCom() {}

    public SPlayerCom(Socket socket) {
	mySocket=socket;
	isConnected=true;
	try {
	    myOut = new PrintWriter(socket.getOutputStream(), true);
	    myIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	} catch (IOException e) {
	    System.out.println("Error creating new DAPlayerCOM#"+numInstantiated);
	    isConnected=false;
	}
	comNumber=numInstantiated;
	numInstantiated++;
    }

    public SPlayerCom(String address, int port) {
	Socket socket;
	isConnected=true;
	try {
	    socket = new Socket(address, port);
	    myOut = new PrintWriter(socket.getOutputStream(), true);
	    myIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}  catch (UnknownHostException e) {
	    System.out.println("UnknownHostException creating new DAPlayerCOM#"+numInstantiated);
	    isConnected=false;
	} catch (IOException e) {
	    System.out.println("IOException creating new DAPlayerCOM#"+numInstantiated);
	    isConnected=false;
	}
	comNumber=numInstantiated;
	numInstantiated++;
    }
	
    public String getLine() {
	String line = "";
	try {
	    if (myIn.ready())
		line=myIn.readLine();
	} catch (IOException e) {
	    System.out.println(userId+": Error in getLine()");
	    isConnected=false;
	}
	if ((Global.DEBUG_MODE)&&(!line.equals("")))
	    System.out.println("Received '"+line+"' from "+userId);
	return line;
    }

    public String waitForLine() {
	String line = "";
	try {
	    line=myIn.readLine();
	} catch (IOException e) {
	    System.out.println(userId + ": Error in getLine()");
	    isConnected=false;
	}
	if ((Global.DEBUG_MODE)&&(!line.equals("")))
	    System.out.println("Received '"+line+"' from "+userId);
	return line;
    }

    public void sendLine(String s) {
	myOut.println(s);
	if (Global.DEBUG_MODE)
	    System.out.println("Sending: '"+s+"' to "+userId);
    }

    public int getComNumber() {
	return comNumber;
    }
		
    public void close() {
	isConnected=false;
	try {
	    myIn.close();
	    myOut.close();
	    mySocket.close();
	} catch (IOException e) { System.out.println("Problem closing communications with "+userId); }
    }

    public boolean isConnected() { return isConnected; }

    public void setUser(String u) { userId=u; }
    
    public String getUser() { return userId; } 

    public void setPlayerNumber(int n) {playerNumber = n;}

    public int getPlayerNumber() { return playerNumber; }

    public void setName(String n) {name = n;}

    public String getName() { return name; }
}

