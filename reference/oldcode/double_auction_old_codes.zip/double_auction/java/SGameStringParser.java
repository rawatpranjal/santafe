import java.util.*;

public class SGameStringParser {
    private static int timeoutD = 60;
    private static int minWaitTimeD = 0;
    private static int maxWaitTimeD = 60;
    private static int minHumanPlayersD = 2;
    private static int maxHumanPlayersD = 8;
    private static int minBuyersD = 1;
    private static int minSellersD = 1;
    private static int maxSellersD = 8;
    private static int maxBuyersD = 8;
    private static int numRoundsD = 3;
    private static int numPeriodsD = 3;
    private static int numTimesD = 25;
    private static int minTokensD = 3;
    private static int maxTokensD = 5;
    private static int minPriceD = 1;
    private static int maxPriceD = 999;
    private static int randGenD = 1236;


    private SGameHandler myHandler;
    private STokenGeneratorFactory myTokenGeneratorFactory;
    private SRobotFactory myRobotFactory;

    public SGameStringParser(SGameHandler myH) {
	myHandler=myH;
	myTokenGeneratorFactory = new STokenGeneratorFactory();
	myRobotFactory = new SRobotFactory();
    }

    public SGameInitializer parseGameString(SPlayerCom creator, int gameId, String gameDetails) {
	System.out.println("Game String Parser has been asked to parse: "+gameDetails);

	int timeout = timeoutD;
	int minWaitTime = minWaitTimeD;
	int maxWaitTime = maxWaitTimeD;
	int minHumanPlayers = minHumanPlayersD;
	int maxHumanPlayers = maxHumanPlayersD;
	int minBuyers = minBuyersD;
	int minSellers = minSellersD;
	int maxBuyers = maxBuyersD;
	int maxSellers = maxSellersD;
	int numRounds = numRoundsD;
	int numPeriods = numPeriodsD;
	int numTimes =  numTimesD;
	int minTokens = minTokensD;
	int maxTokens = maxTokensD;
	int minPrice = minPriceD;
	int maxPrice = maxPriceD;
	int randGen = randGenD;;

	String[] gameTerms = gameDetails.split("\\s",0);

	ArrayList<SPlayer> gameRobots = new ArrayList<SPlayer>();

	for (int x=1; x<gameTerms.length; x++) {
	    String s = gameTerms[x];
	    if (!s.equals("")) {
		x++;
		while (gameTerms[x].equals("")) x++;
		int value = Integer.parseInt(gameTerms[x]);
		if (s.equals("maxHumans"))
		    maxHumanPlayers = value;
		else if (s.equals("minHumans"))
		    minHumanPlayers = value;
		else if (s.equals("maxWaitTime"))
		    maxWaitTime = value;
		else if (s.equals("minWaitTime"))
		    minWaitTime=value;
		else if (s.equals("robot"))
		    gameRobots.add(myRobotFactory.makeRobot(value));
		else if (s.equals("timeout"))
		    timeout = value;
		else if (s.equals("minTokens"))
		    minTokens = value;
		else if (s.equals("maxTokens"))
		    maxTokens = value;
		else if (s.equals("numRounds"))
		    numRounds = value;
		else if (s.equals("numPeriods"))
		    numPeriods = value;
		else if (s.equals("numTimes"))
		    numTimes=value;
		else
		    System.out.println("Unrecognized game details code: "+s);
	    }
	}	

	STokenGenerator tGen = myTokenGeneratorFactory.makeFactory(randGen);

	return new SGameInitializer(myHandler, creator, gameId, timeout, minWaitTime, maxWaitTime, minHumanPlayers, maxHumanPlayers, gameRobots, numRounds, numPeriods, numTimes, maxBuyers, maxSellers, maxTokens, minPrice, maxPrice, minTokens, maxTokens, tGen, randGen);
    }
}
